#define RF_PACKAGE_BUILDING
#include "RF/Package.h"
#include "RF/Compression.h"
#include "RF/Core.h"
#include <stdio.h>
#include <stdlib.h>

RF_DEFINE_MODULE(RF_PACKAGE_API, "RF.Package.C", "C")

typedef struct { char* name; uint8_t* data; uint64_t stored, orig; uint32_t crc, flags; int owned; } Ent;
struct RF_Pack { Ent* e; size_t n, cap; char** mk; char** mv; size_t nm, mcap; uint8_t* blob; };

RF_Pack* rf_pack_new(void) { return rf_alloc(sizeof(RF_Pack)); }
void rf_pack_free(RF_Pack* p) {
    if (!p) return;
    for (size_t i = 0; i < p->n; i++) { rf_free(p->e[i].name); if (p->e[i].owned) rf_free(p->e[i].data); }
    for (size_t i = 0; i < p->nm; i++) { rf_free(p->mk[i]); rf_free(p->mv[i]); }
    rf_free(p->e); rf_free(p->mk); rf_free(p->mv); rf_free(p->blob); rf_free(p);
}
RF_Status rf_pack_set_meta(RF_Pack* p, const char* k, const char* v) {
    if (!p || !k || !v || !*k || strpbrk(k, "=\n") || strchr(v, '\n')) return RF_ERR_ARG;
    for (size_t i = 0; i < p->nm; i++) if (!strcmp(p->mk[i], k)) { char* nv = rf_strdup(v); if (!nv) return RF_ERR_NOMEM; rf_free(p->mv[i]); p->mv[i] = nv; return RF_OK; }
    if (p->nm == p->mcap) { size_t nc = p->mcap ? p->mcap * 2 : 8; char** a = rf_realloc(p->mk, nc * sizeof *a); if (!a) return RF_ERR_NOMEM; p->mk = a;
        char** b = rf_realloc(p->mv, nc * sizeof *b); if (!b) return RF_ERR_NOMEM; p->mv = b; p->mcap = nc; }
    p->mk[p->nm] = rf_strdup(k); p->mv[p->nm] = rf_strdup(v); p->nm++; return RF_OK;
}
const char* rf_pack_meta(const RF_Pack* p, const char* k) {
    if (!p || !k) return NULL; for (size_t i = 0; i < p->nm; i++) if (!strcmp(p->mk[i], k)) return p->mv[i]; return NULL;
}
static Ent* find(const RF_Pack* p, const char* name) { for (size_t i = 0; i < p->n; i++) if (!strcmp(p->e[i].name, name)) return &p->e[i]; return NULL; }

RF_Status rf_pack_add(RF_Pack* p, const char* name, const void* data, size_t size, int compress) {
    if (!p || !name || !*name || (!data && size) || strlen(name) > 65535 || find(p, name)) return RF_ERR_ARG;
    uint8_t* buf = NULL; size_t bn = 0; uint32_t flags = 0;
    if (compress && size) {
        void* c; size_t cn;
        if (rf_lz_compress(data, size, &c, &cn) == RF_OK) { if (cn < size) { buf = c; bn = cn; flags = 1; } else rf_free(c); }
    }
    if (!buf) { buf = rf_alloc(size); if (!buf) return RF_ERR_NOMEM; if (size) memcpy(buf, data, size); bn = size; }
    if (p->n == p->cap) { size_t nc = p->cap ? p->cap * 2 : 8; Ent* ne = rf_realloc(p->e, nc * sizeof *ne); if (!ne) { rf_free(buf); return RF_ERR_NOMEM; } p->e = ne; p->cap = nc; }
    Ent* e = &p->e[p->n++]; e->name = rf_strdup(name); e->data = buf; e->stored = bn; e->orig = size; e->crc = rf_crc32(data, size); e->flags = flags; e->owned = 1;
    return RF_OK;
}
size_t rf_pack_count(const RF_Pack* p) { return p ? p->n : 0; }
const char* rf_pack_name(const RF_Pack* p, size_t i) { return p && i < p->n ? p->e[i].name : NULL; }
uint64_t rf_pack_size(const RF_Pack* p, size_t i) { return p && i < p->n ? p->e[i].orig : 0; }

RF_Status rf_pack_extract(const RF_Pack* p, const char* name, void** data, size_t* size) {
    if (!p || !name || !data || !size) return RF_ERR_ARG;
    Ent* e = find(p, name); if (!e) return RF_ERR_NOTFOUND;
    uint8_t* out; size_t on;
    if (e->flags & 1) { void* d; if (rf_lz_decompress(e->data, (size_t)e->stored, &d, &on) != RF_OK) return RF_ERR_IO; out = d; }
    else { on = (size_t)e->stored; out = rf_alloc(on + 1); if (!out) return RF_ERR_NOMEM; memcpy(out, e->data, on); }
    if (on != e->orig || rf_crc32(out, on) != e->crc) { rf_free(out); rf_set_error("pack: CRC mismatch for %s", name); return RF_ERR_IO; }
    *data = out; *size = on; return RF_OK;
}

static void w16(uint8_t* o, uint32_t v) { o[0] = (uint8_t)v; o[1] = (uint8_t)(v >> 8); }
static void w32(uint8_t* o, uint32_t v) { for (int i = 0; i < 4; i++) o[i] = (uint8_t)(v >> (8 * i)); }
static void w64(uint8_t* o, uint64_t v) { for (int i = 0; i < 8; i++) o[i] = (uint8_t)(v >> (8 * i)); }
static uint32_t r16(const uint8_t* o) { return o[0] | (uint32_t)o[1] << 8; }
static uint32_t r32(const uint8_t* o) { return o[0] | (uint32_t)o[1] << 8 | (uint32_t)o[2] << 16 | (uint32_t)o[3] << 24; }
static uint64_t r64(const uint8_t* o) { return r32(o) | (uint64_t)r32(o + 4) << 32; }

RF_Status rf_pack_save_mem(const RF_Pack* p, void** out, size_t* size) {
    if (!p || !out || !size) return RF_ERR_ARG;
    size_t msz = 0; for (size_t i = 0; i < p->nm; i++) msz += strlen(p->mk[i]) + strlen(p->mv[i]) + 2;
    size_t data = 0, idx = 0; for (size_t i = 0; i < p->n; i++) { data += (size_t)p->e[i].stored; idx += 2 + strlen(p->e[i].name) + 4 + 24 + 4; }
    size_t total = 32 + msz + data + idx; uint8_t* b = rf_alloc(total); if (!b) return RF_ERR_NOMEM;
    uint8_t* w = b + 32;
    for (size_t i = 0; i < p->nm; i++) { size_t a = strlen(p->mk[i]), c = strlen(p->mv[i]); memcpy(w, p->mk[i], a); w += a; *w++ = '='; memcpy(w, p->mv[i], c); w += c; *w++ = '\n'; }
    uint64_t off = 32 + msz, index_off = 32 + msz + data; uint8_t* ix = b + index_off;
    for (size_t i = 0; i < p->n; i++) {
        const Ent* e = &p->e[i]; size_t nl = strlen(e->name);
        memcpy(b + off, e->data, (size_t)e->stored);
        w16(ix, (uint32_t)nl); ix += 2; memcpy(ix, e->name, nl); ix += nl; w32(ix, e->flags); ix += 4;
        w64(ix, off); ix += 8; w64(ix, e->stored); ix += 8; w64(ix, e->orig); ix += 8; w32(ix, e->crc); ix += 4; off += e->stored;
    }
    memcpy(b, "UDKL", 4); w32(b + 4, 1); w32(b + 8, (uint32_t)p->n); w32(b + 12, (uint32_t)msz); w64(b + 16, index_off); w32(b + 24, 0);
    w32(b + 28, rf_crc32(b, 28)); *out = b; *size = total; return RF_OK;
}

RF_Status rf_pack_open_mem(const void* data, size_t size, RF_Pack** out) {
    const uint8_t* d = data;
    if (!d || !out || size < 32 || memcmp(d, "UDKL", 4)) { rf_set_error("pack: not a .udklib"); return RF_ERR_ARG; }
    if (r32(d + 28) != rf_crc32(d, 28)) { rf_set_error("pack: header CRC mismatch"); return RF_ERR_IO; }
    if (r32(d + 4) != 1) { rf_set_error("pack: unsupported version"); return RF_ERR_UNSUPPORTED; }
    uint32_t cnt = r32(d + 8), msz = r32(d + 12); uint64_t io = r64(d + 16);
    if (32 + (uint64_t)msz > size || io > size || io < 32 + (uint64_t)msz) { rf_set_error("pack: bad layout"); return RF_ERR_IO; }
    RF_Pack* p = rf_pack_new(); if (!p) return RF_ERR_NOMEM;
    p->blob = rf_alloc(size); if (!p->blob) { rf_pack_free(p); return RF_ERR_NOMEM; } memcpy(p->blob, d, size); d = p->blob;
    const uint8_t* m = d + 32; const uint8_t* me = m + msz;
    while (m < me) { const uint8_t* nl = memchr(m, '\n', (size_t)(me - m)); if (!nl) break; const uint8_t* eq = memchr(m, '=', (size_t)(nl - m));
        if (eq) { char* k = rf_alloc((size_t)(eq - m) + 1); char* v = rf_alloc((size_t)(nl - eq)); memcpy(k, m, (size_t)(eq - m)); memcpy(v, eq + 1, (size_t)(nl - eq - 1)); rf_pack_set_meta(p, k, v); rf_free(k); rf_free(v); }
        m = nl + 1; }
    const uint8_t* ix = d + io; const uint8_t* end = d + size;
    for (uint32_t i = 0; i < cnt; i++) {
        if (ix + 2 > end) goto bad; size_t nl = r16(ix); ix += 2; if (ix + nl + 4 + 28 > end) goto bad;
        char* name = rf_alloc(nl + 1); memcpy(name, ix, nl); ix += nl; uint32_t fl = r32(ix); ix += 4;
        uint64_t off = r64(ix), st = r64(ix + 8), og = r64(ix + 16); uint32_t crc = r32(ix + 24); ix += 28;
        if (off > size || st > size - off) { rf_free(name); goto bad; }
        if (p->n == p->cap) { size_t nc = p->cap ? p->cap * 2 : 8; Ent* ne = rf_realloc(p->e, nc * sizeof *ne); if (!ne) { rf_free(name); goto bad; } p->e = ne; p->cap = nc; }
        Ent* e = &p->e[p->n++]; e->name = name; e->data = (uint8_t*)d + off; e->stored = st; e->orig = og; e->crc = crc; e->flags = fl; e->owned = 0;
    }
    *out = p; return RF_OK;
bad: rf_pack_free(p); rf_set_error("pack: corrupt index"); return RF_ERR_IO;
}

/* ---- file helpers ---- */
static FILE* fopen8(const char* path, const char* mode) {
#ifdef _WIN32
    wchar_t* w; wchar_t m[8]; size_t i = 0; if (rf_utf8_to_utf16(path, &w) != RF_OK) return NULL;
    for (; mode[i] && i < 7; i++) m[i] = (wchar_t)mode[i]; m[i] = 0; FILE* f = _wfopen(w, m); rf_free(w); return f;
#else
    return fopen(path, mode);
#endif
}
RF_Status rf_pack_add_file(RF_Pack* p, const char* name, const char* path, int compress) {
    FILE* f = fopen8(path, "rb"); if (!f) { rf_set_error("cannot open %s", path); return RF_ERR_IO; }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); if (n < 0) { fclose(f); return RF_ERR_IO; }
    uint8_t* b = rf_alloc((size_t)n + 1); if (!b) { fclose(f); return RF_ERR_NOMEM; }
    size_t r = fread(b, 1, (size_t)n, f); fclose(f);
    RF_Status s = r == (size_t)n ? rf_pack_add(p, name, b, r, compress) : RF_ERR_IO; rf_free(b); return s;
}
RF_Status rf_pack_save_file(const RF_Pack* p, const char* path) {
    void* b; size_t n; RF_Status s = rf_pack_save_mem(p, &b, &n); if (s) return s;
    FILE* f = fopen8(path, "wb"); if (!f) { rf_free(b); return RF_ERR_IO; }
    s = fwrite(b, 1, n, f) == n ? RF_OK : RF_ERR_IO; fclose(f); rf_free(b); return s;
}
RF_Status rf_pack_open_file(const char* path, RF_Pack** out) {
    FILE* f = fopen8(path, "rb"); if (!f) { rf_set_error("cannot open %s", path); return RF_ERR_IO; }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); if (n < 0) { fclose(f); return RF_ERR_IO; }
    uint8_t* b = rf_alloc((size_t)n + 1); if (!b) { fclose(f); return RF_ERR_NOMEM; }
    size_t r = fread(b, 1, (size_t)n, f); fclose(f);
    RF_Status s = r == (size_t)n ? rf_pack_open_mem(b, r, out) : RF_ERR_IO; rf_free(b); return s;
}
