#define RF_AUDIO_BUILDING
#include "RF/Audio.h"
#include "RF/Core.h"
#include <windows.h>
#include <mmsystem.h>

RF_DEFINE_MODULE(RF_AUDIO_API, "RF.Audio.C", "C")

static void put16(uint8_t* p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put32(uint8_t* p, uint32_t v) { for (int i = 0; i < 4; i++) p[i] = (uint8_t)(v >> (8 * i)); }
RF_Status rf_audio_play_file(const char* p, int async) {
    wchar_t* w; RF_Status s = rf_utf8_to_utf16(p, &w); if (s) return s;
    BOOL ok = PlaySoundW(w, NULL, SND_FILENAME | (async ? SND_ASYNC : SND_SYNC)); rf_free(w); return ok ? RF_OK : RF_ERR_WINAPI;
}
RF_Status rf_audio_play_mem(const void* wav, int async) { return wav && PlaySoundW((LPCWSTR)wav, NULL, SND_MEMORY | (async ? SND_ASYNC : SND_SYNC)) ? RF_OK : RF_ERR_WINAPI; }
void rf_audio_stop(void) { PlaySoundW(NULL, NULL, 0); }
RF_Status rf_audio_beep(uint32_t f, uint32_t ms) { return Beep(f, ms) ? RF_OK : RF_ERR_WINAPI; }
RF_Status rf_audio_record_wav(uint32_t ms, uint32_t rate, void** out, size_t* size) {
    if (!out || !size || !ms || !rate) return RF_ERR_ARG;
    WAVEFORMATEX f; memset(&f, 0, sizeof f); f.wFormatTag = WAVE_FORMAT_PCM; f.nChannels = 1; f.nSamplesPerSec = rate; f.wBitsPerSample = 16; f.nBlockAlign = 2; f.nAvgBytesPerSec = rate * 2;
    size_t bytes = (size_t)((uint64_t)rate * ms / 1000) * 2; uint8_t* wav = rf_alloc(44 + bytes); if (!wav) return RF_ERR_NOMEM;
    HWAVEIN in; HANDLE ev = CreateEventW(NULL, FALSE, FALSE, NULL);
    if (waveInOpen(&in, WAVE_MAPPER, &f, (DWORD_PTR)ev, 0, CALLBACK_EVENT) != MMSYSERR_NOERROR) { rf_free(wav); CloseHandle(ev); rf_set_error("no microphone / waveInOpen failed"); return RF_ERR_WINAPI; }
    WAVEHDR h; memset(&h, 0, sizeof h); h.lpData = (LPSTR)(wav + 44); h.dwBufferLength = (DWORD)bytes;
    waveInPrepareHeader(in, &h, sizeof h); waveInAddBuffer(in, &h, sizeof h); waveInStart(in);
    while (!(h.dwFlags & WHDR_DONE)) WaitForSingleObject(ev, 100);
    waveInStop(in); waveInUnprepareHeader(in, &h, sizeof h); waveInClose(in); CloseHandle(ev);
    memcpy(wav, "RIFF", 4); put32(wav + 4, (uint32_t)((uint32_t)(36 + bytes))); memcpy(wav + 8, "WAVEfmt ", 8); put32(wav + 16, (uint32_t)(16));
    put16(wav + 20, (uint32_t)(1)); put16(wav + 22, (uint32_t)(1)); put32(wav + 24, (uint32_t)(rate)); put32(wav + 28, (uint32_t)(rate * 2)); put16(wav + 32, (uint32_t)(2)); put16(wav + 34, (uint32_t)(16));
    memcpy(wav + 36, "data", 4); put32(wav + 40, (uint32_t)((uint32_t)bytes)); *out = wav; *size = 44 + bytes; return RF_OK;
}
