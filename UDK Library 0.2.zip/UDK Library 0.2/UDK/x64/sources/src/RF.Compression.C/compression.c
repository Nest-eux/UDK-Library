#define RF_COMPRESSION_BUILDING
#include "RF/Compression.h"
#include "RF/Core.h"

RF_DEFINE_MODULE(RF_COMPRESSION_API, "RF.Compression.C", "C")

#define HBITS 14
static uint32_t rd32(const uint8_t* p) { return p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24; }
size_t rf_lz_bound(size_t n) { return n + n / 255 + 32; }

static uint8_t* ext(uint8_t* o, size_t v) { while (v >= 255) { *o++ = 255; v -= 255; } *o++ = (uint8_t)v; return o; }

RF_Status rf_lz_compress(const void* in, size_t n, void** out, size_t* out_n) {
    if ((!in && n) || !out || !out_n || n > 0xFFFFFFFFu) return RF_ERR_ARG;
    const uint8_t* src = in; uint8_t* dst = rf_alloc(rf_lz_bound(n) + 8); if (!dst) return RF_ERR_NOMEM;
    uint32_t* tbl = rf_alloc((1u << HBITS) * sizeof(uint32_t)); if (!tbl) { rf_free(dst); return RF_ERR_NOMEM; }
    memset(tbl, 0xFF, (1u << HBITS) * sizeof(uint32_t));
    memcpy(dst, "RFZ1", 4); dst[4] = (uint8_t)n; dst[5] = (uint8_t)(n >> 8); dst[6] = (uint8_t)(n >> 16); dst[7] = (uint8_t)(n >> 24);
    uint8_t* o = dst + 8; size_t ip = 0, anchor = 0;
    if (n >= 8) while (ip + 4 <= n) {
        uint32_t seq = rd32(src + ip), h = (seq * 2654435761u) >> (32 - HBITS), ref = tbl[h]; tbl[h] = (uint32_t)ip;
        if (ref != 0xFFFFFFFFu && ip - ref <= 65535 && rd32(src + ref) == seq) {
            size_t m = 4; while (ip + m < n && src[ref + m] == src[ip + m]) m++;
            size_t lit = ip - anchor, ml = m - 4;
            *o++ = (uint8_t)((lit >= 15 ? 15 : lit) << 4 | (ml >= 15 ? 15 : ml));
            if (lit >= 15) o = ext(o, lit - 15);
            memcpy(o, src + anchor, lit); o += lit;
            size_t off = ip - ref; *o++ = (uint8_t)off; *o++ = (uint8_t)(off >> 8);
            if (ml >= 15) o = ext(o, ml - 15);
            ip += m; anchor = ip;
        } else ip++;
    }
    size_t lit = n - anchor;
    *o++ = (uint8_t)((lit >= 15 ? 15 : lit) << 4); if (lit >= 15) o = ext(o, lit - 15);
    memcpy(o, src + anchor, lit); o += lit;
    rf_free(tbl); *out = dst; *out_n = (size_t)(o - dst); return RF_OK;
}

RF_Status rf_lz_decompress(const void* in, size_t n, void** out, size_t* out_n) {
    const uint8_t* s = in; if (!in || n < 8 || memcmp(s, "RFZ1", 4) || !out || !out_n) return RF_ERR_ARG;
    size_t osz = rd32(s + 4); uint8_t* d = rf_alloc(osz + 1); if (!d) return RF_ERR_NOMEM;
    size_t ip = 8, op = 0;
    while (ip < n) {
        uint8_t tok = s[ip++]; size_t lit = tok >> 4, ml = tok & 15;
        if (lit == 15) { uint8_t b; do { if (ip >= n) goto bad; b = s[ip++]; lit += b; } while (b == 255); }
        if (ip + lit > n || op + lit > osz) goto bad;
        memcpy(d + op, s + ip, lit); ip += lit; op += lit;
        if (ip >= n) break;
        if (ip + 2 > n) goto bad;
        size_t off = s[ip] | (size_t)s[ip + 1] << 8; ip += 2;
        if (ml == 15) { uint8_t b; do { if (ip >= n) goto bad; b = s[ip++]; ml += b; } while (b == 255); }
        ml += 4; if (!off || off > op || op + ml > osz) goto bad;
        for (size_t i = 0; i < ml; i++, op++) d[op] = d[op - off];
    }
    if (op != osz) goto bad;
    *out = d; *out_n = osz; return RF_OK;
bad: rf_free(d); rf_set_error("lz: corrupt data"); return RF_ERR_IO;
}
