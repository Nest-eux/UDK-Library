#define RF_REGEX_BUILDING
#include "RF/Regex.hpp"
#include <regex>
#include <string>
#include <cstring>
#include <cstdlib>

struct RFX_Regex { std::regex re; };
RF_DEFINE_MODULE(extern "C" RF_DLLEXPORT, "RF.Regex.Cpp", "CPP")

RFX_Regex* rfx_compile(const char* p, int ic) {
    if (!p) return nullptr;
    try { auto f = std::regex::ECMAScript; if (ic) f |= std::regex::icase; return new RFX_Regex{ std::regex(p, f) }; } catch (...) { return nullptr; }
}
void rfx_free(RFX_Regex* r) { delete r; }
int rfx_match_full(const RFX_Regex* r, const char* t) { return r && t && std::regex_match(t, r->re); }
int rfx_find(const RFX_Regex* r, const char* t, size_t start, RFX_Match* m) {
    if (!r || !t || start > std::strlen(t)) return 0;
    std::cmatch c; const char* b = t + start;
    if (!std::regex_search(b, c, r->re, start ? std::regex_constants::match_prev_avail : std::regex_constants::match_default)) return 0;
    if (m) { m->count = (int)std::min<size_t>(c.size(), 10); for (int i = 0; i < m->count; i++) { if (c[i].matched) { m->pos[i] = (int)(c[i].first - t); m->len[i] = (int)c[i].length(); } else { m->pos[i] = -1; m->len[i] = 0; } } }
    return 1;
}
char* rfx_replace(const RFX_Regex* r, const char* t, const char* rep) {
    if (!r || !t || !rep) return nullptr;
    try { std::string s = std::regex_replace(std::string(t), r->re, std::string(rep)); char* o = (char*)std::malloc(s.size() + 1); if (o) std::memcpy(o, s.c_str(), s.size() + 1); return o; } catch (...) { return nullptr; }
}
void rfx_free_string(char* s) { std::free(s); }
