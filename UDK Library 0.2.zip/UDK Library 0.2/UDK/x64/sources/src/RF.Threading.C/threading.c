#define RF_THREADING_BUILDING
#include "RF/Threading.h"
#include "RF/Core.h"
#include <windows.h>

RF_DEFINE_MODULE(RF_THREADING_API, "RF.Threading.C", "C")

struct RF_Thread { HANDLE h; RF_ThreadFn fn; void* arg; };
static DWORD WINAPI tmain(LPVOID p) { RF_Thread* t = p; t->fn(t->arg); return 0; }
RF_Thread* rf_thread_start(RF_ThreadFn fn, void* arg) {
    if (!fn) return NULL; RF_Thread* t = rf_alloc(sizeof *t); if (!t) return NULL; t->fn = fn; t->arg = arg;
    t->h = CreateThread(NULL, 0, tmain, t, 0, NULL); if (!t->h) { rf_free(t); return NULL; } return t;
}
void rf_thread_join(RF_Thread* t) { if (!t) return; WaitForSingleObject(t->h, INFINITE); CloseHandle(t->h); rf_free(t); }
uint32_t rf_thread_current_id(void) { return GetCurrentThreadId(); }

struct RF_Mutex { CRITICAL_SECTION cs; };
RF_Mutex* rf_mutex_new(void) { RF_Mutex* m = rf_alloc(sizeof *m); if (m) InitializeCriticalSection(&m->cs); return m; }
void rf_mutex_lock(RF_Mutex* m) { if (m) EnterCriticalSection(&m->cs); }
int rf_mutex_try_lock(RF_Mutex* m) { return m && TryEnterCriticalSection(&m->cs); }
void rf_mutex_unlock(RF_Mutex* m) { if (m) LeaveCriticalSection(&m->cs); }
void rf_mutex_free(RF_Mutex* m) { if (m) { DeleteCriticalSection(&m->cs); rf_free(m); } }

struct RF_Event { HANDLE h; };
RF_Event* rf_event_new(int manual, int init) { RF_Event* e = rf_alloc(sizeof *e); if (e) e->h = CreateEventW(NULL, manual != 0, init != 0, NULL); return e; }
void rf_event_set(RF_Event* e) { if (e) SetEvent(e->h); }
void rf_event_reset(RF_Event* e) { if (e) ResetEvent(e->h); }
int rf_event_wait(RF_Event* e, uint32_t ms) { return e && WaitForSingleObject(e->h, ms) == WAIT_OBJECT_0; }
void rf_event_free(RF_Event* e) { if (e) { CloseHandle(e->h); rf_free(e); } }

struct RF_Sem { HANDLE h; };
RF_Sem* rf_sem_new(int init, int max) { RF_Sem* s = rf_alloc(sizeof *s); if (s) s->h = CreateSemaphoreW(NULL, init, max, NULL); return s; }
int rf_sem_acquire(RF_Sem* s, uint32_t ms) { return s && WaitForSingleObject(s->h, ms) == WAIT_OBJECT_0; }
void rf_sem_release(RF_Sem* s) { if (s) ReleaseSemaphore(s->h, 1, NULL); }
void rf_sem_free(RF_Sem* s) { if (s) { CloseHandle(s->h); rf_free(s); } }

struct RF_Timer { HANDLE h; RF_ThreadFn cb; void* arg; };
static VOID CALLBACK tcb(PVOID p, BOOLEAN f) { (void)f; RF_Timer* t = p; t->cb(t->arg); }
RF_Timer* rf_timer_start(uint32_t ms, int repeat, RF_ThreadFn cb, void* arg) {
    if (!cb) return NULL; RF_Timer* t = rf_alloc(sizeof *t); if (!t) return NULL; t->cb = cb; t->arg = arg;
    if (!CreateTimerQueueTimer(&t->h, NULL, tcb, t, ms, repeat ? ms : 0, WT_EXECUTEDEFAULT)) { rf_free(t); return NULL; } return t;
}
void rf_timer_stop(RF_Timer* t) { if (!t) return; DeleteTimerQueueTimer(NULL, t->h, INVALID_HANDLE_VALUE); rf_free(t); }
void rf_sleep_ms(uint32_t ms) { Sleep(ms); }
uint64_t rf_ticks_ms(void) { return GetTickCount64(); }
double rf_clock_seconds(void) { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return (double)c.QuadPart / (double)f.QuadPart; }
