#define RF_IMAGE_BUILDING
#include "RF/Image.hpp"
#include <vector>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <cmath>

struct RFI_Image { int w, h; std::vector<uint8_t> px; };
RF_DEFINE_MODULE(extern "C" RF_DLLEXPORT, "RF.Image.Cpp", "CPP")

RFI_Image* rfi_create(int w, int h) { if (w <= 0 || h <= 0 || (uint64_t)w * h > 400000000ull) return nullptr; try { return new RFI_Image{ w, h, std::vector<uint8_t>((size_t)w * h * 4, 0) }; } catch (...) { return nullptr; } }
void rfi_free(RFI_Image* i) { delete i; }
int rfi_width(const RFI_Image* i) { return i ? i->w : 0; }
int rfi_height(const RFI_Image* i) { return i ? i->h : 0; }
uint8_t* rfi_pixels(RFI_Image* i) { return i ? i->px.data() : nullptr; }
void rfi_free_buffer(void* p) { std::free(p); }

static void put16(uint8_t* p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put32(uint8_t* p, uint32_t v) { for (int i = 0; i < 4; i++) p[i] = (uint8_t)(v >> (8 * i)); }
static uint32_t u32(const uint8_t* p) { return p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24; }
RFI_Image* rfi_load_bmp_mem(const void* data, size_t size) {
    const uint8_t* d = (const uint8_t*)data; if (!d || size < 54 || d[0] != 'B' || d[1] != 'M') return nullptr;
    uint32_t off = u32(d + 10), hs = u32(d + 14); int32_t w = (int32_t)u32(d + 18), h = (int32_t)u32(d + 22); uint16_t bpp = (uint16_t)(d[28] | d[29] << 8); uint32_t comp = u32(d + 30);
    if (hs < 40 || (bpp != 24 && bpp != 32) || (comp != 0 && comp != 3) || w <= 0 || h == 0) return nullptr;
    bool top = h < 0; int ah = top ? -h : h; size_t stride = ((size_t)w * bpp / 8 + 3) & ~(size_t)3;
    if (off > size || stride * ah > size - off) return nullptr;
    RFI_Image* im = rfi_create(w, ah); if (!im) return nullptr;
    for (int y = 0; y < ah; y++) {
        const uint8_t* s = d + off + stride * (top ? y : ah - 1 - y); uint8_t* o = &im->px[(size_t)y * w * 4];
        for (int x = 0; x < w; x++) { size_t k = (size_t)x * (bpp / 8); o[x*4] = s[k+2]; o[x*4+1] = s[k+1]; o[x*4+2] = s[k]; o[x*4+3] = bpp == 32 ? s[k+3] : 255; }
    }
    return im;
}
RF_Status rfi_save_bmp_mem(const RFI_Image* im, void** out, size_t* size) {
    if (!im || !out || !size) return RF_ERR_ARG; size_t stride = ((size_t)im->w * 3 + 3) & ~(size_t)3, img = stride * im->h, total = 54 + img;
    uint8_t* b = (uint8_t*)std::calloc(1, total); if (!b) return RF_ERR_NOMEM;
    std::memcpy(b, "BM", 2); put32(b + 2, (uint32_t)((uint32_t)total)); put32(b + 10, (uint32_t)(54)); put32(b + 14, (uint32_t)(40)); put32(b + 18, (uint32_t)(im->w)); put32(b + 22, (uint32_t)(im->h));
    put16(b + 26, (uint32_t)(1)); put16(b + 28, (uint32_t)(24)); put32(b + 34, (uint32_t)((uint32_t)img));
    for (int y = 0; y < im->h; y++) { uint8_t* o = b + 54 + stride * (im->h - 1 - y); const uint8_t* s = &im->px[(size_t)y * im->w * 4];
        for (int x = 0; x < im->w; x++) { o[x*3] = s[x*4+2]; o[x*3+1] = s[x*4+1]; o[x*3+2] = s[x*4]; } }
    *out = b; *size = total; return RF_OK;
}
RFI_Image* rfi_resize(const RFI_Image* im, int nw, int nh) {
    if (!im) return nullptr; RFI_Image* r = rfi_create(nw, nh); if (!r) return nullptr;
    for (int y = 0; y < nh; y++) {
        float fy = nh > 1 ? (float)y * (im->h - 1) / (nh - 1) : 0; int y0 = (int)fy, y1 = std::min(y0 + 1, im->h - 1); float ty = fy - y0;
        for (int x = 0; x < nw; x++) {
            float fx = nw > 1 ? (float)x * (im->w - 1) / (nw - 1) : 0; int x0 = (int)fx, x1 = std::min(x0 + 1, im->w - 1); float tx = fx - x0;
            for (int c = 0; c < 4; c++) {
                float a = im->px[((size_t)y0 * im->w + x0) * 4 + c] * (1 - tx) + im->px[((size_t)y0 * im->w + x1) * 4 + c] * tx;
                float b = im->px[((size_t)y1 * im->w + x0) * 4 + c] * (1 - tx) + im->px[((size_t)y1 * im->w + x1) * 4 + c] * tx;
                r->px[((size_t)y * nw + x) * 4 + c] = (uint8_t)std::lround(a * (1 - ty) + b * ty);
            }
        }
    }
    return r;
}
RFI_Image* rfi_crop(const RFI_Image* im, int x, int y, int w, int h) {
    if (!im || x < 0 || y < 0 || w <= 0 || h <= 0 || x + w > im->w || y + h > im->h) return nullptr; RFI_Image* r = rfi_create(w, h); if (!r) return nullptr;
    for (int j = 0; j < h; j++) std::memcpy(&r->px[(size_t)j * w * 4], &im->px[((size_t)(y + j) * im->w + x) * 4], (size_t)w * 4); return r;
}
void rfi_grayscale(RFI_Image* im) { if (!im) return; for (size_t i = 0; i < im->px.size(); i += 4) { uint8_t g = (uint8_t)((im->px[i] * 299 + im->px[i+1] * 587 + im->px[i+2] * 114) / 1000); im->px[i] = im->px[i+1] = im->px[i+2] = g; } }
void rfi_flip(RFI_Image* im, int vertical) {
    if (!im) return;
    if (vertical) for (int y = 0; y < im->h / 2; y++) std::swap_ranges(im->px.begin() + (size_t)y * im->w * 4, im->px.begin() + (size_t)(y + 1) * im->w * 4, im->px.begin() + (size_t)(im->h - 1 - y) * im->w * 4);
    else for (int y = 0; y < im->h; y++) for (int x = 0; x < im->w / 2; x++) for (int c = 0; c < 4; c++) std::swap(im->px[((size_t)y * im->w + x) * 4 + c], im->px[((size_t)y * im->w + im->w - 1 - x) * 4 + c]);
}
