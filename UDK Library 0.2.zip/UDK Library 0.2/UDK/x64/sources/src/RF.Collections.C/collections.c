#define RF_COLLECTIONS_BUILDING
#include "RF/Collections.h"
#include "RF/Core.h"
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

RF_DEFINE_MODULE(RF_COLLECTIONS_API, "RF.Collections.C", "C")

/* ---------- Vec ---------- */
struct RF_Vec { uint8_t* data; size_t len, cap, esz; };
RF_Vec* rf_vec_new(size_t esz) {
    if (!esz) return NULL;
    RF_Vec* v = rf_alloc(sizeof *v); if (v) v->esz = esz; return v;
}
void rf_vec_free(RF_Vec* v) { if (v) { rf_free(v->data); rf_free(v); } }
size_t rf_vec_len(const RF_Vec* v) { return v ? v->len : 0; }
RF_Status rf_vec_push(RF_Vec* v, const void* e) {
    if (!v || !e) return RF_ERR_ARG;
    if (v->len == v->cap) {
        size_t nc = v->cap ? v->cap * 2 : 8;
        uint8_t* nd = rf_realloc(v->data, nc * v->esz); if (!nd) return RF_ERR_NOMEM;
        v->data = nd; v->cap = nc;
    }
    memcpy(v->data + v->len * v->esz, e, v->esz); v->len++; return RF_OK;
}
void* rf_vec_at(RF_Vec* v, size_t i) { return (v && i < v->len) ? v->data + i * v->esz : NULL; }
RF_Status rf_vec_pop(RF_Vec* v, void* out) {
    if (!v || !v->len) return RF_ERR_ARG;
    v->len--; if (out) memcpy(out, v->data + v->len * v->esz, v->esz); return RF_OK;
}
RF_Status rf_vec_remove(RF_Vec* v, size_t i) {
    if (!v || i >= v->len) return RF_ERR_ARG;
    memmove(v->data + i * v->esz, v->data + (i + 1) * v->esz, (v->len - i - 1) * v->esz); v->len--; return RF_OK;
}
void rf_vec_clear(RF_Vec* v) { if (v) v->len = 0; }

/* ---------- Map ---------- */
typedef struct Node { char* key; void* val; struct Node* next; uint64_t h; } Node;
struct RF_Map { Node** b; size_t nb, count; };
static uint64_t hs(const char* s) { return rf_fnv1a64(s, strlen(s)); }
RF_Map* rf_map_new(void) {
    RF_Map* m = rf_alloc(sizeof *m); if (!m) return NULL;
    m->nb = 16; m->b = rf_alloc(m->nb * sizeof(Node*)); if (!m->b) { rf_free(m); return NULL; } return m;
}
void rf_map_free(RF_Map* m) {
    if (!m) return;
    for (size_t i = 0; i < m->nb; i++) for (Node* n = m->b[i]; n;) { Node* x = n->next; rf_free(n->key); rf_free(n); n = x; }
    rf_free(m->b); rf_free(m);
}
static Node* find(const RF_Map* m, const char* k, uint64_t h) {
    for (Node* n = m->b[h % m->nb]; n; n = n->next) if (n->h == h && !strcmp(n->key, k)) return n;
    return NULL;
}
static int grow(RF_Map* m) {
    size_t nn = m->nb * 2; Node** nb = rf_alloc(nn * sizeof(Node*)); if (!nb) return 0;
    for (size_t i = 0; i < m->nb; i++) for (Node* n = m->b[i]; n;) { Node* x = n->next; n->next = nb[n->h % nn]; nb[n->h % nn] = n; n = x; }
    rf_free(m->b); m->b = nb; m->nb = nn; return 1;
}
RF_Status rf_map_set(RF_Map* m, const char* k, void* v) {
    if (!m || !k) return RF_ERR_ARG;
    uint64_t h = hs(k); Node* n = find(m, k, h);
    if (n) { n->val = v; return RF_OK; }
    if (m->count * 4 > m->nb * 3 && !grow(m)) return RF_ERR_NOMEM;
    n = rf_alloc(sizeof *n); if (!n) return RF_ERR_NOMEM;
    n->key = rf_strdup(k); n->val = v; n->h = h; n->next = m->b[h % m->nb]; m->b[h % m->nb] = n; m->count++; return RF_OK;
}
void* rf_map_get(const RF_Map* m, const char* k) { if (!m || !k) return NULL; Node* n = find(m, k, hs(k)); return n ? n->val : NULL; }
int rf_map_has(const RF_Map* m, const char* k) { return m && k && find(m, k, hs(k)) != NULL; }
RF_Status rf_map_remove(RF_Map* m, const char* k) {
    if (!m || !k) return RF_ERR_ARG;
    uint64_t h = hs(k);
    for (Node** p = &m->b[h % m->nb]; *p; p = &(*p)->next)
        if ((*p)->h == h && !strcmp((*p)->key, k)) { Node* d = *p; *p = d->next; rf_free(d->key); rf_free(d); m->count--; return RF_OK; }
    return RF_ERR_NOTFOUND;
}
size_t rf_map_count(const RF_Map* m) { return m ? m->count : 0; }
void rf_map_foreach(const RF_Map* m, RF_MapIter cb, void* user) {
    if (!m || !cb) return;
    for (size_t i = 0; i < m->nb; i++) for (Node* n = m->b[i]; n; n = n->next) if (!cb(n->key, n->val, user)) return;
}

/* ---------- StrBuf ---------- */
struct RF_StrBuf { char* s; size_t len, cap; };
RF_StrBuf* rf_sb_new(void) {
    RF_StrBuf* b = rf_alloc(sizeof *b); if (!b) return NULL;
    b->cap = 64; b->s = rf_alloc(b->cap); if (!b->s) { rf_free(b); return NULL; } return b;
}
void rf_sb_free(RF_StrBuf* b) { if (b) { rf_free(b->s); rf_free(b); } }
static RF_Status reserve(RF_StrBuf* b, size_t extra) {
    if (b->len + extra + 1 <= b->cap) return RF_OK;
    size_t nc = b->cap; while (nc < b->len + extra + 1) nc *= 2;
    char* n = rf_realloc(b->s, nc); if (!n) return RF_ERR_NOMEM; b->s = n; b->cap = nc; return RF_OK;
}
RF_Status rf_sb_append(RF_StrBuf* b, const char* s) {
    if (!b || !s) return RF_ERR_ARG; size_t n = strlen(s);
    RF_Status r = reserve(b, n); if (r) return r;
    memcpy(b->s + b->len, s, n + 1); b->len += n; return RF_OK;
}
RF_Status rf_sb_appendf(RF_StrBuf* b, const char* fmt, ...) {
    if (!b || !fmt) return RF_ERR_ARG;
    va_list a, a2; va_start(a, fmt); va_copy(a2, a);
    int n = vsnprintf(NULL, 0, fmt, a); va_end(a);
    if (n < 0) { va_end(a2); return RF_ERR_GENERIC; }
    RF_Status r = reserve(b, (size_t)n);
    if (!r) { vsnprintf(b->s + b->len, (size_t)n + 1, fmt, a2); b->len += (size_t)n; }
    va_end(a2); return r;
}
const char* rf_sb_cstr(const RF_StrBuf* b) { return b ? b->s : ""; }
size_t rf_sb_len(const RF_StrBuf* b) { return b ? b->len : 0; }
char* rf_sb_detach(RF_StrBuf* b) { if (!b) return NULL; char* s = b->s; rf_free(b); return s; }
