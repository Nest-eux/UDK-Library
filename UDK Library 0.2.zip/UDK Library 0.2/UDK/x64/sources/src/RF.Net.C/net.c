#define RF_NET_BUILDING
#include "RF/Net.h"
#include "RF/Core.h"
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <winhttp.h>
#include <stdio.h>

RF_DEFINE_MODULE(RF_NET_API, "RF.Net.C", "C")

struct RF_Socket { SOCKET s; };
static INIT_ONCE once = INIT_ONCE_STATIC_INIT;
static BOOL CALLBACK do_init(PINIT_ONCE o, PVOID p, PVOID* c) { (void)o; (void)p; (void)c; WSADATA d; return WSAStartup(MAKEWORD(2, 2), &d) == 0; }
static int ensure(void) { return InitOnceExecuteOnce(&once, do_init, NULL, NULL); }
static RF_Socket* wrap(SOCKET s) { RF_Socket* r = rf_alloc(sizeof *r); if (!r) { closesocket(s); return NULL; } r->s = s; return r; }
static RF_Status serr(const char* w) { rf_set_error("%s failed (WSA %d)", w, WSAGetLastError()); return RF_ERR_IO; }

RF_Status rf_tcp_connect(const char* host, uint16_t port, RF_Socket** out) {
    if (!host || !out || !ensure()) return RF_ERR_ARG; char ps[8]; snprintf(ps, sizeof ps, "%u", port);
    struct addrinfo h, *res = NULL; memset(&h, 0, sizeof h); h.ai_socktype = SOCK_STREAM; h.ai_family = AF_UNSPEC;
    if (getaddrinfo(host, ps, &h, &res)) return serr("getaddrinfo");
    for (struct addrinfo* a = res; a; a = a->ai_next) {
        SOCKET s = socket(a->ai_family, a->ai_socktype, a->ai_protocol); if (s == INVALID_SOCKET) continue;
        if (connect(s, a->ai_addr, (int)a->ai_addrlen) == 0) { freeaddrinfo(res); *out = wrap(s); return *out ? RF_OK : RF_ERR_NOMEM; }
        closesocket(s);
    }
    freeaddrinfo(res); return serr("connect");
}
RF_Status rf_tcp_listen(uint16_t port, int backlog, RF_Socket** out) {
    if (!out || !ensure()) return RF_ERR_ARG; SOCKET s = socket(AF_INET, SOCK_STREAM, 0); if (s == INVALID_SOCKET) return serr("socket");
    BOOL one = TRUE; setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (const char*)&one, sizeof one);
    struct sockaddr_in a; memset(&a, 0, sizeof a); a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_ANY); a.sin_port = htons(port);
    if (bind(s, (struct sockaddr*)&a, sizeof a) || listen(s, backlog > 0 ? backlog : 16)) { RF_Status e = serr("bind/listen"); closesocket(s); return e; }
    *out = wrap(s); return *out ? RF_OK : RF_ERR_NOMEM;
}
RF_Status rf_tcp_accept(RF_Socket* l, RF_Socket** c) {
    if (!l || !c) return RF_ERR_ARG; SOCKET s = accept(l->s, NULL, NULL); if (s == INVALID_SOCKET) return serr("accept");
    *c = wrap(s); return *c ? RF_OK : RF_ERR_NOMEM;
}
int rf_sock_send(RF_Socket* s, const void* d, size_t n) { if (!s) return -1; int r = send(s->s, d, (int)n, 0); return r == SOCKET_ERROR ? -1 : r; }
int rf_sock_recv(RF_Socket* s, void* b, size_t n) { if (!s) return -1; int r = recv(s->s, b, (int)n, 0); return r == SOCKET_ERROR ? -1 : r; }
RF_Status rf_sock_set_timeout(RF_Socket* s, uint32_t ms) { if (!s) return RF_ERR_ARG; DWORD t = ms; setsockopt(s->s, SOL_SOCKET, SO_RCVTIMEO, (const char*)&t, sizeof t); setsockopt(s->s, SOL_SOCKET, SO_SNDTIMEO, (const char*)&t, sizeof t); return RF_OK; }
void rf_sock_close(RF_Socket* s) { if (s) { closesocket(s->s); rf_free(s); } }

RF_Status rf_udp_open(uint16_t port, RF_Socket** out) {
    if (!out || !ensure()) return RF_ERR_ARG; SOCKET s = socket(AF_INET, SOCK_DGRAM, 0); if (s == INVALID_SOCKET) return serr("socket");
    struct sockaddr_in a; memset(&a, 0, sizeof a); a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_ANY); a.sin_port = htons(port);
    if (bind(s, (struct sockaddr*)&a, sizeof a)) { RF_Status e = serr("bind"); closesocket(s); return e; }
    *out = wrap(s); return *out ? RF_OK : RF_ERR_NOMEM;
}
int rf_udp_sendto(RF_Socket* s, const char* host, uint16_t port, const void* d, size_t n) {
    if (!s || !host) return -1; char ps[8]; snprintf(ps, sizeof ps, "%u", port);
    struct addrinfo h, *res = NULL; memset(&h, 0, sizeof h); h.ai_family = AF_INET; h.ai_socktype = SOCK_DGRAM; if (getaddrinfo(host, ps, &h, &res)) return -1;
    int r = sendto(s->s, d, (int)n, 0, res->ai_addr, (int)res->ai_addrlen); freeaddrinfo(res); return r == SOCKET_ERROR ? -1 : r;
}
int rf_udp_recvfrom(RF_Socket* s, void* b, size_t n, char* fh, size_t hs, uint16_t* fp) {
    if (!s) return -1; struct sockaddr_in a; int l = sizeof a; int r = recvfrom(s->s, b, (int)n, 0, (struct sockaddr*)&a, &l); if (r == SOCKET_ERROR) return -1;
    if (fh && hs) { const char* t = inet_ntoa(a.sin_addr); strncpy(fh, t ? t : "", hs - 1); fh[hs - 1] = 0; } if (fp) *fp = ntohs(a.sin_port); return r;
}

RF_Status rf_http_request(const char* method, const char* url, const char* headers, const void* body, size_t blen, int* status, void** resp, size_t* rlen) {
    if (!method || !url || !resp || !rlen) return RF_ERR_ARG; RF_Status st = RF_ERR_IO;
    wchar_t *wm = NULL, *wu = NULL, *wh = NULL; HINTERNET hs = NULL, hc = NULL, hr = NULL; wchar_t host[256], path[2048]; URL_COMPONENTS uc; uint8_t* data = NULL; size_t n = 0;
    if (rf_utf8_to_utf16(method, &wm) || rf_utf8_to_utf16(url, &wu)) { st = RF_ERR_ARG; goto done; }
    if (headers && rf_utf8_to_utf16(headers, &wh)) { st = RF_ERR_ARG; goto done; }
    memset(&uc, 0, sizeof uc); uc.dwStructSize = sizeof uc; uc.lpszHostName = host; uc.dwHostNameLength = 256; uc.lpszUrlPath = path; uc.dwUrlPathLength = 2048;
    uc.dwExtraInfoLength = (DWORD)-1;
    if (!WinHttpCrackUrl(wu, 0, 0, &uc)) { rf_set_error("bad url"); st = RF_ERR_ARG; goto done; }
    if (uc.dwExtraInfoLength && uc.lpszExtraInfo) { size_t pl = wcslen(path), el = uc.dwExtraInfoLength; if (pl + el < 2047) { memcpy(path + pl, uc.lpszExtraInfo, el * sizeof(wchar_t)); path[pl + el] = 0; } }
    hs = WinHttpOpen(L"RF-UDK/0.1", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, NULL, NULL, 0); if (!hs) goto done;
    hc = WinHttpConnect(hs, host, uc.nPort, 0); if (!hc) goto done;
    hr = WinHttpOpenRequest(hc, wm, path, NULL, NULL, NULL, uc.nScheme == INTERNET_SCHEME_HTTPS ? WINHTTP_FLAG_SECURE : 0); if (!hr) goto done;
    if (!WinHttpSendRequest(hr, wh ? wh : WINHTTP_NO_ADDITIONAL_HEADERS, wh ? (DWORD)-1L : 0, (LPVOID)body, (DWORD)blen, (DWORD)blen, 0) || !WinHttpReceiveResponse(hr, NULL)) { rf_set_error("http failed (%lu)", GetLastError()); goto done; }
    if (status) { DWORD c = 0, sz = sizeof c; WinHttpQueryHeaders(hr, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, NULL, &c, &sz, NULL); *status = (int)c; }
    { size_t cap = 4096; data = rf_alloc(cap + 1); if (!data) { st = RF_ERR_NOMEM; goto done; } DWORD got;
      for (;;) { if (n + 4096 > cap) { cap *= 2; uint8_t* nd = rf_realloc(data, cap + 1); if (!nd) { st = RF_ERR_NOMEM; goto done; } data = nd; }
        if (!WinHttpReadData(hr, data + n, 4096, &got)) goto done; if (!got) break; n += got; }
      data[n] = 0; *resp = data; *rlen = n; data = NULL; st = RF_OK; }
done:
    rf_free(data); rf_free(wm); rf_free(wu); rf_free(wh);
    if (hr) WinHttpCloseHandle(hr); if (hc) WinHttpCloseHandle(hc); if (hs) WinHttpCloseHandle(hs); return st;
}
