#define RF_CORE_BUILDING
#include "RF/Core.h"
#include <windows.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

static RF_LogCallback g_cb; static void* g_cb_user;
static __thread char g_err[256];

RF_DEFINE_MODULE(RF_CORE_API, "RF.Core.C", "C")
const char* rf_version(void) { return "RF UDK 0.1.0"; }

const char* rf_last_error(void) { return g_err; }
void rf_set_error(const char* fmt, ...) {
    va_list a; va_start(a, fmt); vsnprintf(g_err, sizeof g_err, fmt, a); va_end(a);
}

void* rf_alloc(size_t n) { return calloc(1, n ? n : 1); }
void* rf_realloc(void* p, size_t n) { return realloc(p, n); }
void  rf_free(void* p) { free(p); }

RF_Status rf_utf8_to_utf16(const char* s, wchar_t** out) {
    if (!s || !out) return RF_ERR_ARG;
    int n = MultiByteToWideChar(CP_UTF8, 0, s, -1, NULL, 0);
    if (n <= 0) { rf_set_error("utf8->utf16 failed (%lu)", GetLastError()); return RF_ERR_WINAPI; }
    wchar_t* w = rf_alloc((size_t)n * sizeof(wchar_t));
    if (!w) return RF_ERR_NOMEM;
    MultiByteToWideChar(CP_UTF8, 0, s, -1, w, n);
    *out = w; return RF_OK;
}
RF_Status rf_utf16_to_utf8(const wchar_t* s, char** out) {
    if (!s || !out) return RF_ERR_ARG;
    int n = WideCharToMultiByte(CP_UTF8, 0, s, -1, NULL, 0, NULL, NULL);
    if (n <= 0) { rf_set_error("utf16->utf8 failed (%lu)", GetLastError()); return RF_ERR_WINAPI; }
    char* c = rf_alloc((size_t)n);
    if (!c) return RF_ERR_NOMEM;
    WideCharToMultiByte(CP_UTF8, 0, s, -1, c, n, NULL, NULL);
    *out = c; return RF_OK;
}
char* rf_strdup(const char* s) {
    if (!s) return NULL;
    size_t n = strlen(s) + 1; char* d = rf_alloc(n);
    if (d) memcpy(d, s, n);
    return d;
}

void rf_log_set_callback(RF_LogCallback cb, void* user) { g_cb = cb; g_cb_user = user; }
void rf_log(RF_LogLevel lvl, const char* fmt, ...) {
    char buf[1024]; va_list a; va_start(a, fmt); vsnprintf(buf, sizeof buf, fmt, a); va_end(a);
    if (g_cb) g_cb(lvl, buf, g_cb_user);
    else { static const char* n[] = {"DEBUG","INFO","WARN","ERROR"}; fprintf(stderr, "[RF %s] %s\n", n[lvl], buf); }
}

uint32_t rf_crc32(const void* data, size_t n) {
    const uint8_t* p = data; uint32_t c = 0xFFFFFFFFu;
    for (size_t i = 0; i < n; i++) {
        c ^= p[i];
        for (int k = 0; k < 8; k++) c = (c >> 1) ^ (0xEDB88320u & (uint32_t)-(int32_t)(c & 1));
    }
    return ~c;
}
uint64_t rf_fnv1a64(const void* data, size_t n) {
    const uint8_t* p = data; uint64_t h = 1469598103934665603ULL;
    for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 1099511628211ULL; }
    return h;
}

struct RF_Module { HMODULE h; };

RF_Status rf_module_load(const char* path, RF_Module** out) {
    wchar_t* w; RF_Status s = rf_utf8_to_utf16(path, &w);
    if (s != RF_OK) return s;
    HMODULE h = LoadLibraryW(w); rf_free(w);
    if (!h) { rf_set_error("LoadLibrary failed (%lu)", GetLastError()); return RF_ERR_NOTFOUND; }
    if (!GetProcAddress(h, "RF_GetModuleInfo")) {
        FreeLibrary(h); rf_set_error("not an RF module (no RF_GetModuleInfo)"); return RF_ERR_UNSUPPORTED;
    }
    RF_Module* m = rf_alloc(sizeof *m); if (!m) { FreeLibrary(h); return RF_ERR_NOMEM; }
    m->h = h; *out = m; return RF_OK;
}
RF_Status rf_module_info(RF_Module* m, RF_ModuleInfo* out) {
    if (!m || !out) return RF_ERR_ARG;
    RF_GetModuleInfoFn f = (RF_GetModuleInfoFn)(void*)GetProcAddress(m->h, "RF_GetModuleInfo");
    return f ? (RF_Status)f(out) : RF_ERR_UNSUPPORTED;
}
void* rf_module_symbol(RF_Module* m, const char* name) {
    return (m && name) ? (void*)GetProcAddress(m->h, name) : NULL;
}
void rf_module_unload(RF_Module* m) { if (m) { FreeLibrary(m->h); rf_free(m); } }
