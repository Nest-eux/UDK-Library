#define RF_TEXT_BUILDING
#include "RF/Text.h"
#include "RF/Core.h"
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

RF_DEFINE_MODULE(RF_TEXT_API, "RF.Text.C", "C")

static const char B64[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
char* rf_base64_encode(const void* data, size_t n) {
    const uint8_t* p = data; char* o = rf_alloc(((n + 2) / 3) * 4 + 1); if (!o) return NULL; char* w = o;
    for (size_t i = 0; i < n; i += 3) {
        uint32_t v = (uint32_t)p[i] << 16 | (i + 1 < n ? (uint32_t)p[i + 1] << 8 : 0) | (i + 2 < n ? p[i + 2] : 0);
        *w++ = B64[v >> 18 & 63]; *w++ = B64[v >> 12 & 63];
        *w++ = i + 1 < n ? B64[v >> 6 & 63] : '='; *w++ = i + 2 < n ? B64[v & 63] : '=';
    }
    return o;
}
static int b64v(char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A'; if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52; if (c == '+') return 62; if (c == '/') return 63; return -1;
}
RF_Status rf_base64_decode(const char* s, void** out, size_t* n) {
    if (!s || !out || !n) return RF_ERR_ARG;
    size_t len = strlen(s); uint8_t* o = rf_alloc(len / 4 * 3 + 3); if (!o) return RF_ERR_NOMEM;
    size_t w = 0; uint32_t acc = 0; int bits = 0;
    for (size_t i = 0; i < len; i++) {
        if (s[i] == '=' ) break; if (s[i] == '\n' || s[i] == '\r' || s[i] == ' ') continue;
        int v = b64v(s[i]); if (v < 0) { rf_free(o); return RF_ERR_ARG; }
        acc = acc << 6 | (uint32_t)v; bits += 6;
        if (bits >= 8) { bits -= 8; o[w++] = (uint8_t)(acc >> bits); }
    }
    *out = o; *n = w; return RF_OK;
}
char* rf_hex_encode(const void* data, size_t n) {
    static const char H[] = "0123456789abcdef"; const uint8_t* p = data; char* o = rf_alloc(n * 2 + 1); if (!o) return NULL;
    for (size_t i = 0; i < n; i++) { o[i * 2] = H[p[i] >> 4]; o[i * 2 + 1] = H[p[i] & 15]; } return o;
}
static int hv(char c) { if (c >= '0' && c <= '9') return c - '0'; if (c >= 'a' && c <= 'f') return c - 'a' + 10; if (c >= 'A' && c <= 'F') return c - 'A' + 10; return -1; }
RF_Status rf_hex_decode(const char* s, void** out, size_t* n) {
    if (!s || !out || !n) return RF_ERR_ARG; size_t len = strlen(s); if (len & 1) return RF_ERR_ARG;
    uint8_t* o = rf_alloc(len / 2 + 1); if (!o) return RF_ERR_NOMEM;
    for (size_t i = 0; i < len; i += 2) { int a = hv(s[i]), b = hv(s[i + 1]); if (a < 0 || b < 0) { rf_free(o); return RF_ERR_ARG; } o[i / 2] = (uint8_t)(a << 4 | b); }
    *out = o; *n = len / 2; return RF_OK;
}
char* rf_str_trim(const char* s) {
    if (!s) return NULL; while (*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n') s++;
    size_t n = strlen(s); while (n && (s[n-1] == ' ' || s[n-1] == '\t' || s[n-1] == '\r' || s[n-1] == '\n')) n--;
    char* o = rf_alloc(n + 1); if (o) memcpy(o, s, n); return o;
}
char* rf_str_lower(const char* s) { char* o = rf_strdup(s); if (o) for (char* p = o; *p; p++) if (*p >= 'A' && *p <= 'Z') *p += 32; return o; }
char* rf_str_upper(const char* s) { char* o = rf_strdup(s); if (o) for (char* p = o; *p; p++) if (*p >= 'a' && *p <= 'z') *p -= 32; return o; }
char* rf_str_replace(const char* s, const char* from, const char* to) {
    if (!s || !from || !*from || !to) return rf_strdup(s);
    size_t fl = strlen(from), tl = strlen(to), cnt = 0;
    for (const char* p = s; (p = strstr(p, from)); p += fl) cnt++;
    char* o = rf_alloc(strlen(s) + cnt * (tl > fl ? tl - fl : 0) + 1); if (!o) return NULL; char* w = o;
    for (;;) { const char* p = strstr(s, from); if (!p) { strcpy(w, s); break; }
        memcpy(w, s, (size_t)(p - s)); w += p - s; memcpy(w, to, tl); w += tl; s = p + fl; }
    return o;
}
char* rf_str_format(const char* fmt, ...) {
    va_list a, b; va_start(a, fmt); va_copy(b, a); int n = vsnprintf(NULL, 0, fmt, a); va_end(a);
    char* o = n < 0 ? NULL : rf_alloc((size_t)n + 1); if (o) vsnprintf(o, (size_t)n + 1, fmt, b); va_end(b); return o;
}
char** rf_str_split(const char* s, char sep, size_t* count) {
    if (!s || !count) return NULL; size_t n = 1; for (const char* p = s; *p; p++) if (*p == sep) n++;
    char** r = rf_alloc(n * sizeof(char*)); if (!r) return NULL; size_t i = 0; const char* st = s;
    for (const char* p = s;; p++) if (*p == sep || !*p) {
        size_t l = (size_t)(p - st); r[i] = rf_alloc(l + 1); if (r[i]) memcpy(r[i], st, l); i++; st = p + 1; if (!*p) break; }
    *count = n; return r;
}
void rf_str_split_free(char** parts, size_t count) { if (!parts) return; for (size_t i = 0; i < count; i++) rf_free(parts[i]); rf_free(parts); }
int rf_str_starts_with(const char* s, const char* p) { return s && p && !strncmp(s, p, strlen(p)); }
int rf_str_ends_with(const char* s, const char* x) { if (!s || !x) return 0; size_t a = strlen(s), b = strlen(x); return b <= a && !strcmp(s + a - b, x); }
int rf_utf8_valid(const char* s) {
    const uint8_t* p = (const uint8_t*)s; if (!p) return 0;
    while (*p) {
        int n; uint32_t c = *p;
        if (c < 0x80) { p++; continue; } else if ((c >> 5) == 6) { n = 1; c &= 31; } else if ((c >> 4) == 14) { n = 2; c &= 15; } else if ((c >> 3) == 30) { n = 3; c &= 7; } else return 0;
        for (int i = 1; i <= n; i++) { if ((p[i] >> 6) != 2) return 0; c = c << 6 | (p[i] & 63); }
        if ((n == 1 && c < 0x80) || (n == 2 && c < 0x800) || (n == 3 && c < 0x10000) || c > 0x10FFFF || (c >= 0xD800 && c <= 0xDFFF)) return 0;
        p += n + 1;
    }
    return 1;
}
size_t rf_utf8_length(const char* s) { size_t n = 0; if (!s) return 0; for (; *s; s++) if (((uint8_t)*s & 0xC0) != 0x80) n++; return n; }
