#define RF_WIN32UI_BUILDING
#include "RF/Win32UI.h"
#include "RF/Core.h"
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>

RF_DEFINE_MODULE(RF_WIN32UI_API, "RF.Win32UI.C", "C")

struct RF_Window { HWND hwnd; RF_UIEvent cb; void* user; };
static const wchar_t* CLS = L"RFWin32UIWindow";
static HFONT g_font;
static LRESULT CALLBACK wp(HWND h, UINT m, WPARAM w, LPARAM l) {
    RF_Window* win = (RF_Window*)GetWindowLongPtrW(h, GWLP_USERDATA);
    if (win && win->cb) {
        if (m == WM_COMMAND && l) { int code = HIWORD(w); if (code == BN_CLICKED || code == EN_CHANGE || code == LBN_SELCHANGE) win->cb(LOWORD(w), 0, win->user); }
        else if (m == WM_CLOSE) win->cb(0, 1, win->user);
    }
    if (m == WM_DESTROY) { PostQuitMessage(0); return 0; }
    return DefWindowProcW(h, m, w, l);
}
RF_Window* rf_ui_window_create(const char* title, int w, int h, RF_UIEvent cb, void* user) {
    static int reg; INITCOMMONCONTROLSEX ic = { sizeof ic, ICC_PROGRESS_CLASS | ICC_STANDARD_CLASSES }; InitCommonControlsEx(&ic);
    if (!reg) { WNDCLASSW c; memset(&c, 0, sizeof c); c.lpfnWndProc = wp; c.hInstance = GetModuleHandleW(NULL); c.hCursor = LoadCursorW(NULL, (LPCWSTR)IDC_ARROW); c.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1); c.lpszClassName = CLS; if (!RegisterClassW(&c)) return NULL; reg = 1;
        g_font = (HFONT)GetStockObject(DEFAULT_GUI_FONT); }
    wchar_t* t; if (rf_utf8_to_utf16(title ? title : "", &t)) return NULL; RF_Window* r = rf_alloc(sizeof *r); if (!r) { rf_free(t); return NULL; }
    r->cb = cb; r->user = user; r->hwnd = CreateWindowExW(0, CLS, t, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, w, h, NULL, NULL, GetModuleHandleW(NULL), NULL); rf_free(t);
    if (!r->hwnd) { rf_free(r); return NULL; } SetWindowLongPtrW(r->hwnd, GWLP_USERDATA, (LONG_PTR)r); return r;
}
static RF_Status add(RF_Window* w, const wchar_t* cls, int id, const char* text, DWORD style, int x, int y, int cw, int ch, DWORD ex) {
    if (!w) return RF_ERR_ARG; wchar_t* t; if (rf_utf8_to_utf16(text ? text : "", &t)) return RF_ERR_ARG;
    HWND c = CreateWindowExW(ex, cls, t, WS_CHILD | WS_VISIBLE | style, x, y, cw, ch, w->hwnd, (HMENU)(INT_PTR)id, GetModuleHandleW(NULL), NULL); rf_free(t);
    if (!c) return RF_ERR_WINAPI; SendMessageW(c, WM_SETFONT, (WPARAM)g_font, TRUE); return RF_OK;
}
RF_Status rf_ui_add_button(RF_Window* w, int id, const char* t, int x, int y, int cw, int ch) { return add(w, L"BUTTON", id, t, BS_PUSHBUTTON | WS_TABSTOP, x, y, cw, ch, 0); }
RF_Status rf_ui_add_label(RF_Window* w, int id, const char* t, int x, int y, int cw, int ch) { return add(w, L"STATIC", id, t, 0, x, y, cw, ch, 0); }
RF_Status rf_ui_add_edit(RF_Window* w, int id, const char* t, int x, int y, int cw, int ch, int ml) { return add(w, L"EDIT", id, t, WS_TABSTOP | ES_AUTOHSCROLL | (ml ? ES_MULTILINE | ES_WANTRETURN | WS_VSCROLL | ES_AUTOVSCROLL : 0), x, y, cw, ch, WS_EX_CLIENTEDGE); }
RF_Status rf_ui_add_checkbox(RF_Window* w, int id, const char* t, int x, int y, int cw, int ch) { return add(w, L"BUTTON", id, t, BS_AUTOCHECKBOX | WS_TABSTOP, x, y, cw, ch, 0); }
RF_Status rf_ui_add_listbox(RF_Window* w, int id, int x, int y, int cw, int ch) { return add(w, L"LISTBOX", id, "", WS_VSCROLL | LBS_NOTIFY | WS_TABSTOP, x, y, cw, ch, WS_EX_CLIENTEDGE); }
RF_Status rf_ui_add_progress(RF_Window* w, int id, int x, int y, int cw, int ch) { return add(w, L"msctls_progress32", id, "", 0, x, y, cw, ch, 0); }
static HWND ctl(RF_Window* w, int id) { return w ? GetDlgItem(w->hwnd, id) : NULL; }
RF_Status rf_ui_set_text(RF_Window* w, int id, const char* t) { HWND c = ctl(w, id); wchar_t* u; if (!c || rf_utf8_to_utf16(t ? t : "", &u)) return RF_ERR_ARG; SetWindowTextW(c, u); rf_free(u); return RF_OK; }
char* rf_ui_get_text(RF_Window* w, int id) {
    HWND c = ctl(w, id); if (!c) return NULL; int n = GetWindowTextLengthW(c); wchar_t* b = rf_alloc(((size_t)n + 1) * sizeof(wchar_t)); if (!b) return NULL;
    GetWindowTextW(c, b, n + 1); char* u = NULL; rf_utf16_to_utf8(b, &u); rf_free(b); return u;
}
int rf_ui_get_checked(RF_Window* w, int id) { HWND c = ctl(w, id); return c && SendMessageW(c, BM_GETCHECK, 0, 0) == BST_CHECKED; }
RF_Status rf_ui_listbox_add(RF_Window* w, int id, const char* t) { HWND c = ctl(w, id); wchar_t* u; if (!c || rf_utf8_to_utf16(t ? t : "", &u)) return RF_ERR_ARG; SendMessageW(c, LB_ADDSTRING, 0, (LPARAM)u); rf_free(u); return RF_OK; }
RF_Status rf_ui_progress_set(RF_Window* w, int id, int pct) { HWND c = ctl(w, id); if (!c) return RF_ERR_ARG; SendMessageW(c, PBM_SETPOS, (WPARAM)(pct < 0 ? 0 : pct > 100 ? 100 : pct), 0); return RF_OK; }
void rf_ui_show(RF_Window* w) { if (w) { ShowWindow(w->hwnd, SW_SHOW); UpdateWindow(w->hwnd); } }
int rf_ui_run(void) { MSG m; while (GetMessageW(&m, NULL, 0, 0) > 0) { if (!IsDialogMessageW(GetAncestor(m.hwnd, GA_ROOT), &m)) { TranslateMessage(&m); DispatchMessageW(&m); } } return 0; }
void rf_ui_quit(void) { PostQuitMessage(0); }
void rf_ui_window_close(RF_Window* w) { if (w) { DestroyWindow(w->hwnd); rf_free(w); } }
int rf_ui_message_box(const char* title, const char* text, uint32_t flags) {
    wchar_t *t = NULL, *x = NULL; rf_utf8_to_utf16(title ? title : "", &t); rf_utf8_to_utf16(text ? text : "", &x); int r = MessageBoxW(NULL, x, t, flags); rf_free(t); rf_free(x); return r;
}
static RF_Status dialog(const char* filter, char** out, int save) {
    if (!out) return RF_ERR_ARG; wchar_t* f = NULL; if (filter && rf_utf8_to_utf16(filter, &f)) return RF_ERR_ARG;
    if (f) { for (wchar_t* p = f; *p; p++) if (*p == L'|') *p = 0; }  /* double-NUL terminated by rf_utf8_to_utf16 alloc: string end + extra zero below */
    size_t fl = f ? wcslen(f) : 0; wchar_t* ff = NULL; if (f) { ff = rf_alloc((strlen(filter) + 3) * sizeof(wchar_t)); memcpy(ff, f, (strlen(filter) + 1) * sizeof(wchar_t)); (void)fl; }
    wchar_t path[MAX_PATH * 2] = {0}; OPENFILENAMEW o; memset(&o, 0, sizeof o); o.lStructSize = sizeof o; o.lpstrFilter = ff; o.lpstrFile = path; o.nMaxFile = MAX_PATH * 2;
    o.Flags = OFN_EXPLORER | OFN_NOCHANGEDIR | (save ? OFN_OVERWRITEPROMPT : OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST);
    BOOL ok = save ? GetSaveFileNameW(&o) : GetOpenFileNameW(&o); rf_free(f); rf_free(ff);
    if (!ok) return RF_ERR_NOTFOUND; return rf_utf16_to_utf8(path, out);
}
RF_Status rf_ui_open_file_dialog(const char* filter, char** out) { return dialog(filter, out, 0); }
RF_Status rf_ui_save_file_dialog(const char* filter, char** out) { return dialog(filter, out, 1); }
