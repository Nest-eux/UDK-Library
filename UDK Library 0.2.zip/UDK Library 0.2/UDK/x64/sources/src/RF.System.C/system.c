#define RF_SYSTEM_BUILDING
#include "RF/System.h"
#include "RF/Core.h"
#include <windows.h>
#include <tlhelp32.h>
#include <string.h>
#include <stdlib.h>

RF_DEFINE_MODULE(RF_SYSTEM_API, "RF.System.C", "C")

int rf_file_exists(const char* path) {
    wchar_t* w; if (rf_utf8_to_utf16(path, &w) != RF_OK) return 0;
    DWORD a = GetFileAttributesW(w); rf_free(w);
    return a != INVALID_FILE_ATTRIBUTES;
}
RF_Status rf_file_read_all(const char* path, void** data, size_t* size) {
    wchar_t* w; RF_Status s = rf_utf8_to_utf16(path, &w); if (s != RF_OK) return s;
    HANDLE h = CreateFileW(w, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL); rf_free(w);
    if (h == INVALID_HANDLE_VALUE) { rf_set_error("open failed (%lu)", GetLastError()); return RF_ERR_IO; }
    LARGE_INTEGER sz; GetFileSizeEx(h, &sz);
    uint8_t* buf = rf_alloc((size_t)sz.QuadPart + 1);
    if (!buf) { CloseHandle(h); return RF_ERR_NOMEM; }
    size_t total = (size_t)sz.QuadPart, done = 0;
    while (done < total) {
        DWORD got = 0, chunk = (DWORD)((total - done) > (1u << 20) ? (1u << 20) : (total - done));
        if (!ReadFile(h, buf + done, chunk, &got, NULL) || !got) break;
        done += got;
    }
    CloseHandle(h);
    *data = buf; *size = done; return RF_OK;
}
RF_Status rf_file_write_all(const char* path, const void* data, size_t size) {
    wchar_t* w; RF_Status s = rf_utf8_to_utf16(path, &w); if (s != RF_OK) return s;
    HANDLE h = CreateFileW(w, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL); rf_free(w);
    if (h == INVALID_HANDLE_VALUE) { rf_set_error("create failed (%lu)", GetLastError()); return RF_ERR_IO; }
    const uint8_t* p = data; size_t done = 0;
    while (done < size) {
        DWORD put = 0, chunk = (DWORD)((size - done) > (1u << 20) ? (1u << 20) : (size - done));
        if (!WriteFile(h, p + done, chunk, &put, NULL) || !put) { CloseHandle(h); return RF_ERR_IO; }
        done += put;
    }
    CloseHandle(h); return RF_OK;
}

RF_Status rf_process_run(const char* cmd, int wait, uint32_t* exit_code) {
    wchar_t* w; RF_Status s = rf_utf8_to_utf16(cmd, &w); if (s != RF_OK) return s;
    STARTUPINFOW si; memset(&si, 0, sizeof si); si.cb = sizeof si; PROCESS_INFORMATION pi;
    BOOL ok = CreateProcessW(NULL, w, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi); rf_free(w);
    if (!ok) { rf_set_error("CreateProcess failed (%lu)", GetLastError()); return RF_ERR_WINAPI; }
    if (wait) { WaitForSingleObject(pi.hProcess, INFINITE); DWORD c = 0; GetExitCodeProcess(pi.hProcess, &c); if (exit_code) *exit_code = c; }
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess); return RF_OK;
}
RF_Status rf_process_enum(RF_ProcessCb cb, void* user) {
    if (!cb) return RF_ERR_ARG;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return RF_ERR_WINAPI;
    PROCESSENTRY32W pe; memset(&pe, 0, sizeof pe); pe.dwSize = sizeof pe;
    for (BOOL ok = Process32FirstW(snap, &pe); ok; ok = Process32NextW(snap, &pe)) {
        char* n = NULL; if (rf_utf16_to_utf8(pe.szExeFile, &n) != RF_OK) continue;
        int cont = cb(pe.th32ProcessID, n, user); rf_free(n);
        if (!cont) break;
    }
    CloseHandle(snap); return RF_OK;
}
RF_Status rf_process_kill(uint32_t pid) {
    HANDLE h = OpenProcess(PROCESS_TERMINATE, FALSE, pid);
    if (!h) { rf_set_error("OpenProcess failed (%lu)", GetLastError()); return RF_ERR_WINAPI; }
    BOOL ok = TerminateProcess(h, 1); CloseHandle(h); return ok ? RF_OK : RF_ERR_WINAPI;
}

static HKEY root_of(const char* r) { return (r && !strcmp(r, "HKLM")) ? HKEY_LOCAL_MACHINE : HKEY_CURRENT_USER; }
RF_Status rf_reg_read_string(const char* root, const char* key, const char* name, char* buf, size_t buf_size) {
    wchar_t *wk = NULL, *wn = NULL; HKEY k; RF_Status s = RF_ERR_WINAPI;
    if (rf_utf8_to_utf16(key, &wk) != RF_OK) return RF_ERR_ARG;
    rf_utf8_to_utf16(name ? name : "", &wn);
    if (RegOpenKeyExW(root_of(root), wk, 0, KEY_READ, &k) == ERROR_SUCCESS) {
        wchar_t tmp[2048]; DWORD sz = sizeof tmp, type;
        if (RegQueryValueExW(k, wn, NULL, &type, (BYTE*)tmp, &sz) == ERROR_SUCCESS && (type == REG_SZ || type == REG_EXPAND_SZ)) {
            char* u; if (rf_utf16_to_utf8(tmp, &u) == RF_OK) { strncpy(buf, u, buf_size - 1); buf[buf_size - 1] = 0; rf_free(u); s = RF_OK; }
        } else s = RF_ERR_NOTFOUND;
        RegCloseKey(k);
    }
    rf_free(wk); rf_free(wn); return s;
}
RF_Status rf_reg_write_string(const char* root, const char* key, const char* name, const char* value) {
    wchar_t *wk, *wn, *wv; HKEY k; RF_Status s = RF_ERR_WINAPI;
    rf_utf8_to_utf16(key, &wk); rf_utf8_to_utf16(name ? name : "", &wn); rf_utf8_to_utf16(value, &wv);
    if (RegCreateKeyExW(root_of(root), wk, 0, NULL, 0, KEY_WRITE, NULL, &k, NULL) == ERROR_SUCCESS) {
        if (RegSetValueExW(k, wn, 0, REG_SZ, (const BYTE*)wv, (DWORD)((wcslen(wv) + 1) * sizeof(wchar_t))) == ERROR_SUCCESS) s = RF_OK;
        RegCloseKey(k);
    }
    rf_free(wk); rf_free(wn); rf_free(wv); return s;
}
RF_Status rf_reg_delete_value(const char* root, const char* key, const char* name) {
    wchar_t *wk, *wn; HKEY k; RF_Status s = RF_ERR_WINAPI;
    rf_utf8_to_utf16(key, &wk); rf_utf8_to_utf16(name ? name : "", &wn);
    if (RegOpenKeyExW(root_of(root), wk, 0, KEY_WRITE, &k) == ERROR_SUCCESS) {
        if (RegDeleteValueW(k, wn) == ERROR_SUCCESS) s = RF_OK;
        RegCloseKey(k);
    }
    rf_free(wk); rf_free(wn); return s;
}

typedef struct { RF_WindowCb cb; void* user; } WinCtx;
static BOOL CALLBACK enum_win(HWND h, LPARAM l) {
    WinCtx* c = (WinCtx*)l; wchar_t t[512];
    if (!IsWindowVisible(h) || !GetWindowTextW(h, t, 512)) return TRUE;
    char* u; if (rf_utf16_to_utf8(t, &u) != RF_OK) return TRUE;
    int cont = c->cb((uintptr_t)h, u, c->user); rf_free(u); return cont;
}
RF_Status rf_window_enum(RF_WindowCb cb, void* user) {
    if (!cb) return RF_ERR_ARG; WinCtx c = { cb, user }; EnumWindows(enum_win, (LPARAM)&c); return RF_OK;
}
RF_Status rf_clipboard_get_text(char** out) {
    if (!out) return RF_ERR_ARG; if (!OpenClipboard(NULL)) return RF_ERR_WINAPI;
    RF_Status s = RF_ERR_NOTFOUND; HANDLE h = GetClipboardData(CF_UNICODETEXT);
    if (h) { wchar_t* w = GlobalLock(h); if (w) { s = rf_utf16_to_utf8(w, out); GlobalUnlock(h); } }
    CloseClipboard(); return s;
}
RF_Status rf_clipboard_set_text(const char* text) {
    wchar_t* w; RF_Status s = rf_utf8_to_utf16(text, &w); if (s != RF_OK) return s;
    size_t bytes = (wcslen(w) + 1) * sizeof(wchar_t);
    HGLOBAL g = GlobalAlloc(GMEM_MOVEABLE, bytes);
    if (!g || !OpenClipboard(NULL)) { rf_free(w); return RF_ERR_WINAPI; }
    memcpy(GlobalLock(g), w, bytes); GlobalUnlock(g); rf_free(w);
    EmptyClipboard(); SetClipboardData(CF_UNICODETEXT, g); CloseClipboard(); return RF_OK;
}

RF_Status rf_sysinfo(RF_SysInfo* o) {
    if (!o) return RF_ERR_ARG; memset(o, 0, sizeof *o);
    SYSTEM_INFO si; GetSystemInfo(&si); o->cpu_count = si.dwNumberOfProcessors;
    MEMORYSTATUSEX m; memset(&m, 0, sizeof m); m.dwLength = sizeof m; GlobalMemoryStatusEx(&m);
    o->ram_total = m.ullTotalPhys; o->ram_free = m.ullAvailPhys;
    typedef LONG (WINAPI *RtlGetVersionFn)(OSVERSIONINFOW*);
    RtlGetVersionFn f = (RtlGetVersionFn)(void*)GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "RtlGetVersion");
    OSVERSIONINFOW v; memset(&v, 0, sizeof v); v.dwOSVersionInfoSize = sizeof v;
    if (f && f(&v) == 0) { o->os_major = v.dwMajorVersion; o->os_minor = v.dwMinorVersion; o->os_build = v.dwBuildNumber; }
    DWORD n = sizeof o->computer_name; GetComputerNameA(o->computer_name, &n);
    return RF_OK;
}
