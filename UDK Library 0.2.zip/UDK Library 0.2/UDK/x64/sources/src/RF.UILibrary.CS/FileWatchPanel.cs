using System.Windows.Controls;
using RF.Core;

namespace RF.UI;

/// <summary>Watches a folder via RF.FileSystem.C and logs changes into a LogView.</summary>
public class FileWatchPanel : DockPanel
{
    readonly LogView _log = new();
    FileWatcher? _watcher;
    readonly TextBox _path = new() { Width = 380, Margin = new System.Windows.Thickness(4) };

    public FileWatchPanel()
    {
        var bar = new StackPanel { Orientation = Orientation.Horizontal };
        bar.Children.Add(_path);
        bar.Children.Add(RFControls.Button("Start", (_, _) => Start(_path.Text)));
        bar.Children.Add(RFControls.Button("Stop", (_, _) => Stop()));
        SetDock(bar, Dock.Top); Children.Add(bar); Children.Add(_log);
    }
    public string Path { get => _path.Text; set => _path.Text = value; }
    public void Start(string dir)
    {
        Stop();
        try { _watcher = new FileWatcher(dir, true, (a, p) => _log.Append($"{a}: {p}")); _log.Append($"watching {dir}"); }
        catch (RFException e) { _log.Append("error: " + e.Message); }
    }
    public void Stop() { _watcher?.Dispose(); _watcher = null; }
}
