using System.Windows;

namespace RF.UI;

public static class RFTheme
{
    /// <summary>Loads the RF dark theme into the application resources.</summary>
    public static void Apply(Application app) =>
        app.Resources.MergedDictionaries.Add(new ResourceDictionary {
            Source = new Uri("pack://application:,,,/RF.UILibrary.CS;component/Themes/Dark.xaml") });
}
