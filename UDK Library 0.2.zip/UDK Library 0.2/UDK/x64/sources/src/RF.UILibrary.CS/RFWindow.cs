using System.Windows;
using System.Windows.Controls;

namespace RF.UI;

/// <summary>Base window with RF styling. Derive or use directly.</summary>
public class RFWindow : Window
{
    public RFWindow() { SetResourceReference(StyleProperty, "RF.Window"); }
}

public static class RFControls
{
    public static Button Button(string text, RoutedEventHandler onClick)
    {
        var b = new Button { Content = text, Margin = new Thickness(4) };
        b.SetResourceReference(FrameworkElement.StyleProperty, "RF.Button");
        b.Click += onClick; return b;
    }
}
