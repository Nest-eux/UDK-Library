using System.Windows;
using System.Windows.Controls;
using RF.Core;

namespace RF.UI;

/// <summary>Panel showing system info through RF.System.C, with a working Refresh button.</summary>
public class SystemInfoPanel : StackPanel
{
    readonly TextBlock _text = new() { Margin = new Thickness(8) };
    public SystemInfoPanel()
    {
        Children.Add(_text);
        Children.Add(RFControls.Button("Refresh", (_, _) => Refresh()));
        Refresh();
    }
    public void Refresh()
    {
        var i = Core.RF.GetSysInfo();
        _text.Text = $"{i.ComputerName}  |  CPU {i.CpuCount}  |  RAM {i.RamFree >> 20}/{i.RamTotal >> 20} MB free  |  Windows {i.OsMajor}.{i.OsMinor}.{i.OsBuild}";
    }
}
