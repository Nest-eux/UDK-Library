using System.Windows;
using System.Windows.Controls;
using RF.Core;

namespace RF.UI;

/// <summary>Live process list (RF.System.C) with filter box, refresh and kill.</summary>
public class ProcessListView : DockPanel
{
    readonly ListView _list = new();
    readonly TextBox _filter = new() { Margin = new Thickness(4) };
    List<ProcessEntry> _all = new();

    public ProcessListView()
    {
        var bar = new StackPanel { Orientation = Orientation.Horizontal };
        _filter.Width = 220; _filter.TextChanged += (_, _) => Apply();
        bar.Children.Add(_filter);
        bar.Children.Add(RFControls.Button("Refresh", (_, _) => Refresh()));
        bar.Children.Add(RFControls.Button("Kill selected", (_, _) => KillSelected()));
        SetDock(bar, Dock.Top); Children.Add(bar);
        var gv = new GridView();
        gv.Columns.Add(new GridViewColumn { Header = "PID", Width = 80, DisplayMemberBinding = new System.Windows.Data.Binding(nameof(ProcessEntry.Pid)) });
        gv.Columns.Add(new GridViewColumn { Header = "Name", Width = 320, DisplayMemberBinding = new System.Windows.Data.Binding(nameof(ProcessEntry.Name)) });
        _list.View = gv; Children.Add(_list);
        Refresh();
    }
    public void Refresh() { _all = Core.RF.Processes(); Apply(); }
    void Apply()
    {
        var f = _filter.Text.Trim();
        _list.ItemsSource = string.IsNullOrEmpty(f) ? _all : _all.Where(p => p.Name.Contains(f, StringComparison.OrdinalIgnoreCase)).ToList();
    }
    void KillSelected()
    {
        if (_list.SelectedItem is not ProcessEntry p) return;
        if (MessageBox.Show($"Kill {p.Name} ({p.Pid})?", "RF", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
        try { Core.RF.KillProcess(p.Pid); Refresh(); } catch (RFException e) { MessageBox.Show(e.Message, "RF"); }
    }
}
