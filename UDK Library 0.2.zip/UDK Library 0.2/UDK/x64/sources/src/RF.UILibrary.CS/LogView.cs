using System.Windows.Controls;

namespace RF.UI;

/// <summary>Auto-scrolling log list; Append is safe to call from any thread.</summary>
public class LogView : ListBox
{
    public int MaxLines { get; set; } = 2000;
    public void Append(string line)
    {
        if (!Dispatcher.CheckAccess()) { Dispatcher.BeginInvoke(() => Append(line)); return; }
        Items.Add($"[{DateTime.Now:HH:mm:ss}] {line}");
        while (Items.Count > MaxLines) Items.RemoveAt(0);
        ScrollIntoView(Items[^1]);
    }
}
