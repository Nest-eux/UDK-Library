#define RF_PARALLEL_BUILDING
#include "RF/Parallel.hpp"
#include <thread>
#include <mutex>
#include <condition_variable>
#include <deque>
#include <vector>
#include <cstring>

struct RFP_Pool {
    std::vector<std::thread> workers;
    std::deque<std::pair<RFP_Task, void*>> q;
    std::mutex m; std::condition_variable cv, idle;
    unsigned busy = 0; bool stop = false;
};

RF_DEFINE_MODULE(extern "C" RF_DLLEXPORT, "RF.Parallel.Cpp", "CPP")

RFP_Pool* rfp_pool_create(unsigned n) {
    if (!n) n = std::thread::hardware_concurrency();
    if (!n) n = 2;
    auto* p = new RFP_Pool;
    for (unsigned i = 0; i < n; i++) p->workers.emplace_back([p] {
        for (;;) {
            std::pair<RFP_Task, void*> t;
            { std::unique_lock<std::mutex> l(p->m);
              p->cv.wait(l, [p]{ return p->stop || !p->q.empty(); });
              if (p->stop && p->q.empty()) return;
              t = p->q.front(); p->q.pop_front(); p->busy++; }
            t.first(t.second);
            { std::lock_guard<std::mutex> l(p->m); p->busy--; if (p->q.empty() && !p->busy) p->idle.notify_all(); }
        }
    });
    return p;
}
RF_Status rfp_pool_submit(RFP_Pool* p, RFP_Task fn, void* user) {
    if (!p || !fn) return RF_ERR_ARG;
    { std::lock_guard<std::mutex> l(p->m); p->q.emplace_back(fn, user); }
    p->cv.notify_one(); return RF_OK;
}
void rfp_pool_wait(RFP_Pool* p) {
    if (!p) return; std::unique_lock<std::mutex> l(p->m);
    p->idle.wait(l, [p]{ return p->q.empty() && !p->busy; });
}
void rfp_pool_destroy(RFP_Pool* p) {
    if (!p) return;
    { std::lock_guard<std::mutex> l(p->m); p->stop = true; }
    p->cv.notify_all(); for (auto& t : p->workers) t.join(); delete p;
}

namespace { struct PF { void (*body)(unsigned, void*); void* user; unsigned i; }; }
RF_Status rfp_parallel_for(unsigned count, void (*body)(unsigned, void*), void* user) {
    if (!body) return RF_ERR_ARG;
    RFP_Pool* p = rfp_pool_create(0);
    std::vector<PF> items(count);
    for (unsigned i = 0; i < count; i++) {
        items[i] = { body, user, i };
        rfp_pool_submit(p, [](void* u){ auto* f = static_cast<PF*>(u); f->body(f->i, f->user); }, &items[i]);
    }
    rfp_pool_wait(p); rfp_pool_destroy(p); return RF_OK;
}
