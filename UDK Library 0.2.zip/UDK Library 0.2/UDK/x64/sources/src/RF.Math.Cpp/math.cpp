#define RF_MATH_BUILDING
#include "RF/Math.hpp"
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>

RF_DEFINE_MODULE(extern "C" RF_DLLEXPORT, "RF.Math.Cpp", "CPP")

void rfm_mat4_identity(float* m) { std::memset(m, 0, 16 * sizeof(float)); m[0] = m[5] = m[10] = m[15] = 1; }
void rfm_mat4_mul(const float* a, const float* b, float* out) {
    float r[16]; for (int c = 0; c < 4; c++) for (int rw = 0; rw < 4; rw++) { float s = 0; for (int k = 0; k < 4; k++) s += a[k * 4 + rw] * b[c * 4 + k]; r[c * 4 + rw] = s; }
    std::memcpy(out, r, sizeof r);
}
void rfm_mat4_translate(float* m, float x, float y, float z) { rfm_mat4_identity(m); m[12] = x; m[13] = y; m[14] = z; }
void rfm_mat4_scale(float* m, float x, float y, float z) { rfm_mat4_identity(m); m[0] = x; m[5] = y; m[10] = z; }
void rfm_mat4_rotate(float* m, float rad, float x, float y, float z) {
    float l = std::sqrt(x*x + y*y + z*z); if (l == 0) { rfm_mat4_identity(m); return; } x /= l; y /= l; z /= l;
    float c = std::cos(rad), s = std::sin(rad), t = 1 - c; rfm_mat4_identity(m);
    m[0] = t*x*x + c;   m[4] = t*x*y - s*z; m[8]  = t*x*z + s*y;
    m[1] = t*x*y + s*z; m[5] = t*y*y + c;   m[9]  = t*y*z - s*x;
    m[2] = t*x*z - s*y; m[6] = t*y*z + s*x; m[10] = t*z*z + c;
}
void rfm_mat4_perspective(float* m, float fov, float asp, float n, float f) {
    float t = 1.0f / std::tan(fov / 2); std::memset(m, 0, 16 * sizeof(float));
    m[0] = t / asp; m[5] = t; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = 2 * f * n / (n - f);
}
int rfm_mat4_invert(const float* m, float* out) {
    double a[4][8]; for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) { a[r][c] = m[c * 4 + r]; a[r][4 + c] = r == c; }
    for (int i = 0; i < 4; i++) {
        int p = i; for (int r = i + 1; r < 4; r++) if (std::fabs(a[r][i]) > std::fabs(a[p][i])) p = r;
        if (std::fabs(a[p][i]) < 1e-12) return 0; if (p != i) for (int c = 0; c < 8; c++) std::swap(a[i][c], a[p][c]);
        double d = a[i][i]; for (int c = 0; c < 8; c++) a[i][c] /= d;
        for (int r = 0; r < 4; r++) if (r != i) { double f = a[r][i]; for (int c = 0; c < 8; c++) a[r][c] -= f * a[i][c]; }
    }
    for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) out[c * 4 + r] = (float)a[r][4 + c]; return 1;
}
void rfm_vec3_cross(const float* a, const float* b, float* o) { float r[3] = { a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0] }; std::memcpy(o, r, sizeof r); }
float rfm_vec3_dot(const float* a, const float* b) { return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]; }
void rfm_vec3_normalize(const float* a, float* o) { float l = std::sqrt(rfm_vec3_dot(a, a)); if (l == 0) { o[0] = o[1] = o[2] = 0; return; } for (int i = 0; i < 3; i++) o[i] = a[i] / l; }

int rfm_mat_mul(const double* a, int ar, int ac, const double* b, int bc, double* out) {
    if (!a || !b || !out || ar <= 0 || ac <= 0 || bc <= 0) return 0; std::vector<double> r((size_t)ar * bc, 0.0);
    for (int i = 0; i < ar; i++) for (int k = 0; k < ac; k++) { double v = a[(size_t)i * ac + k]; for (int j = 0; j < bc; j++) r[(size_t)i * bc + j] += v * b[(size_t)k * bc + j]; }
    std::memcpy(out, r.data(), r.size() * sizeof(double)); return 1;
}
int rfm_solve(const double* A, int n, const double* b, double* x) {
    if (!A || !b || !x || n <= 0) return 0; std::vector<double> a((size_t)n * (n + 1));
    for (int i = 0; i < n; i++) { for (int j = 0; j < n; j++) a[(size_t)i * (n + 1) + j] = A[(size_t)i * n + j]; a[(size_t)i * (n + 1) + n] = b[i]; }
    for (int i = 0; i < n; i++) {
        int p = i; for (int r = i + 1; r < n; r++) if (std::fabs(a[(size_t)r * (n + 1) + i]) > std::fabs(a[(size_t)p * (n + 1) + i])) p = r;
        if (std::fabs(a[(size_t)p * (n + 1) + i]) < 1e-12) return 0;
        if (p != i) for (int c = 0; c <= n; c++) std::swap(a[(size_t)i * (n + 1) + c], a[(size_t)p * (n + 1) + c]);
        for (int r = i + 1; r < n; r++) { double f = a[(size_t)r * (n + 1) + i] / a[(size_t)i * (n + 1) + i]; for (int c = i; c <= n; c++) a[(size_t)r * (n + 1) + c] -= f * a[(size_t)i * (n + 1) + c]; }
    }
    for (int i = n - 1; i >= 0; i--) { double s = a[(size_t)i * (n + 1) + n]; for (int j = i + 1; j < n; j++) s -= a[(size_t)i * (n + 1) + j] * x[j]; x[i] = s / a[(size_t)i * (n + 1) + i]; }
    return 1;
}
int rfm_stats(const double* v, int n, RFM_Stats* o) {
    if (!v || !o || n <= 0) return 0; std::vector<double> s(v, v + n); std::sort(s.begin(), s.end());
    double sum = 0; for (double d : s) sum += d; o->mean = sum / n; double q = 0; for (double d : s) q += (d - o->mean) * (d - o->mean);
    o->variance = q / n; o->stddev = std::sqrt(o->variance); o->min = s.front(); o->max = s.back(); o->median = n % 2 ? s[n / 2] : (s[n / 2 - 1] + s[n / 2]) / 2; return 1;
}
