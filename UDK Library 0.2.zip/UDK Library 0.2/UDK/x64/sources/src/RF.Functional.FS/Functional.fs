namespace RF.Functional

open System
open System.Text
open RF.Core

/// Result-based (no exceptions) wrappers over the RF native layer.
module Safe =
    let private wrap (f: unit -> 'a) : Result<'a, string> =
        try Ok (f ())
        with
        | :? RFException as e -> Error e.Message
        | :? ArgumentException as e -> Error e.Message

    let readFile (path: string) = wrap (fun () -> RF.ReadFile path)
    let writeFile (path: string) (data: byte[]) = wrap (fun () -> RF.WriteFile(path, ReadOnlySpan<byte>(data)))
    let sysInfo ()           = wrap RF.GetSysInfo
    let processes ()         = wrap (fun () -> RF.Processes() |> List.ofSeq)
    let windows ()           = wrap (fun () -> RF.Windows() |> List.ofSeq)
    let crc32 (data: byte[]) = RF.Crc32(ReadOnlySpan<byte>(data))
    let httpGet (url: string) = wrap (fun () -> RFNet.Get url)
    let screenshot ()        = wrap (fun () -> RFInput.Screenshot())
    let compress (d: byte[]) = wrap (fun () -> RFCompression.Compress(ReadOnlySpan<byte>(d)))
    let decompress (d: byte[]) = wrap (fun () -> RFCompression.Decompress(ReadOnlySpan<byte>(d)))

module Crypto =
    let sha256Hex (text: string) = RFCrypto.Sha256 text |> Convert.ToHexString |> fun s -> s.ToLowerInvariant()
    /// Encrypt = ChaCha20 + HMAC-SHA256 (encrypt-then-MAC). Output: nonce(12) | tag(32) | ciphertext
    let seal (key: byte[]) (plain: byte[]) =
        let nonce = RFCrypto.Random 12
        let ct = RFCrypto.ChaCha20(key, nonce, ReadOnlySpan<byte>(plain))
        let tag = RFCrypto.HmacSha256(ReadOnlySpan<byte>(key), ReadOnlySpan<byte>(Array.append nonce ct))
        Array.concat [ nonce; tag; ct ]
    let openSealed (key: byte[]) (blob: byte[]) : Result<byte[], string> =
        if blob.Length < 44 then Error "blob too short" else
        let nonce, tag, ct = blob.[0..11], blob.[12..43], blob.[44..]
        let expect = RFCrypto.HmacSha256(ReadOnlySpan<byte>(key), ReadOnlySpan<byte>(Array.append nonce ct))
        if System.Security.Cryptography.CryptographicOperations.FixedTimeEquals(ReadOnlySpan<byte>(expect), ReadOnlySpan<byte>(tag))
        then Ok (RFCrypto.ChaCha20(key, nonce, ReadOnlySpan<byte>(ct)))
        else Error "authentication failed"

module Pipeline =
    let ( >>= ) r f = Result.bind f r
    let findProcess (name: string) =
        Safe.processes () |> Result.map (List.filter (fun p -> p.Name.Contains(name, StringComparison.OrdinalIgnoreCase)))
