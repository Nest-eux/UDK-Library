#define RF_CRYPTO_BUILDING
#include "RF/Crypto.h"
#include "RF/Core.h"
#ifdef _WIN32
 #include <windows.h>
 #include <bcrypt.h>
#else
 #include <stdio.h>
#endif

RF_DEFINE_MODULE(RF_CRYPTO_API, "RF.Crypto.C", "C")

#define ROR(x, n) (((x) >> (n)) | ((x) << (32 - (n))))
static const uint32_t K[64] = {
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2 };

typedef struct { uint32_t h[8]; uint8_t buf[64]; uint64_t len; size_t fill; } Sha;
static void block(Sha* s, const uint8_t* p) {
    uint32_t w[64], a, b, c, d, e, f, g, h;
    for (int i = 0; i < 16; i++) w[i] = (uint32_t)p[i*4] << 24 | (uint32_t)p[i*4+1] << 16 | (uint32_t)p[i*4+2] << 8 | p[i*4+3];
    for (int i = 16; i < 64; i++) { uint32_t s0 = ROR(w[i-15],7) ^ ROR(w[i-15],18) ^ (w[i-15] >> 3), s1 = ROR(w[i-2],17) ^ ROR(w[i-2],19) ^ (w[i-2] >> 10); w[i] = w[i-16] + s0 + w[i-7] + s1; }
    a=s->h[0]; b=s->h[1]; c=s->h[2]; d=s->h[3]; e=s->h[4]; f=s->h[5]; g=s->h[6]; h=s->h[7];
    for (int i = 0; i < 64; i++) {
        uint32_t t1 = h + (ROR(e,6) ^ ROR(e,11) ^ ROR(e,25)) + ((e & f) ^ (~e & g)) + K[i] + w[i];
        uint32_t t2 = (ROR(a,2) ^ ROR(a,13) ^ ROR(a,22)) + ((a & b) ^ (a & c) ^ (b & c));
        h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
    }
    s->h[0]+=a; s->h[1]+=b; s->h[2]+=c; s->h[3]+=d; s->h[4]+=e; s->h[5]+=f; s->h[6]+=g; s->h[7]+=h;
}
static void sinit(Sha* s) { static const uint32_t i[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19}; memcpy(s->h, i, sizeof i); s->len = 0; s->fill = 0; }
static void supd(Sha* s, const void* d, size_t n) {
    const uint8_t* p = d; s->len += n;
    while (n) { size_t c = 64 - s->fill; if (c > n) c = n; memcpy(s->buf + s->fill, p, c); s->fill += c; p += c; n -= c; if (s->fill == 64) { block(s, s->buf); s->fill = 0; } }
}
static void sfin(Sha* s, uint8_t out[32]) {
    uint64_t bits = s->len * 8; uint8_t pad = 0x80; supd(s, &pad, 1); pad = 0; while (s->fill != 56) supd(s, &pad, 1);
    uint8_t l[8]; for (int i = 0; i < 8; i++) l[i] = (uint8_t)(bits >> (56 - 8 * i)); supd(s, l, 8);
    for (int i = 0; i < 8; i++) { out[i*4] = (uint8_t)(s->h[i] >> 24); out[i*4+1] = (uint8_t)(s->h[i] >> 16); out[i*4+2] = (uint8_t)(s->h[i] >> 8); out[i*4+3] = (uint8_t)s->h[i]; }
}
void rf_sha256(const void* d, size_t n, uint8_t out[32]) { Sha s; sinit(&s); supd(&s, d, n); sfin(&s, out); }

void rf_hmac_sha256(const void* key, size_t kl, const void* d, size_t n, uint8_t out[32]) {
    uint8_t k[64] = {0}, ip[64], op[64], in[32]; Sha s;
    if (kl > 64) rf_sha256(key, kl, k); else if (kl) memcpy(k, key, kl);
    for (int i = 0; i < 64; i++) { ip[i] = k[i] ^ 0x36; op[i] = k[i] ^ 0x5c; }
    sinit(&s); supd(&s, ip, 64); supd(&s, d, n); sfin(&s, in);
    sinit(&s); supd(&s, op, 64); supd(&s, in, 32); sfin(&s, out);
}
void rf_pbkdf2_sha256(const void* pw, size_t pl, const void* salt, size_t sl, uint32_t iters, void* out, size_t outlen) {
    uint8_t* o = out; uint32_t blk = 1;
    uint8_t* sb = rf_alloc(sl + 4); if (!sb) return; memcpy(sb, salt, sl);
    while (outlen) {
        uint8_t u[32], t[32]; sb[sl] = (uint8_t)(blk >> 24); sb[sl+1] = (uint8_t)(blk >> 16); sb[sl+2] = (uint8_t)(blk >> 8); sb[sl+3] = (uint8_t)blk;
        rf_hmac_sha256(pw, pl, sb, sl + 4, u); memcpy(t, u, 32);
        for (uint32_t i = 1; i < iters; i++) { rf_hmac_sha256(pw, pl, u, 32, u); for (int j = 0; j < 32; j++) t[j] ^= u[j]; }
        size_t c = outlen < 32 ? outlen : 32; memcpy(o, t, c); o += c; outlen -= c; blk++;
    }
    rf_free(sb);
}

#define ROL(x, n) (((x) << (n)) | ((x) >> (32 - (n))))
#define QR(a,b,c,d) a+=b; d^=a; d=ROL(d,16); c+=d; b^=c; b=ROL(b,12); a+=b; d^=a; d=ROL(d,8); c+=d; b^=c; b=ROL(b,7)
static uint32_t ld32(const uint8_t* p) { return p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24; }
void rf_chacha20_xor(const uint8_t key[32], const uint8_t nonce[12], uint32_t counter, const void* in, void* out, size_t n) {
    const uint8_t* ip = in; uint8_t* op = out; uint32_t st[16] = { 0x61707865, 0x3320646e, 0x79622d32, 0x6b206574 };
    for (int i = 0; i < 8; i++) st[4 + i] = ld32(key + i * 4);
    st[12] = counter; for (int i = 0; i < 3; i++) st[13 + i] = ld32(nonce + i * 4);
    while (n) {
        uint32_t x[16]; uint8_t ks[64]; memcpy(x, st, sizeof x);
        for (int r = 0; r < 10; r++) { QR(x[0],x[4],x[8],x[12]); QR(x[1],x[5],x[9],x[13]); QR(x[2],x[6],x[10],x[14]); QR(x[3],x[7],x[11],x[15]);
                                       QR(x[0],x[5],x[10],x[15]); QR(x[1],x[6],x[11],x[12]); QR(x[2],x[7],x[8],x[13]); QR(x[3],x[4],x[9],x[14]); }
        for (int i = 0; i < 16; i++) { uint32_t v = x[i] + st[i]; ks[i*4] = (uint8_t)v; ks[i*4+1] = (uint8_t)(v >> 8); ks[i*4+2] = (uint8_t)(v >> 16); ks[i*4+3] = (uint8_t)(v >> 24); }
        size_t c = n < 64 ? n : 64; for (size_t i = 0; i < c; i++) op[i] = ip[i] ^ ks[i];
        ip += c; op += c; n -= c; st[12]++;
    }
}
RF_Status rf_random_bytes(void* buf, size_t n) {
    if (!buf) return RF_ERR_ARG;
#ifdef _WIN32
    return BCryptGenRandom(NULL, buf, (ULONG)n, BCRYPT_USE_SYSTEM_PREFERRED_RNG) == 0 ? RF_OK : RF_ERR_WINAPI;
#else
    FILE* f = fopen("/dev/urandom", "rb"); if (!f) return RF_ERR_IO; size_t r = fread(buf, 1, n, f); fclose(f); return r == n ? RF_OK : RF_ERR_IO;
#endif
}
int rf_const_time_eq(const void* a, const void* b, size_t n) { const uint8_t *x = a, *y = b; uint8_t d = 0; for (size_t i = 0; i < n; i++) d |= x[i] ^ y[i]; return d == 0; }
