#define RF_JSON_BUILDING
#include "RF/Json.h"
#include "RF/Core.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

RF_DEFINE_MODULE(RF_JSON_API, "RF.Json.C", "C")

struct RF_Json { RF_JsonType t; double num; int b; char* str; RF_Json** items; char** keys; size_t count, cap; };

static RF_Json* mk(RF_JsonType t) { RF_Json* j = rf_alloc(sizeof *j); if (j) j->t = t; return j; }
RF_Json* rf_json_new_null(void) { return mk(RF_JSON_NULL); }
RF_Json* rf_json_new_bool(int b) { RF_Json* j = mk(RF_JSON_BOOL); if (j) j->b = !!b; return j; }
RF_Json* rf_json_new_number(double d) { RF_Json* j = mk(RF_JSON_NUMBER); if (j) j->num = d; return j; }
RF_Json* rf_json_new_string(const char* s) { RF_Json* j = mk(RF_JSON_STRING); if (j) j->str = rf_strdup(s ? s : ""); return j; }
RF_Json* rf_json_new_array(void) { return mk(RF_JSON_ARRAY); }
RF_Json* rf_json_new_object(void) { return mk(RF_JSON_OBJECT); }

void rf_json_free(RF_Json* j) {
    if (!j) return;
    for (size_t i = 0; i < j->count; i++) { rf_json_free(j->items[i]); if (j->keys) rf_free(j->keys[i]); }
    rf_free(j->items); rf_free(j->keys); rf_free(j->str); rf_free(j);
}
RF_JsonType rf_json_type(const RF_Json* j) { return j ? j->t : RF_JSON_NULL; }
double rf_json_number(const RF_Json* j) { return j && j->t == RF_JSON_NUMBER ? j->num : 0; }
int rf_json_bool(const RF_Json* j) { return j && j->t == RF_JSON_BOOL ? j->b : 0; }
const char* rf_json_string(const RF_Json* j) { return j && j->t == RF_JSON_STRING ? j->str : NULL; }
size_t rf_json_count(const RF_Json* j) { return j ? j->count : 0; }
RF_Json* rf_json_at(const RF_Json* j, size_t i) { return j && i < j->count ? j->items[i] : NULL; }
const char* rf_json_key_at(const RF_Json* j, size_t i) { return j && j->t == RF_JSON_OBJECT && i < j->count ? j->keys[i] : NULL; }
RF_Json* rf_json_get(const RF_Json* j, const char* k) {
    if (!j || j->t != RF_JSON_OBJECT || !k) return NULL;
    for (size_t i = 0; i < j->count; i++) if (!strcmp(j->keys[i], k)) return j->items[i];
    return NULL;
}
static RF_Status push(RF_Json* c, char* key, RF_Json* it) {
    if (c->count == c->cap) {
        size_t nc = c->cap ? c->cap * 2 : 4;
        RF_Json** ni = rf_realloc(c->items, nc * sizeof *ni); if (!ni) return RF_ERR_NOMEM; c->items = ni;
        if (c->t == RF_JSON_OBJECT) { char** nk = rf_realloc(c->keys, nc * sizeof *nk); if (!nk) return RF_ERR_NOMEM; c->keys = nk; }
        c->cap = nc;
    }
    c->items[c->count] = it; if (c->t == RF_JSON_OBJECT) c->keys[c->count] = key; c->count++; return RF_OK;
}
RF_Status rf_json_array_push(RF_Json* a, RF_Json* it) { if (!a || a->t != RF_JSON_ARRAY || !it) return RF_ERR_ARG; return push(a, NULL, it); }
RF_Status rf_json_object_set(RF_Json* o, const char* k, RF_Json* it) {
    if (!o || o->t != RF_JSON_OBJECT || !k || !it) return RF_ERR_ARG;
    for (size_t i = 0; i < o->count; i++) if (!strcmp(o->keys[i], k)) { rf_json_free(o->items[i]); o->items[i] = it; return RF_OK; }
    return push(o, rf_strdup(k), it);
}

/* ---- parser ---- */
typedef struct { const char* p; int depth; } P;
static void ws(P* s) { while (*s->p == ' ' || *s->p == '\t' || *s->p == '\n' || *s->p == '\r') s->p++; }
static RF_Json* val(P* s);
static int hex4(const char* p, uint32_t* o) { uint32_t v = 0; for (int i = 0; i < 4; i++) { char c = p[i]; v <<= 4;
    if (c >= '0' && c <= '9') v |= (uint32_t)(c - '0'); else if (c >= 'a' && c <= 'f') v |= (uint32_t)(c - 'a' + 10); else if (c >= 'A' && c <= 'F') v |= (uint32_t)(c - 'A' + 10); else return 0; } *o = v; return 1; }
static char* pstr(P* s) {
    s->p++; size_t cap = 16, n = 0; char* o = rf_alloc(cap); if (!o) return NULL;
    while (*s->p != '"') {
        if (!*s->p || (uint8_t)*s->p < 0x20) { rf_free(o); rf_set_error("json: bad string"); return NULL; }
        if (n + 5 >= cap) { cap *= 2; char* t = rf_realloc(o, cap); if (!t) { rf_free(o); return NULL; } o = t; }
        if (*s->p != '\\') { o[n++] = *s->p++; continue; }
        s->p++; char c = *s->p++;
        switch (c) {
            case '"': o[n++] = '"'; break; case '\\': o[n++] = '\\'; break; case '/': o[n++] = '/'; break;
            case 'b': o[n++] = '\b'; break; case 'f': o[n++] = '\f'; break; case 'n': o[n++] = '\n'; break;
            case 'r': o[n++] = '\r'; break; case 't': o[n++] = '\t'; break;
            case 'u': { uint32_t u; if (!hex4(s->p, &u)) { rf_free(o); rf_set_error("json: bad \\u"); return NULL; } s->p += 4;
                if (u >= 0xD800 && u < 0xDC00 && s->p[0] == '\\' && s->p[1] == 'u') { uint32_t lo; if (hex4(s->p + 2, &lo) && lo >= 0xDC00 && lo < 0xE000) { u = 0x10000 + ((u - 0xD800) << 10) + (lo - 0xDC00); s->p += 6; } }
                if (u < 0x80) o[n++] = (char)u; else if (u < 0x800) { o[n++] = (char)(0xC0 | u >> 6); o[n++] = (char)(0x80 | (u & 63)); }
                else if (u < 0x10000) { o[n++] = (char)(0xE0 | u >> 12); o[n++] = (char)(0x80 | (u >> 6 & 63)); o[n++] = (char)(0x80 | (u & 63)); }
                else { o[n++] = (char)(0xF0 | u >> 18); o[n++] = (char)(0x80 | (u >> 12 & 63)); o[n++] = (char)(0x80 | (u >> 6 & 63)); o[n++] = (char)(0x80 | (u & 63)); } break; }
            default: rf_free(o); rf_set_error("json: bad escape"); return NULL;
        }
    }
    s->p++; o[n] = 0; return o;
}
static RF_Json* val(P* s) {
    ws(s);
    if (++s->depth > 200) { rf_set_error("json: too deep"); return NULL; }
    RF_Json* r = NULL; char c = *s->p;
    if (c == '{' || c == '[') {
        int obj = c == '{'; char end = obj ? '}' : ']'; s->p++; r = obj ? rf_json_new_object() : rf_json_new_array(); ws(s);
        if (*s->p == end) { s->p++; s->depth--; return r; }
        for (;;) {
            char* key = NULL; ws(s);
            if (obj) { if (*s->p != '"') goto fail; key = pstr(s); if (!key) goto fail; ws(s); if (*s->p++ != ':') { rf_free(key); goto fail; } }
            RF_Json* it = val(s); if (!it) { rf_free(key); goto fail; }
            if (obj) { if (rf_json_object_set(r, key, it) != RF_OK) { rf_free(key); rf_json_free(it); goto fail; } rf_free(key); }
            else if (rf_json_array_push(r, it) != RF_OK) { rf_json_free(it); goto fail; }
            ws(s); if (*s->p == ',') { s->p++; continue; } if (*s->p == end) { s->p++; break; } goto fail;
        }
    } else if (c == '"') { char* t = pstr(s); if (!t) { s->depth--; return NULL; } r = mk(RF_JSON_STRING); if (r) r->str = t; else rf_free(t);
    } else if (!strncmp(s->p, "true", 4)) { s->p += 4; r = rf_json_new_bool(1);
    } else if (!strncmp(s->p, "false", 5)) { s->p += 5; r = rf_json_new_bool(0);
    } else if (!strncmp(s->p, "null", 4)) { s->p += 4; r = rf_json_new_null();
    } else if (c == '-' || (c >= '0' && c <= '9')) { char* e; double d = strtod(s->p, &e); if (e == s->p) goto fail; s->p = e; r = rf_json_new_number(d);
    } else goto fail;
    s->depth--; return r;
fail:
    rf_json_free(r); s->depth--; if (!*rf_last_error()) rf_set_error("json: syntax error near '%.12s'", s->p); return NULL;
}
RF_Json* rf_json_parse(const char* text) {
    if (!text) return NULL; rf_set_error(""); P s = { text, 0 }; RF_Json* r = val(&s); if (!r) return NULL;
    ws(&s); if (*s.p) { rf_json_free(r); rf_set_error("json: trailing data"); return NULL; } return r;
}

/* ---- serializer ---- */
typedef struct { char* s; size_t n, cap; int fail; } B;
static void bp(B* b, const char* t, size_t l) {
    if (b->fail) return; if (b->n + l + 1 > b->cap) { size_t nc = b->cap ? b->cap : 64; while (nc < b->n + l + 1) nc *= 2; char* ns = rf_realloc(b->s, nc); if (!ns) { b->fail = 1; return; } b->s = ns; b->cap = nc; }
    memcpy(b->s + b->n, t, l); b->n += l; b->s[b->n] = 0;
}
static void bs(B* b, const char* t) { bp(b, t, strlen(t)); }
static void ind(B* b, int pretty, int d) { if (!pretty) return; bp(b, "\n", 1); for (int i = 0; i < d; i++) bs(b, "  "); }
static void qstr(B* b, const char* s) {
    bp(b, "\"", 1);
    for (; *s; s++) { unsigned char c = (unsigned char)*s; char t[8];
        if (c == '"') bs(b, "\\\""); else if (c == '\\') bs(b, "\\\\"); else if (c == '\n') bs(b, "\\n"); else if (c == '\r') bs(b, "\\r"); else if (c == '\t') bs(b, "\\t");
        else if (c < 0x20) { snprintf(t, sizeof t, "\\u%04x", c); bs(b, t); } else bp(b, s, 1); }
    bp(b, "\"", 1);
}
static void ser(B* b, const RF_Json* j, int pretty, int d) {
    char t[40];
    switch (j->t) {
        case RF_JSON_NULL: bs(b, "null"); break; case RF_JSON_BOOL: bs(b, j->b ? "true" : "false"); break;
        case RF_JSON_NUMBER: if (isfinite(j->num)) { if (j->num == floor(j->num) && fabs(j->num) < 1e15) snprintf(t, sizeof t, "%.0f", j->num); else snprintf(t, sizeof t, "%.17g", j->num); bs(b, t); } else bs(b, "null"); break;
        case RF_JSON_STRING: qstr(b, j->str); break;
        default: { int obj = j->t == RF_JSON_OBJECT; bp(b, obj ? "{" : "[", 1);
            for (size_t i = 0; i < j->count; i++) { if (i) bp(b, ",", 1); ind(b, pretty, d + 1); if (obj) { qstr(b, j->keys[i]); bs(b, pretty ? ": " : ":"); } ser(b, j->items[i], pretty, d + 1); }
            if (j->count) ind(b, pretty, d); bp(b, obj ? "}" : "]", 1); }
    }
}
char* rf_json_stringify(const RF_Json* j, int pretty) {
    if (!j) return NULL; B b = { 0 }; ser(&b, j, pretty, 0); if (b.fail) { rf_free(b.s); return NULL; } return b.s;
}
