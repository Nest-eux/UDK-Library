#define RF_INPUT_BUILDING
#include "RF/Input.h"
#include "RF/Core.h"
#include <windows.h>

RF_DEFINE_MODULE(RF_INPUT_API, "RF.Input.C", "C")

static void put16(uint8_t* p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put32(uint8_t* p, uint32_t v) { for (int i = 0; i < 4; i++) p[i] = (uint8_t)(v >> (8 * i)); }
static RF_Status send1(INPUT* i) { return SendInput(1, i, sizeof *i) == 1 ? RF_OK : RF_ERR_WINAPI; }
RF_Status rf_input_key(uint16_t vk, int down) { INPUT i; memset(&i, 0, sizeof i); i.type = INPUT_KEYBOARD; i.ki.wVk = vk; i.ki.dwFlags = down ? 0 : KEYEVENTF_KEYUP; return send1(&i); }
RF_Status rf_input_key_press(uint16_t vk) { RF_Status s = rf_input_key(vk, 1); return s ? s : rf_input_key(vk, 0); }
RF_Status rf_input_type_text(const char* t) {
    wchar_t* w; RF_Status s = rf_utf8_to_utf16(t, &w); if (s) return s;
    for (const wchar_t* p = w; *p; p++) {
        INPUT i[2]; memset(i, 0, sizeof i);
        i[0].type = i[1].type = INPUT_KEYBOARD; i[0].ki.wScan = i[1].ki.wScan = *p; i[0].ki.dwFlags = KEYEVENTF_UNICODE; i[1].ki.dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYUP;
        if (SendInput(2, i, sizeof(INPUT)) != 2) { rf_free(w); return RF_ERR_WINAPI; }
    }
    rf_free(w); return RF_OK;
}
RF_Status rf_input_mouse_move(int x, int y) { return SetCursorPos(x, y) ? RF_OK : RF_ERR_WINAPI; }
RF_Status rf_input_mouse_click(int b, int dbl) {
    DWORD d = b == 1 ? MOUSEEVENTF_RIGHTDOWN : b == 2 ? MOUSEEVENTF_MIDDLEDOWN : MOUSEEVENTF_LEFTDOWN, u = b == 1 ? MOUSEEVENTF_RIGHTUP : b == 2 ? MOUSEEVENTF_MIDDLEUP : MOUSEEVENTF_LEFTUP;
    for (int k = 0; k < (dbl ? 2 : 1); k++) { INPUT i[2]; memset(i, 0, sizeof i); i[0].type = i[1].type = INPUT_MOUSE; i[0].mi.dwFlags = d; i[1].mi.dwFlags = u; if (SendInput(2, i, sizeof(INPUT)) != 2) return RF_ERR_WINAPI; }
    return RF_OK;
}
RF_Status rf_input_mouse_wheel(int delta) { INPUT i; memset(&i, 0, sizeof i); i.type = INPUT_MOUSE; i.mi.dwFlags = MOUSEEVENTF_WHEEL; i.mi.mouseData = (DWORD)delta; return send1(&i); }
RF_Status rf_cursor_pos(int* x, int* y) { POINT p; if (!GetCursorPos(&p)) return RF_ERR_WINAPI; if (x) *x = p.x; if (y) *y = p.y; return RF_OK; }
int rf_key_is_down(uint16_t vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; }

typedef struct { int used, id; uint32_t mod, vk; RF_HotkeyCb cb; void* user; HANDLE th; DWORD tid; HANDLE ready; int ok; } Hk;
static Hk g_hk[32];
static DWORD WINAPI hk_main(LPVOID p) {
    Hk* h = p; MSG m; PeekMessageW(&m, NULL, WM_USER, WM_USER, PM_NOREMOVE);
    h->ok = RegisterHotKey(NULL, 1, h->mod | MOD_NOREPEAT, h->vk); SetEvent(h->ready); if (!h->ok) return 1;
    while (GetMessageW(&m, NULL, 0, 0) > 0) if (m.message == WM_HOTKEY) h->cb(h->id, h->user);
    UnregisterHotKey(NULL, 1); return 0;
}
RF_Status rf_hotkey_register(int id, uint32_t mod, uint32_t vk, RF_HotkeyCb cb, void* user) {
    if (!cb) return RF_ERR_ARG; Hk* h = NULL; for (int i = 0; i < 32; i++) { if (g_hk[i].used && g_hk[i].id == id) return RF_ERR_ARG; if (!g_hk[i].used && !h) h = &g_hk[i]; }
    if (!h) return RF_ERR_NOMEM; memset(h, 0, sizeof *h); h->id = id; h->mod = mod; h->vk = vk; h->cb = cb; h->user = user; h->ready = CreateEventW(NULL, TRUE, FALSE, NULL);
    h->th = CreateThread(NULL, 0, hk_main, h, 0, &h->tid); WaitForSingleObject(h->ready, 3000); CloseHandle(h->ready);
    if (!h->ok) { WaitForSingleObject(h->th, 1000); CloseHandle(h->th); rf_set_error("RegisterHotKey failed (%lu)", GetLastError()); memset(h, 0, sizeof *h); return RF_ERR_WINAPI; }
    h->used = 1; return RF_OK;
}
void rf_hotkey_unregister(int id) {
    for (int i = 0; i < 32; i++) if (g_hk[i].used && g_hk[i].id == id) { PostThreadMessageW(g_hk[i].tid, WM_QUIT, 0, 0); WaitForSingleObject(g_hk[i].th, 2000); CloseHandle(g_hk[i].th); memset(&g_hk[i], 0, sizeof g_hk[i]); }
}
RF_Status rf_screen_size(int* w, int* h) { if (w) *w = GetSystemMetrics(SM_CXSCREEN); if (h) *h = GetSystemMetrics(SM_CYSCREEN); return RF_OK; }
RF_Status rf_screen_capture_bmp(int x, int y, int w, int h, void** out, size_t* size) {
    if (!out || !size) return RF_ERR_ARG; if (w <= 0 || h <= 0) { x = y = 0; w = GetSystemMetrics(SM_CXSCREEN); h = GetSystemMetrics(SM_CYSCREEN); }
    HDC sc = GetDC(NULL), mem = CreateCompatibleDC(sc); HBITMAP bm = CreateCompatibleBitmap(sc, w, h); HGDIOBJ old = SelectObject(mem, bm);
    BOOL ok = BitBlt(mem, 0, 0, w, h, sc, x, y, SRCCOPY | CAPTUREBLT);
    size_t stride = ((size_t)w * 3 + 3) & ~(size_t)3, img = stride * (size_t)h, total = 54 + img; uint8_t* b = ok ? rf_alloc(total) : NULL;
    if (b) {
        BITMAPINFO bi; memset(&bi, 0, sizeof bi); bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER); bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = h; bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 24; bi.bmiHeader.biCompression = BI_RGB;
        SelectObject(mem, old); ok = GetDIBits(mem, bm, 0, (UINT)h, b + 54, &bi, DIB_RGB_COLORS) != 0;
        memcpy(b, "BM", 2); put32(b + 2, (uint32_t)((uint32_t)total)); put32(b + 10, (uint32_t)(54)); put32(b + 14, (uint32_t)(40)); put32(b + 18, (uint32_t)(w)); put32(b + 22, (uint32_t)(h));
        put16(b + 26, (uint32_t)(1)); put16(b + 28, (uint32_t)(24)); put32(b + 34, (uint32_t)((uint32_t)img));
    } else SelectObject(mem, old);
    DeleteObject(bm); DeleteDC(mem); ReleaseDC(NULL, sc);
    if (!b || !ok) { rf_free(b); return RF_ERR_WINAPI; } *out = b; *size = total; return RF_OK;
}
