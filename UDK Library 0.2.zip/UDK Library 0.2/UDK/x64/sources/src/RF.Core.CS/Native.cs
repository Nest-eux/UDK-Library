using System.Runtime.InteropServices;
using System.Text;

namespace RF.Core;

public enum RFStatus { Ok = 0, Generic = -1, Arg = -2, NoMem = -3, IO = -4, NotFound = -5, WinApi = -6, Unsupported = -7 }

public class RFException : Exception
{
    public RFStatus Status { get; }
    public RFException(RFStatus s, string? detail = null) : base($"RF error {s}: {detail ?? Native.LastError()}") => Status = s;
}

/// <summary>Raw P/Invoke layer for RF.Core.C / RF.System.C / RF.Parallel.Cpp.</summary>
public static unsafe class Native
{
    const string Core = "RF.Core.C", Sys = "RF.System.C", Par = "RF.Parallel.Cpp";

    [DllImport(Core, CallingConvention = CallingConvention.Cdecl)] static extern IntPtr rf_version();
    [DllImport(Core, CallingConvention = CallingConvention.Cdecl)] static extern IntPtr rf_last_error();
    [DllImport(Core, CallingConvention = CallingConvention.Cdecl)] public static extern uint rf_crc32(byte* data, nuint n);
    [DllImport(Core, CallingConvention = CallingConvention.Cdecl)] public static extern ulong rf_fnv1a64(byte* data, nuint n);
    [DllImport(Core, CallingConvention = CallingConvention.Cdecl)] public static extern void rf_free(IntPtr p);

    [DllImport(Sys, CallingConvention = CallingConvention.Cdecl)] public static extern int rf_file_exists([MarshalAs(UnmanagedType.LPUTF8Str)] string path);
    [DllImport(Sys, CallingConvention = CallingConvention.Cdecl)] public static extern RFStatus rf_file_read_all([MarshalAs(UnmanagedType.LPUTF8Str)] string path, out IntPtr data, out nuint size);
    [DllImport(Sys, CallingConvention = CallingConvention.Cdecl)] public static extern RFStatus rf_file_write_all([MarshalAs(UnmanagedType.LPUTF8Str)] string path, byte* data, nuint size);
    [DllImport(Sys, CallingConvention = CallingConvention.Cdecl)] public static extern RFStatus rf_process_run([MarshalAs(UnmanagedType.LPUTF8Str)] string cmd, int wait, out uint exitCode);
    [DllImport(Sys, CallingConvention = CallingConvention.Cdecl)] public static extern RFStatus rf_process_kill(uint pid);
    [DllImport(Sys, CallingConvention = CallingConvention.Cdecl)] public static extern RFStatus rf_reg_read_string([MarshalAs(UnmanagedType.LPUTF8Str)] string root, [MarshalAs(UnmanagedType.LPUTF8Str)] string key, [MarshalAs(UnmanagedType.LPUTF8Str)] string? name, byte* buf, nuint size);
    [DllImport(Sys, CallingConvention = CallingConvention.Cdecl)] public static extern RFStatus rf_reg_write_string([MarshalAs(UnmanagedType.LPUTF8Str)] string root, [MarshalAs(UnmanagedType.LPUTF8Str)] string key, [MarshalAs(UnmanagedType.LPUTF8Str)] string? name, [MarshalAs(UnmanagedType.LPUTF8Str)] string value);
    [DllImport(Sys, CallingConvention = CallingConvention.Cdecl)] public static extern RFStatus rf_clipboard_get_text(out IntPtr text);
    [DllImport(Sys, CallingConvention = CallingConvention.Cdecl)] public static extern RFStatus rf_clipboard_set_text([MarshalAs(UnmanagedType.LPUTF8Str)] string text);
    [DllImport(Sys, CallingConvention = CallingConvention.Cdecl)] public static extern RFStatus rf_sysinfo(out SysInfoRaw info);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int ProcessCb(uint pid, IntPtr exeUtf8, IntPtr user);
    [DllImport(Sys, CallingConvention = CallingConvention.Cdecl)] public static extern RFStatus rf_process_enum(ProcessCb cb, IntPtr user);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int WindowCb(nuint hwnd, IntPtr titleUtf8, IntPtr user);
    [DllImport(Sys, CallingConvention = CallingConvention.Cdecl)] public static extern RFStatus rf_window_enum(WindowCb cb, IntPtr user);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate void ParBody(uint i, IntPtr user);
    [DllImport(Par, CallingConvention = CallingConvention.Cdecl)] public static extern RFStatus rfp_parallel_for(uint count, ParBody body, IntPtr user);

    [StructLayout(LayoutKind.Sequential)]
    public struct SysInfoRaw
    {
        public uint CpuCount; public ulong RamTotal, RamFree; public uint OsMajor, OsMinor, OsBuild;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)] public byte[] ComputerName;
    }

    public static string Version() => Marshal.PtrToStringUTF8(rf_version())!;
    public static string LastError() => Marshal.PtrToStringUTF8(rf_last_error()) ?? "";
    internal static void Check(RFStatus s) { if (s != RFStatus.Ok) throw new RFException(s); }
}
