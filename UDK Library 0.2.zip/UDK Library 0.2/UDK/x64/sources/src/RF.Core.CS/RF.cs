using System.Runtime.InteropServices;
using System.Text;

namespace RF.Core;

public record SysInfo(string ComputerName, uint CpuCount, ulong RamTotal, ulong RamFree, uint OsMajor, uint OsMinor, uint OsBuild);
public record ProcessEntry(uint Pid, string Name);
public record WindowEntry(nuint Handle, string Title);

/// <summary>High-level, safe C# API on top of the native RF libraries.</summary>
public static unsafe class RF
{
    public static string Version => Native.Version();

    public static uint Crc32(ReadOnlySpan<byte> data) { fixed (byte* p = data) return Native.rf_crc32(p, (nuint)data.Length); }

    public static byte[] ReadFile(string path)
    {
        Native.Check(Native.rf_file_read_all(path, out var ptr, out var size));
        try { var arr = new byte[(int)size]; Marshal.Copy(ptr, arr, 0, arr.Length); return arr; }
        finally { Native.rf_free(ptr); }
    }
    public static void WriteFile(string path, ReadOnlySpan<byte> data)
    { fixed (byte* p = data) Native.Check(Native.rf_file_write_all(path, p, (nuint)data.Length)); }

    public static uint RunProcess(string cmd, bool wait = true)
    { Native.Check(Native.rf_process_run(cmd, wait ? 1 : 0, out var code)); return code; }
    public static void KillProcess(uint pid) => Native.Check(Native.rf_process_kill(pid));

    public static List<ProcessEntry> Processes()
    {
        var list = new List<ProcessEntry>();
        Native.ProcessCb cb = (pid, name, _) => { list.Add(new(pid, Marshal.PtrToStringUTF8(name) ?? "")); return 1; };
        Native.Check(Native.rf_process_enum(cb, IntPtr.Zero)); GC.KeepAlive(cb); return list;
    }
    public static List<WindowEntry> Windows()
    {
        var list = new List<WindowEntry>();
        Native.WindowCb cb = (h, t, _) => { list.Add(new(h, Marshal.PtrToStringUTF8(t) ?? "")); return 1; };
        Native.Check(Native.rf_window_enum(cb, IntPtr.Zero)); GC.KeepAlive(cb); return list;
    }

    public static string? RegistryRead(string root, string key, string? name = null)
    {
        byte* buf = stackalloc byte[2048];
        var s = Native.rf_reg_read_string(root, key, name, buf, 2048);
        return s == RFStatus.Ok ? Marshal.PtrToStringUTF8((IntPtr)buf) : null;
    }
    public static void RegistryWrite(string root, string key, string? name, string value)
        => Native.Check(Native.rf_reg_write_string(root, key, name, value));

    public static string? ClipboardText
    {
        get { if (Native.rf_clipboard_get_text(out var p) != RFStatus.Ok) return null; try { return Marshal.PtrToStringUTF8(p); } finally { Native.rf_free(p); } }
        set => Native.Check(Native.rf_clipboard_set_text(value ?? ""));
    }

    public static SysInfo GetSysInfo()
    {
        Native.Check(Native.rf_sysinfo(out var r));
        var name = Encoding.UTF8.GetString(r.ComputerName).TrimEnd('\0');
        return new(name, r.CpuCount, r.RamTotal, r.RamFree, r.OsMajor, r.OsMinor, r.OsBuild);
    }

    public static void ParallelFor(int count, Action<int> body)
    {
        Native.ParBody cb = (i, _) => body((int)i);
        Native.Check(Native.rfp_parallel_for((uint)count, cb, IntPtr.Zero)); GC.KeepAlive(cb);
    }
}
