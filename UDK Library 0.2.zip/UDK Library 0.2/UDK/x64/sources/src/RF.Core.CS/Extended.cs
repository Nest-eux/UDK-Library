using System.Runtime.InteropServices;
using System.Text;

namespace RF.Core;

/// <summary>Raw P/Invoke for the extended RF libraries.</summary>
internal static unsafe class NativeX
{
    const string Crypto = "RF.Crypto.C", Comp = "RF.Compression.C", Pack = "RF.Package.C", FS = "RF.FileSystem.C",
                 Net = "RF.Net.C", Inp = "RF.Input.C", Aud = "RF.Audio.C", Img = "RF.Image.Cpp", Rx = "RF.Regex.Cpp", Core = "RF.Core.C";
    const CallingConvention C = CallingConvention.Cdecl;
    const UnmanagedType U8 = UnmanagedType.LPUTF8Str;

    [DllImport(Crypto, CallingConvention = C)] public static extern void rf_sha256(byte* d, nuint n, byte* o);
    [DllImport(Crypto, CallingConvention = C)] public static extern void rf_hmac_sha256(byte* k, nuint kl, byte* d, nuint n, byte* o);
    [DllImport(Crypto, CallingConvention = C)] public static extern void rf_pbkdf2_sha256(byte* p, nuint pl, byte* s, nuint sl, uint it, byte* o, nuint ol);
    [DllImport(Crypto, CallingConvention = C)] public static extern void rf_chacha20_xor(byte* key, byte* nonce, uint counter, byte* i, byte* o, nuint n);
    [DllImport(Crypto, CallingConvention = C)] public static extern RFStatus rf_random_bytes(byte* b, nuint n);

    [DllImport(Comp, CallingConvention = C)] public static extern RFStatus rf_lz_compress(byte* i, nuint n, out IntPtr o, out nuint on);
    [DllImport(Comp, CallingConvention = C)] public static extern RFStatus rf_lz_decompress(byte* i, nuint n, out IntPtr o, out nuint on);

    [DllImport(Pack, CallingConvention = C)] public static extern IntPtr rf_pack_new();
    [DllImport(Pack, CallingConvention = C)] public static extern void rf_pack_free(IntPtr p);
    [DllImport(Pack, CallingConvention = C)] public static extern RFStatus rf_pack_set_meta(IntPtr p, [MarshalAs(U8)] string k, [MarshalAs(U8)] string v);
    [DllImport(Pack, CallingConvention = C)] public static extern IntPtr rf_pack_meta(IntPtr p, [MarshalAs(U8)] string k);
    [DllImport(Pack, CallingConvention = C)] public static extern RFStatus rf_pack_add(IntPtr p, [MarshalAs(U8)] string name, byte* d, nuint n, int compress);
    [DllImport(Pack, CallingConvention = C)] public static extern nuint rf_pack_count(IntPtr p);
    [DllImport(Pack, CallingConvention = C)] public static extern IntPtr rf_pack_name(IntPtr p, nuint i);
    [DllImport(Pack, CallingConvention = C)] public static extern ulong rf_pack_size(IntPtr p, nuint i);
    [DllImport(Pack, CallingConvention = C)] public static extern RFStatus rf_pack_extract(IntPtr p, [MarshalAs(U8)] string name, out IntPtr d, out nuint n);
    [DllImport(Pack, CallingConvention = C)] public static extern RFStatus rf_pack_save_file(IntPtr p, [MarshalAs(U8)] string path);
    [DllImport(Pack, CallingConvention = C)] public static extern RFStatus rf_pack_open_file([MarshalAs(U8)] string path, out IntPtr p);

    [UnmanagedFunctionPointer(C)] public delegate void WatchCb(int action, IntPtr relUtf8, IntPtr user);
    [DllImport(FS, CallingConvention = C)] public static extern IntPtr rf_fs_watch_start([MarshalAs(U8)] string dir, int rec, WatchCb cb, IntPtr user);
    [DllImport(FS, CallingConvention = C)] public static extern void rf_fs_watch_stop(IntPtr w);

    [DllImport(Net, CallingConvention = C)] public static extern RFStatus rf_http_request([MarshalAs(U8)] string method, [MarshalAs(U8)] string url, [MarshalAs(U8)] string? headers, byte* body, nuint bl, out int status, out IntPtr resp, out nuint rl);

    [DllImport(Inp, CallingConvention = C)] public static extern RFStatus rf_input_key_press(ushort vk);
    [DllImport(Inp, CallingConvention = C)] public static extern RFStatus rf_input_type_text([MarshalAs(U8)] string t);
    [DllImport(Inp, CallingConvention = C)] public static extern RFStatus rf_input_mouse_move(int x, int y);
    [DllImport(Inp, CallingConvention = C)] public static extern RFStatus rf_input_mouse_click(int b, int dbl);
    [DllImport(Inp, CallingConvention = C)] public static extern RFStatus rf_screen_capture_bmp(int x, int y, int w, int h, out IntPtr bmp, out nuint n);

    [DllImport(Aud, CallingConvention = C)] public static extern RFStatus rf_audio_play_file([MarshalAs(U8)] string p, int async);
    [DllImport(Aud, CallingConvention = C)] public static extern RFStatus rf_audio_beep(uint f, uint ms);
    [DllImport(Aud, CallingConvention = C)] public static extern RFStatus rf_audio_record_wav(uint ms, uint rate, out IntPtr wav, out nuint n);

    [DllImport(Rx, CallingConvention = C)] public static extern IntPtr rfx_compile([MarshalAs(U8)] string p, int ic);
    [DllImport(Rx, CallingConvention = C)] public static extern void rfx_free(IntPtr r);
    [DllImport(Rx, CallingConvention = C)] public static extern int rfx_match_full(IntPtr r, [MarshalAs(U8)] string t);
    [DllImport(Rx, CallingConvention = C)] public static extern IntPtr rfx_replace(IntPtr r, [MarshalAs(U8)] string t, [MarshalAs(U8)] string rep);
    [DllImport(Rx, CallingConvention = C)] public static extern void rfx_free_string(IntPtr s);

    [DllImport(Core, CallingConvention = C)] public static extern void rf_free(IntPtr p);

    public static byte[] Take(IntPtr p, nuint n) { var a = new byte[(int)n]; Marshal.Copy(p, a, 0, a.Length); rf_free(p); return a; }
    public static void Ok(RFStatus s) { if (s != RFStatus.Ok) throw new RFException(s); }
}

public static unsafe class RFCrypto
{
    public static byte[] Sha256(ReadOnlySpan<byte> data) { var o = new byte[32]; fixed (byte* d = data) fixed (byte* p = o) NativeX.rf_sha256(d, (nuint)data.Length, p); return o; }
    public static byte[] Sha256(string text) => Sha256(Encoding.UTF8.GetBytes(text));
    public static byte[] HmacSha256(ReadOnlySpan<byte> key, ReadOnlySpan<byte> data)
    { var o = new byte[32]; fixed (byte* k = key) fixed (byte* d = data) fixed (byte* p = o) NativeX.rf_hmac_sha256(k, (nuint)key.Length, d, (nuint)data.Length, p); return o; }
    public static byte[] Pbkdf2(ReadOnlySpan<byte> password, ReadOnlySpan<byte> salt, uint iterations, int length)
    { var o = new byte[length]; fixed (byte* p = password) fixed (byte* s = salt) fixed (byte* r = o) NativeX.rf_pbkdf2_sha256(p, (nuint)password.Length, s, (nuint)salt.Length, iterations, r, (nuint)length); return o; }
    /// <summary>ChaCha20 stream cipher (encrypt == decrypt). key = 32 bytes, nonce = 12 bytes. Not authenticated: add an HMAC.</summary>
    public static byte[] ChaCha20(byte[] key, byte[] nonce, ReadOnlySpan<byte> data, uint counter = 1)
    {
        if (key.Length != 32 || nonce.Length != 12) throw new ArgumentException("key must be 32 bytes, nonce 12 bytes");
        var o = new byte[data.Length]; fixed (byte* k = key) fixed (byte* n = nonce) fixed (byte* i = data) fixed (byte* r = o) NativeX.rf_chacha20_xor(k, n, counter, i, r, (nuint)data.Length); return o;
    }
    public static byte[] Random(int n) { var o = new byte[n]; fixed (byte* p = o) NativeX.Ok(NativeX.rf_random_bytes(p, (nuint)n)); return o; }
}

public static unsafe class RFCompression
{
    public static byte[] Compress(ReadOnlySpan<byte> d) { fixed (byte* p = d) { NativeX.Ok(NativeX.rf_lz_compress(p, (nuint)d.Length, out var o, out var n)); return NativeX.Take(o, n); } }
    public static byte[] Decompress(ReadOnlySpan<byte> d) { fixed (byte* p = d) { NativeX.Ok(NativeX.rf_lz_decompress(p, (nuint)d.Length, out var o, out var n)); return NativeX.Take(o, n); } }
}

/// <summary>A .udklib package: manifest + compressed CRC-checked entries.</summary>
public sealed unsafe class UdkPackage : IDisposable
{
    IntPtr _p;
    UdkPackage(IntPtr p) => _p = p;
    public static UdkPackage Create() => new(NativeX.rf_pack_new());
    public static UdkPackage Open(string path) { NativeX.Ok(NativeX.rf_pack_open_file(path, out var p)); return new(p); }
    public void SetMeta(string key, string value) => NativeX.Ok(NativeX.rf_pack_set_meta(_p, key, value));
    public string? Meta(string key) => Marshal.PtrToStringUTF8(NativeX.rf_pack_meta(_p, key));
    public void Add(string name, ReadOnlySpan<byte> data, bool compress = true) { fixed (byte* d = data) NativeX.Ok(NativeX.rf_pack_add(_p, name, d, (nuint)data.Length, compress ? 1 : 0)); }
    public void AddFile(string name, string path, bool compress = true) => Add(name, File.ReadAllBytes(path), compress);
    public IEnumerable<(string Name, ulong Size)> Entries()
    { for (nuint i = 0, n = NativeX.rf_pack_count(_p); i < n; i++) yield return (Marshal.PtrToStringUTF8(NativeX.rf_pack_name(_p, i))!, NativeX.rf_pack_size(_p, i)); }
    public byte[] Extract(string name) { NativeX.Ok(NativeX.rf_pack_extract(_p, name, out var d, out var n)); return NativeX.Take(d, n); }
    public void Save(string path) => NativeX.Ok(NativeX.rf_pack_save_file(_p, path));
    public void Dispose() { if (_p != IntPtr.Zero) { NativeX.rf_pack_free(_p); _p = IntPtr.Zero; } GC.SuppressFinalize(this); }
    ~UdkPackage() => Dispose();
}

public enum WatchAction { Added = 1, Removed = 2, Modified = 3, RenamedOld = 4, RenamedNew = 5 }

public sealed class FileWatcher : IDisposable
{
    IntPtr _w; readonly NativeX.WatchCb _cb;  // keep delegate alive
    public FileWatcher(string dir, bool recursive, Action<WatchAction, string> onChange)
    {
        _cb = (a, p, _) => onChange((WatchAction)a, Marshal.PtrToStringUTF8(p) ?? "");
        _w = NativeX.rf_fs_watch_start(dir, recursive ? 1 : 0, _cb, IntPtr.Zero);
        if (_w == IntPtr.Zero) throw new RFException(RFStatus.IO);
    }
    public void Dispose() { if (_w != IntPtr.Zero) { NativeX.rf_fs_watch_stop(_w); _w = IntPtr.Zero; } GC.SuppressFinalize(this); }
}

public static unsafe class RFNet
{
    public record HttpResult(int Status, byte[] Body) { public string Text => Encoding.UTF8.GetString(Body); }
    public static HttpResult Http(string method, string url, string? headers = null, byte[]? body = null)
    {
        fixed (byte* b = body) { NativeX.Ok(NativeX.rf_http_request(method, url, headers, b, (nuint)(body?.Length ?? 0), out var st, out var r, out var n)); return new(st, NativeX.Take(r, n)); }
    }
    public static HttpResult Get(string url) => Http("GET", url);
    public static HttpResult PostJson(string url, string json) => Http("POST", url, "Content-Type: application/json", Encoding.UTF8.GetBytes(json));
}

public static class RFInput
{
    public static void Press(ushort vk) => NativeX.Ok(NativeX.rf_input_key_press(vk));
    public static void Type(string text) => NativeX.Ok(NativeX.rf_input_type_text(text));
    public static void MoveMouse(int x, int y) => NativeX.Ok(NativeX.rf_input_mouse_move(x, y));
    public static void Click(int button = 0, bool dbl = false) => NativeX.Ok(NativeX.rf_input_mouse_click(button, dbl ? 1 : 0));
    /// <summary>Returns a BMP file; (0,0,0,0) = whole primary screen.</summary>
    public static byte[] Screenshot(int x = 0, int y = 0, int w = 0, int h = 0) { NativeX.Ok(NativeX.rf_screen_capture_bmp(x, y, w, h, out var b, out var n)); return NativeX.Take(b, n); }
}

public static class RFAudio
{
    public static void Play(string wavPath, bool async = true) => NativeX.Ok(NativeX.rf_audio_play_file(wavPath, async ? 1 : 0));
    public static void Beep(uint hz = 800, uint ms = 200) => NativeX.Ok(NativeX.rf_audio_beep(hz, ms));
    public static byte[] RecordWav(uint ms, uint sampleRate = 16000) { NativeX.Ok(NativeX.rf_audio_record_wav(ms, sampleRate, out var w, out var n)); return NativeX.Take(w, n); }
}

public sealed class RFRegex : IDisposable
{
    IntPtr _r;
    public RFRegex(string pattern, bool ignoreCase = false) { _r = NativeX.rfx_compile(pattern, ignoreCase ? 1 : 0); if (_r == IntPtr.Zero) throw new ArgumentException("invalid regex"); }
    public bool IsFullMatch(string text) => NativeX.rfx_match_full(_r, text) != 0;
    public string Replace(string text, string replacement)
    { var p = NativeX.rfx_replace(_r, text, replacement); try { return Marshal.PtrToStringUTF8(p) ?? ""; } finally { NativeX.rfx_free_string(p); } }
    public void Dispose() { if (_r != IntPtr.Zero) { NativeX.rfx_free(_r); _r = IntPtr.Zero; } GC.SuppressFinalize(this); }
}
