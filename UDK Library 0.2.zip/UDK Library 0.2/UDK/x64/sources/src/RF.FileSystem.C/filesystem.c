#define RF_FILESYSTEM_BUILDING
#include "RF/FileSystem.h"
#include "RF/Core.h"
#include <windows.h>
#include <shlobj.h>
#include <stdlib.h>

RF_DEFINE_MODULE(RF_FILESYSTEM_API, "RF.FileSystem.C", "C")

static wchar_t* W(const char* s) { wchar_t* w = NULL; return rf_utf8_to_utf16(s, &w) == RF_OK ? w : NULL; }
static char* U(const wchar_t* w) { char* c = NULL; return rf_utf16_to_utf8(w, &c) == RF_OK ? c : NULL; }
static RF_Status werr(const char* what) { rf_set_error("%s failed (%lu)", what, GetLastError()); return GetLastError() == ERROR_FILE_NOT_FOUND || GetLastError() == ERROR_PATH_NOT_FOUND ? RF_ERR_NOTFOUND : RF_ERR_IO; }

RF_Status rf_fs_list(const char* dir, RF_DirCb cb, void* user) {
    if (!dir || !cb) return RF_ERR_ARG; size_t n = strlen(dir); char* pat = rf_alloc(n + 3); if (!pat) return RF_ERR_NOMEM;
    memcpy(pat, dir, n); if (n && dir[n-1] != '\\' && dir[n-1] != '/') pat[n++] = '\\'; pat[n++] = '*';
    wchar_t* w = W(pat); rf_free(pat); if (!w) return RF_ERR_ARG;
    WIN32_FIND_DATAW fd; HANDLE h = FindFirstFileW(w, &fd); rf_free(w); if (h == INVALID_HANDLE_VALUE) return werr("FindFirstFile");
    do {
        if (!wcscmp(fd.cFileName, L".") || !wcscmp(fd.cFileName, L"..")) continue;
        char* nm = U(fd.cFileName); if (!nm) continue;
        int cont = cb(nm, (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0, ((uint64_t)fd.nFileSizeHigh << 32) | fd.nFileSizeLow, user); rf_free(nm);
        if (!cont) break;
    } while (FindNextFileW(h, &fd));
    FindClose(h); return RF_OK;
}
RF_Status rf_fs_mkdir(const char* path) {
    wchar_t* w = W(path); if (!w) return RF_ERR_ARG; size_t n = wcslen(w); RF_Status s = RF_OK;
    for (size_t i = 1; i <= n; i++) if (w[i] == L'\\' || w[i] == L'/' || w[i] == 0) {
        wchar_t c = w[i]; w[i] = 0;
        if (!(i == 2 && w[1] == L':') && !CreateDirectoryW(w, NULL) && GetLastError() != ERROR_ALREADY_EXISTS) { s = werr("CreateDirectory"); w[i] = c; break; }
        w[i] = c;
    }
    rf_free(w); return s;
}
RF_Status rf_fs_copy(const char* a, const char* b, int ow) { wchar_t *x = W(a), *y = W(b); RF_Status s = RF_ERR_ARG; if (x && y) s = CopyFileW(x, y, !ow) ? RF_OK : werr("CopyFile"); rf_free(x); rf_free(y); return s; }
RF_Status rf_fs_move(const char* a, const char* b) { wchar_t *x = W(a), *y = W(b); RF_Status s = RF_ERR_ARG; if (x && y) s = MoveFileExW(x, y, MOVEFILE_COPY_ALLOWED | MOVEFILE_REPLACE_EXISTING) ? RF_OK : werr("MoveFile"); rf_free(x); rf_free(y); return s; }
RF_Status rf_fs_delete(const char* p) {
    wchar_t* w = W(p); if (!w) return RF_ERR_ARG; DWORD a = GetFileAttributesW(w); RF_Status s;
    if (a == INVALID_FILE_ATTRIBUTES) s = werr("GetFileAttributes");
    else if (a & FILE_ATTRIBUTE_DIRECTORY) s = RemoveDirectoryW(w) ? RF_OK : werr("RemoveDirectory");
    else s = DeleteFileW(w) ? RF_OK : werr("DeleteFile");
    rf_free(w); return s;
}
static int del_cb(const char* name, int is_dir, uint64_t size, void* user) {
    (void)size; const char* base = user; char* full = rf_path_join(base, name); if (!full) return 0;
    if (is_dir) rf_fs_delete_tree(full); else rf_fs_delete(full); rf_free(full); return 1;
}
RF_Status rf_fs_delete_tree(const char* p) {
    if (!rf_fs_is_dir(p)) return rf_fs_delete(p);
    rf_fs_list(p, del_cb, (void*)p); return rf_fs_delete(p);
}
int rf_fs_is_dir(const char* p) { wchar_t* w = W(p); if (!w) return 0; DWORD a = GetFileAttributesW(w); rf_free(w); return a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY); }
int64_t rf_fs_file_size(const char* p) {
    wchar_t* w = W(p); if (!w) return -1; WIN32_FILE_ATTRIBUTE_DATA d; BOOL ok = GetFileAttributesExW(w, GetFileExInfoStandard, &d); rf_free(w);
    return ok ? (int64_t)(((uint64_t)d.nFileSizeHigh << 32) | d.nFileSizeLow) : -1;
}
char* rf_path_join(const char* a, const char* b) {
    if (!a || !b) return NULL; size_t la = strlen(a); int sep = la && a[la-1] != '\\' && a[la-1] != '/';
    char* o = rf_alloc(la + strlen(b) + 2); if (!o) return NULL; memcpy(o, a, la); if (sep) o[la++] = '\\'; strcpy(o + la, b); return o;
}
static const char* last_sep(const char* p) { const char *a = strrchr(p, '\\'), *b = strrchr(p, '/'); return a > b ? a : b; }
char* rf_path_filename(const char* p) { if (!p) return NULL; const char* s = last_sep(p); return rf_strdup(s ? s + 1 : p); }
char* rf_path_dir(const char* p) { if (!p) return NULL; const char* s = last_sep(p); if (!s) return rf_strdup(""); size_t n = (size_t)(s - p); char* o = rf_alloc(n + 1); if (o) memcpy(o, p, n); return o; }
char* rf_path_ext(const char* p) { if (!p) return NULL; const char* s = last_sep(p); const char* d = strrchr(s ? s : p, '.'); return rf_strdup(d && d != (s ? s + 1 : p) ? d : ""); }

RF_Status rf_fs_known_folder(const char* which, char** out) {
    if (!which || !out) return RF_ERR_ARG; wchar_t buf[MAX_PATH * 2]; buf[0] = 0; int csidl = -1;
    if (!strcmp(which, "temp")) GetTempPathW(MAX_PATH * 2, buf);
    else if (!strcmp(which, "exe")) GetModuleFileNameW(NULL, buf, MAX_PATH * 2);
    else if (!strcmp(which, "cwd")) GetCurrentDirectoryW(MAX_PATH * 2, buf);
    else if (!strcmp(which, "appdata")) csidl = CSIDL_APPDATA; else if (!strcmp(which, "localappdata")) csidl = CSIDL_LOCAL_APPDATA;
    else if (!strcmp(which, "documents")) csidl = CSIDL_PERSONAL; else if (!strcmp(which, "desktop")) csidl = CSIDL_DESKTOPDIRECTORY;
    else if (!strcmp(which, "home")) csidl = CSIDL_PROFILE; else return RF_ERR_ARG;
    if (csidl >= 0 && FAILED(SHGetFolderPathW(NULL, csidl, NULL, 0, buf))) return RF_ERR_WINAPI;
    return rf_utf16_to_utf8(buf, out);
}

struct RF_Watch { HANDLE dir, thread, stop; int rec; RF_WatchCb cb; void* user; };
static DWORD WINAPI watch_main(LPVOID p) {
    RF_Watch* w = p; BYTE buf[65536] __attribute__((aligned(8))); OVERLAPPED ov; memset(&ov, 0, sizeof ov); ov.hEvent = CreateEventW(NULL, TRUE, FALSE, NULL);
    HANDLE ev[2] = { ov.hEvent, w->stop };
    for (;;) {
        ResetEvent(ov.hEvent); DWORD got = 0;
        if (!ReadDirectoryChangesW(w->dir, buf, sizeof buf, w->rec, FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_DIR_NAME | FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_SIZE, NULL, &ov, NULL)) break;
        if (WaitForMultipleObjects(2, ev, FALSE, INFINITE) != WAIT_OBJECT_0) { CancelIoEx(w->dir, &ov); GetOverlappedResult(w->dir, &ov, &got, TRUE); break; }
        if (!GetOverlappedResult(w->dir, &ov, &got, FALSE) || !got) continue;
        FILE_NOTIFY_INFORMATION* fi = (FILE_NOTIFY_INFORMATION*)buf;
        for (;;) {
            wchar_t* nm = rf_alloc(fi->FileNameLength + 2); memcpy(nm, fi->FileName, fi->FileNameLength); char* u = U(nm); rf_free(nm);
            int act = fi->Action == FILE_ACTION_ADDED ? RF_WATCH_ADDED : fi->Action == FILE_ACTION_REMOVED ? RF_WATCH_REMOVED : fi->Action == FILE_ACTION_MODIFIED ? RF_WATCH_MODIFIED : fi->Action == FILE_ACTION_RENAMED_OLD_NAME ? RF_WATCH_RENAMED_OLD : RF_WATCH_RENAMED_NEW;
            if (u) { w->cb(act, u, w->user); rf_free(u); }
            if (!fi->NextEntryOffset) break; fi = (FILE_NOTIFY_INFORMATION*)((BYTE*)fi + fi->NextEntryOffset);
        }
    }
    CloseHandle(ov.hEvent); return 0;
}
RF_Watch* rf_fs_watch_start(const char* dir, int rec, RF_WatchCb cb, void* user) {
    wchar_t* wd = W(dir); if (!wd || !cb) { rf_free(wd); return NULL; }
    HANDLE h = CreateFileW(wd, FILE_LIST_DIRECTORY, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OVERLAPPED, NULL); rf_free(wd);
    if (h == INVALID_HANDLE_VALUE) { werr("open dir"); return NULL; }
    RF_Watch* w = rf_alloc(sizeof *w); w->dir = h; w->rec = rec; w->cb = cb; w->user = user; w->stop = CreateEventW(NULL, TRUE, FALSE, NULL);
    w->thread = CreateThread(NULL, 0, watch_main, w, 0, NULL); return w;
}
void rf_fs_watch_stop(RF_Watch* w) { if (!w) return; SetEvent(w->stop); WaitForSingleObject(w->thread, 5000); CloseHandle(w->thread); CloseHandle(w->stop); CloseHandle(w->dir); rf_free(w); }
