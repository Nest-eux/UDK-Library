using System.Windows;
using RF.UI;

namespace RFTest;

public static class Program
{
    [STAThread]
    public static void Main()
    {
        var app = new Application { ShutdownMode = ShutdownMode.OnMainWindowClose };
        RFTheme.Apply(app);
        app.Run(new MainWindow());
    }
}
