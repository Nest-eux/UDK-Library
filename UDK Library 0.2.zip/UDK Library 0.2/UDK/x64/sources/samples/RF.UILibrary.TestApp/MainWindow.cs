using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using RF.Core;
using RF.UI;

namespace RFTest;

/// <summary>Test application for RF.UILibrary.CS: shows every UI control and exercises the native libraries.</summary>
public class MainWindow : RFWindow
{
    readonly LogView _selfTestLog = new();
    readonly LogView _cryptoLog = new();
    readonly LogView _toolsLog = new();
    readonly LogView _netLog = new();
    readonly TextBox _cryptoInput = new() { Text = "hello RF UDK", Width = 360, Margin = new Thickness(4) };
    readonly TextBox _url = new() { Text = "https://example.com", Width = 360, Margin = new Thickness(4) };

    public MainWindow()
    {
        Title = "RF.UILibrary.CS - test application";
        Width = 960; Height = 640;

        var tabs = new TabControl();
        tabs.Items.Add(Tab("Self-tests", BuildSelfTests()));
        tabs.Items.Add(Tab("System", new SystemInfoPanel()));
        tabs.Items.Add(Tab("Processes", new ProcessListView()));
        tabs.Items.Add(Tab("File watcher", BuildFileWatch()));
        tabs.Items.Add(Tab("Crypto", BuildCrypto()));
        tabs.Items.Add(Tab("Network", BuildNetwork()));
        tabs.Items.Add(Tab("Tools", BuildTools()));
        Content = tabs;
        Loaded += (_, _) => RunSelfTests();
    }

    // ---------- layout helpers ----------
    static TabItem Tab(string title, UIElement content)
    {
        var panel = new Border { Padding = new Thickness(8), Child = content, Background = (Brush)Application.Current.FindResource("RF.PanelBrush") };
        TextElement.SetForeground(panel, (Brush)Application.Current.FindResource("RF.TextBrush"));
        return new TabItem { Header = new TextBlock { Text = title, Foreground = Brushes.Black }, Content = panel };
    }
    static DockPanel WithLog(Panel bar, LogView log)
    {
        var d = new DockPanel(); DockPanel.SetDock(bar, Dock.Top); d.Children.Add(bar); d.Children.Add(log); return d;
    }
    static StackPanel Bar(params UIElement[] items)
    {
        var s = new StackPanel { Orientation = Orientation.Horizontal };
        foreach (var i in items) s.Children.Add(i);
        return s;
    }

    // ---------- self tests ----------
    UIElement BuildSelfTests() => WithLog(Bar(RFControls.Button("Run all self-tests", (_, _) => { _selfTestLog.Items.Clear(); RunSelfTests(); })), _selfTestLog);

    void Check(string name, Func<bool> test)
    {
        try { _selfTestLog.Append((test() ? "PASS  " : "FAIL  ") + name); }
        catch (Exception e) { _selfTestLog.Append($"FAIL  {name}: {e.GetType().Name}: {e.Message}"); }
    }
    static string Hex(byte[] b) => Convert.ToHexString(b).ToLowerInvariant();

    void RunSelfTests()
    {
        _selfTestLog.Append("RF UDK version: " + RF.Core.RF.Version);
        Check("version string", () => RF.Core.RF.Version.Contains("RF UDK"));
        Check("CRC32 (\"123456789\" = CBF43926)", () => RF.Core.RF.Crc32(Encoding.ASCII.GetBytes("123456789")) == 0xCBF43926);
        Check("SHA-256 (\"abc\")", () => Hex(RFCrypto.Sha256("abc")) == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
        Check("HMAC-SHA256 (RFC 4231 case 2)", () => Hex(RFCrypto.HmacSha256(Encoding.ASCII.GetBytes("Jefe"), Encoding.ASCII.GetBytes("what do ya want for nothing?")))
                                                     == "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843");
        Check("PBKDF2-SHA256 (RFC 7914 vector)", () => Hex(RFCrypto.Pbkdf2(Encoding.ASCII.GetBytes("password"), Encoding.ASCII.GetBytes("salt"), 1, 32))
                                                      == "120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b");
        Check("ChaCha20 round-trip", () =>
        {
            var key = RFCrypto.Random(32); var nonce = RFCrypto.Random(12); var plain = Encoding.UTF8.GetBytes("Привет, RF!");
            var ct = RFCrypto.ChaCha20(key, nonce, plain);
            return !ct.AsSpan().SequenceEqual(plain) && RFCrypto.ChaCha20(key, nonce, ct).AsSpan().SequenceEqual(plain);
        });
        Check("secure random differs", () => !RFCrypto.Random(16).AsSpan().SequenceEqual(RFCrypto.Random(16)));
        Check("LZ compress/decompress", () =>
        {
            var data = Encoding.UTF8.GetBytes(string.Concat(Enumerable.Repeat("RF UDK ", 20000)));
            var c = RFCompression.Compress(data); _selfTestLog.Append($"      {data.Length} -> {c.Length} bytes");
            return c.Length < data.Length / 10 && RFCompression.Decompress(c).AsSpan().SequenceEqual(data);
        });
        Check(".udklib create / open / extract", () =>
        {
            var path = Path.Combine(Path.GetTempPath(), "rf_selftest.udklib");
            using (var p = UdkPackage.Create()) { p.SetMeta("name", "selftest"); p.Add("a.txt", Encoding.UTF8.GetBytes("alpha")); p.Add("dir/b.bin", new byte[5000]); p.Save(path); }
            using var q = UdkPackage.Open(path);
            return q.Meta("name") == "selftest" && q.Entries().Count() == 2 && Encoding.UTF8.GetString(q.Extract("a.txt")) == "alpha" && q.Extract("dir/b.bin").Length == 5000;
        });
        Check(".udklib corruption is detected", () =>
        {
            var path = Path.Combine(Path.GetTempPath(), "rf_selftest_bad.udklib");
            using (var p = UdkPackage.Create()) { p.Add("x.bin", RFCrypto.Random(4000), false); p.Save(path); }
            var bytes = File.ReadAllBytes(path); bytes[bytes.Length / 3] ^= 0xFF; File.WriteAllBytes(path, bytes);
            try { using var q = UdkPackage.Open(path); q.Extract("x.bin"); return false; } catch (RFException) { return true; }
        });
        Check("file write/read (UTF-8 path)", () =>
        {
            var path = Path.Combine(Path.GetTempPath(), "rf_тест.bin"); var data = RFCrypto.Random(1 << 20);
            RF.Core.RF.WriteFile(path, data); return RF.Core.RF.ReadFile(path).AsSpan().SequenceEqual(data);
        });
        Check("system info", () => { var i = RF.Core.RF.GetSysInfo(); return i.CpuCount > 0 && i.RamTotal > 0 && i.OsMajor >= 10; });
        Check("process list contains this process", () => RF.Core.RF.Processes().Any(p => p.Pid == (uint)Environment.ProcessId));
        Check("clipboard round-trip", () => { RF.Core.RF.ClipboardText = "RF clipboard ✓"; return RF.Core.RF.ClipboardText == "RF clipboard ✓"; });
        Check("registry write/read (HKCU)", () =>
        {
            RF.Core.RF.RegistryWrite("HKCU", @"Software\RF-UDK-Test", "value", "ok"); return RF.Core.RF.RegistryRead("HKCU", @"Software\RF-UDK-Test", "value") == "ok";
        });
        Check("regex", () => { using var r = new RFRegex(@"(\w+)@(\w+)\.com"); return r.IsFullMatch("a@b.com") && r.Replace("bob@site.com", "$2:$1") == "site:bob"; });
        Check("parallel for (sum 0..999 = 499500)", () => { long sum = 0; RF.Core.RF.ParallelFor(1000, i => Interlocked.Add(ref sum, i)); return sum == 499500; });
        Check("screenshot is a BMP", () => { var bmp = RFInput.Screenshot(); return bmp.Length > 1000 && bmp[0] == 'B' && bmp[1] == 'M'; });
        _selfTestLog.Append("done.");
    }

    // ---------- file watcher ----------
    UIElement BuildFileWatch()
    {
        return new FileWatchPanel { Path = System.IO.Path.GetTempPath() };
    }

    // ---------- crypto ----------
    UIElement BuildCrypto()
    {
        var key = RFCrypto.Random(32);
        string? lastSealed = null;
        byte[] Seal(byte[] plain)
        {
            var nonce = RFCrypto.Random(12); var ct = RFCrypto.ChaCha20(key, nonce, plain);
            var tag = RFCrypto.HmacSha256(key, nonce.Concat(ct).ToArray());
            return nonce.Concat(tag).Concat(ct).ToArray();
        }
        var bar = Bar(_cryptoInput,
            RFControls.Button("SHA-256", (_, _) => _cryptoLog.Append("SHA-256: " + Hex(RFCrypto.Sha256(_cryptoInput.Text)))),
            RFControls.Button("Encrypt", (_, _) => { lastSealed = Convert.ToBase64String(Seal(Encoding.UTF8.GetBytes(_cryptoInput.Text))); _cryptoLog.Append("sealed: " + lastSealed); }),
            RFControls.Button("Decrypt last", (_, _) =>
            {
                if (lastSealed is null) { _cryptoLog.Append("nothing encrypted yet"); return; }
                var blob = Convert.FromBase64String(lastSealed); var nonce = blob[..12]; var tag = blob[12..44]; var ct = blob[44..];
                var expect = RFCrypto.HmacSha256(key, nonce.Concat(ct).ToArray());
                _cryptoLog.Append(System.Security.Cryptography.CryptographicOperations.FixedTimeEquals(expect, tag)
                    ? "decrypted: " + Encoding.UTF8.GetString(RFCrypto.ChaCha20(key, nonce, ct)) : "authentication FAILED");
            }),
            RFControls.Button("Tamper + decrypt", (_, _) =>
            {
                if (lastSealed is null) { _cryptoLog.Append("nothing encrypted yet"); return; }
                var blob = Convert.FromBase64String(lastSealed); blob[^1] ^= 1; var nonce = blob[..12]; var tag = blob[12..44]; var ct = blob[44..];
                var ok = System.Security.Cryptography.CryptographicOperations.FixedTimeEquals(RFCrypto.HmacSha256(key, nonce.Concat(ct).ToArray()), tag);
                _cryptoLog.Append(ok ? "BUG: tampered data accepted" : "tampered data rejected (expected)");
            }));
        return WithLog(bar, _cryptoLog);
    }

    // ---------- network ----------
    UIElement BuildNetwork()
    {
        var bar = Bar(_url, RFControls.Button("HTTP GET", async (_, _) =>
        {
            var url = _url.Text; _netLog.Append("GET " + url);
            try
            {
                var sw = Stopwatch.StartNew();
                var r = await Task.Run(() => RFNet.Get(url));
                var t = r.Text; _netLog.Append($"status {r.Status}, {r.Body.Length} bytes, {sw.ElapsedMilliseconds} ms");
                _netLog.Append(t.Length > 200 ? t[..200].Replace('\n', ' ') + "..." : t.Replace('\n', ' '));
            }
            catch (Exception e) { _netLog.Append("error: " + e.Message); }
        }));
        return WithLog(bar, _netLog);
    }

    // ---------- misc tools ----------
    UIElement BuildTools()
    {
        var bar = Bar(
            RFControls.Button("Beep", (_, _) => { try { RFAudio.Beep(880, 150); _toolsLog.Append("beep"); } catch (Exception e) { _toolsLog.Append(e.Message); } }),
            RFControls.Button("Screenshot -> temp", (_, _) =>
            {
                try
                {
                    var path = Path.Combine(Path.GetTempPath(), $"rf_shot_{DateTime.Now:HHmmss}.bmp"); File.WriteAllBytes(path, RFInput.Screenshot());
                    _toolsLog.Append("saved " + path); Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
                }
                catch (Exception e) { _toolsLog.Append(e.Message); }
            }),
            RFControls.Button("Windows list", (_, _) =>
            {
                var w = RF.Core.RF.Windows(); _toolsLog.Append($"{w.Count} visible windows"); foreach (var x in w.Take(15)) _toolsLog.Append("  " + x.Title);
            }),
            RFControls.Button("Known folders", (_, _) => { _toolsLog.Append("temp: " + Path.GetTempPath()); _toolsLog.Append("exe: " + Environment.ProcessPath); }));
        return WithLog(bar, _toolsLog);
    }
}
