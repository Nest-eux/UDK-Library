#ifndef RF_MATH_HPP
#define RF_MATH_HPP
#include "Common.h"
#ifdef RF_MATH_BUILDING
 #define RF_MATH_API extern "C" RF_DLLEXPORT
#else
 #define RF_MATH_API extern "C" RF_DLLIMPORT
#endif
/* RF.Math.Cpp - matrices, 4x4 transforms, vectors, statistics, linear solver */
/* mat4: float[16], column-major (OpenGL style) */
RF_MATH_API void   rfm_mat4_identity(float* m);
RF_MATH_API void   rfm_mat4_mul(const float* a, const float* b, float* out);
RF_MATH_API void   rfm_mat4_translate(float* m, float x, float y, float z);
RF_MATH_API void   rfm_mat4_scale(float* m, float x, float y, float z);
RF_MATH_API void   rfm_mat4_rotate(float* m, float radians, float ax, float ay, float az);
RF_MATH_API void   rfm_mat4_perspective(float* m, float fov_y_rad, float aspect, float znear, float zfar);
RF_MATH_API int    rfm_mat4_invert(const float* m, float* out);   /* 0 if singular */
RF_MATH_API void   rfm_vec3_cross(const float* a, const float* b, float* out);
RF_MATH_API float  rfm_vec3_dot(const float* a, const float* b);
RF_MATH_API void   rfm_vec3_normalize(const float* a, float* out);
/* general dense matrices: row-major doubles */
RF_MATH_API int    rfm_mat_mul(const double* a, int ar, int ac, const double* b, int bc, double* out); /* out is ar x bc */
RF_MATH_API int    rfm_solve(const double* a, int n, const double* b, double* x);                      /* Ax=b; 0 if singular */
typedef struct RFM_Stats { double mean, variance, stddev, min, max, median; } RFM_Stats;
RF_MATH_API int    rfm_stats(const double* v, int n, RFM_Stats* out);
#endif
