#ifndef RF_TEXT_H
#define RF_TEXT_H
#include "Common.h"
#ifdef RF_TEXT_BUILDING
 #define RF_TEXT_API RF_DLLEXPORT
#else
 #define RF_TEXT_API RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif
/* RF.Text.C - base64, hex, string helpers, UTF-8 utils (all returned strings: free with rf_free) */
RF_TEXT_API char*     rf_base64_encode(const void* data, size_t n);
RF_TEXT_API RF_Status rf_base64_decode(const char* s, void** out, size_t* n);
RF_TEXT_API char*     rf_hex_encode(const void* data, size_t n);
RF_TEXT_API RF_Status rf_hex_decode(const char* s, void** out, size_t* n);
RF_TEXT_API char*     rf_str_trim(const char* s);
RF_TEXT_API char*     rf_str_lower(const char* s);   /* ASCII */
RF_TEXT_API char*     rf_str_upper(const char* s);   /* ASCII */
RF_TEXT_API char*     rf_str_replace(const char* s, const char* from, const char* to);
RF_TEXT_API char*     rf_str_format(const char* fmt, ...);
RF_TEXT_API char**    rf_str_split(const char* s, char sep, size_t* count);
RF_TEXT_API void      rf_str_split_free(char** parts, size_t count);
RF_TEXT_API int       rf_str_starts_with(const char* s, const char* prefix);
RF_TEXT_API int       rf_str_ends_with(const char* s, const char* suffix);
RF_TEXT_API int       rf_utf8_valid(const char* s);
RF_TEXT_API size_t    rf_utf8_length(const char* s);  /* code points */

#ifdef __cplusplus
}
#endif
#endif
