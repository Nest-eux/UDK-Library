#ifndef RF_CRYPTO_H
#define RF_CRYPTO_H
#include "Common.h"
#ifdef RF_CRYPTO_BUILDING
 #define RF_CRYPTO_API RF_DLLEXPORT
#else
 #define RF_CRYPTO_API RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif
/* RF.Crypto.C - SHA-256, HMAC, PBKDF2, ChaCha20, secure random */
RF_CRYPTO_API void      rf_sha256(const void* data, size_t n, uint8_t out[32]);
RF_CRYPTO_API void      rf_hmac_sha256(const void* key, size_t klen, const void* data, size_t n, uint8_t out[32]);
RF_CRYPTO_API void      rf_pbkdf2_sha256(const void* pass, size_t plen, const void* salt, size_t slen, uint32_t iters, void* out, size_t outlen);
RF_CRYPTO_API void      rf_chacha20_xor(const uint8_t key[32], const uint8_t nonce[12], uint32_t counter, const void* in, void* out, size_t n);
RF_CRYPTO_API RF_Status rf_random_bytes(void* buf, size_t n);
RF_CRYPTO_API int       rf_const_time_eq(const void* a, const void* b, size_t n);

#ifdef __cplusplus
}
#endif
#endif
