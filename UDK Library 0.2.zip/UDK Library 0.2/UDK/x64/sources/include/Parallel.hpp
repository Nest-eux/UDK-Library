/* RF.Parallel.Cpp - thread pool (C++ implementation, flat C ABI so any language can call it) */
#ifndef RF_PARALLEL_HPP
#define RF_PARALLEL_HPP
#include "Common.h"
#ifdef RF_PARALLEL_BUILDING
 #define RF_PARALLEL_API extern "C" __declspec(dllexport)
#else
 #define RF_PARALLEL_API extern "C" __declspec(dllimport)
#endif

typedef void (*RFP_Task)(void* user);
typedef struct RFP_Pool RFP_Pool;

RF_PARALLEL_API RFP_Pool* rfp_pool_create(unsigned threads);   /* 0 = hardware concurrency */
RF_PARALLEL_API RF_Status rfp_pool_submit(RFP_Pool* p, RFP_Task fn, void* user);
RF_PARALLEL_API void      rfp_pool_wait(RFP_Pool* p);
RF_PARALLEL_API void      rfp_pool_destroy(RFP_Pool* p);
RF_PARALLEL_API RF_Status rfp_parallel_for(unsigned count, void (*body)(unsigned i, void* user), void* user);

namespace RF {
class ThreadPool {
    RFP_Pool* p_;
public:
    explicit ThreadPool(unsigned n = 0) : p_(rfp_pool_create(n)) {}
    ~ThreadPool() { rfp_pool_destroy(p_); }
    ThreadPool(const ThreadPool&) = delete; ThreadPool& operator=(const ThreadPool&) = delete;
    template <class F> void Submit(F f) {
        auto* h = new F(f);
        rfp_pool_submit(p_, [](void* u){ auto* g = static_cast<F*>(u); (*g)(); delete g; }, h);
    }
    void Wait() { rfp_pool_wait(p_); }
};
}
#endif
