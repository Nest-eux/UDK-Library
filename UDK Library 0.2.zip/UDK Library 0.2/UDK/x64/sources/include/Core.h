/* RF.Core.C - memory, strings/UTF, logging, hashing, module loader */
#ifndef RF_CORE_H
#define RF_CORE_H
#include "Common.h"
#ifdef RF_CORE_BUILDING
 #define RF_CORE_API RF_DLLEXPORT
#else
 #define RF_CORE_API RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif

RF_CORE_API const char* rf_version(void);

RF_CORE_API const char* rf_last_error(void);
RF_CORE_API void        rf_set_error(const char* fmt, ...);

RF_CORE_API void* rf_alloc(size_t n);          /* zeroed */
RF_CORE_API void* rf_realloc(void* p, size_t n);
RF_CORE_API void  rf_free(void* p);

RF_CORE_API RF_Status rf_utf8_to_utf16(const char* s, wchar_t** out);   /* free with rf_free */
RF_CORE_API RF_Status rf_utf16_to_utf8(const wchar_t* s, char** out);   /* free with rf_free */
RF_CORE_API char*     rf_strdup(const char* s);

typedef enum { RF_LOG_DEBUG, RF_LOG_INFO, RF_LOG_WARN, RF_LOG_ERROR } RF_LogLevel;
typedef void (*RF_LogCallback)(RF_LogLevel lvl, const char* msg, void* user);
RF_CORE_API void rf_log_set_callback(RF_LogCallback cb, void* user);
RF_CORE_API void rf_log(RF_LogLevel lvl, const char* fmt, ...);

RF_CORE_API uint32_t rf_crc32(const void* data, size_t n);
RF_CORE_API uint64_t rf_fnv1a64(const void* data, size_t n);

/* module loader: loads .dll / .rflib files that export RF_GetModuleInfo */
typedef struct RF_Module RF_Module;
RF_CORE_API RF_Status rf_module_load(const char* path_utf8, RF_Module** out);
RF_CORE_API RF_Status rf_module_info(RF_Module* m, RF_ModuleInfo* out);
RF_CORE_API void*     rf_module_symbol(RF_Module* m, const char* name);
RF_CORE_API void      rf_module_unload(RF_Module* m);

#ifdef __cplusplus
}
#endif
#endif
