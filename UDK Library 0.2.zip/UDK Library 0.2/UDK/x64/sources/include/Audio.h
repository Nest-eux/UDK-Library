#ifndef RF_AUDIO_H
#define RF_AUDIO_H
#include "Common.h"
#ifdef RF_AUDIO_BUILDING
 #define RF_AUDIO_API RF_DLLEXPORT
#else
 #define RF_AUDIO_API RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif
/* RF.Audio.C - WAV playback, beep, microphone recording to WAV */
RF_AUDIO_API RF_Status rf_audio_play_file(const char* wav_path, int async);
RF_AUDIO_API RF_Status rf_audio_play_mem(const void* wav, int async);   /* buffer must stay valid while async playback runs */
RF_AUDIO_API void      rf_audio_stop(void);
RF_AUDIO_API RF_Status rf_audio_beep(uint32_t freq_hz, uint32_t ms);
/* blocking record, 16-bit mono PCM; returns a full WAV file in memory (rf_free) */
RF_AUDIO_API RF_Status rf_audio_record_wav(uint32_t ms, uint32_t sample_rate, void** wav, size_t* size);

#ifdef __cplusplus
}
#endif
#endif
