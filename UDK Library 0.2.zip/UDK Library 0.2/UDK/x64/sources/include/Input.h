#ifndef RF_INPUT_H
#define RF_INPUT_H
#include "Common.h"
#ifdef RF_INPUT_BUILDING
 #define RF_INPUT_API RF_DLLEXPORT
#else
 #define RF_INPUT_API RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif
/* RF.Input.C - keyboard/mouse synthesis, global hotkeys, screen capture */
RF_INPUT_API RF_Status rf_input_key(uint16_t vk, int down);
RF_INPUT_API RF_Status rf_input_key_press(uint16_t vk);                    /* down + up */
RF_INPUT_API RF_Status rf_input_type_text(const char* utf8);               /* Unicode typing */
RF_INPUT_API RF_Status rf_input_mouse_move(int x, int y);                  /* absolute screen coords */
RF_INPUT_API RF_Status rf_input_mouse_click(int button, int double_click); /* 0=left 1=right 2=middle */
RF_INPUT_API RF_Status rf_input_mouse_wheel(int delta);
RF_INPUT_API RF_Status rf_cursor_pos(int* x, int* y);
RF_INPUT_API int       rf_key_is_down(uint16_t vk);
/* modifiers: 1=Alt 2=Ctrl 4=Shift 8=Win */
typedef void (*RF_HotkeyCb)(int id, void* user);
RF_INPUT_API RF_Status rf_hotkey_register(int id, uint32_t modifiers, uint32_t vk, RF_HotkeyCb cb, void* user);
RF_INPUT_API void      rf_hotkey_unregister(int id);
RF_INPUT_API RF_Status rf_screen_size(int* w, int* h);
/* full 24-bit BMP file in memory; w=h=0 captures the whole primary screen. Free with rf_free */
RF_INPUT_API RF_Status rf_screen_capture_bmp(int x, int y, int w, int h, void** bmp, size_t* size);

#ifdef __cplusplus
}
#endif
#endif
