#ifndef RF_PACKAGE_H
#define RF_PACKAGE_H
#include "Common.h"
#ifdef RF_PACKAGE_BUILDING
 #define RF_PACKAGE_API RF_DLLEXPORT
#else
 #define RF_PACKAGE_API RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif
/* RF.Package.C - the .udklib container: manifest + compressed, CRC-checked entries */
/* File layout (little endian):
   [32B header: "UDKL", u32 version, u32 entry_count, u32 manifest_size, u64 index_offset, u32 reserved, u32 header_crc32]
   [manifest: "key=value\n" lines][entry blobs][index: per entry u16 name_len, name, u32 flags(bit0=compressed),
   u64 offset, u64 stored_size, u64 orig_size, u32 crc32(orig)]  */
typedef struct RF_Pack RF_Pack;
RF_PACKAGE_API RF_Pack*   rf_pack_new(void);
RF_PACKAGE_API void       rf_pack_free(RF_Pack* p);
RF_PACKAGE_API RF_Status  rf_pack_set_meta(RF_Pack* p, const char* key, const char* value);
RF_PACKAGE_API const char* rf_pack_meta(const RF_Pack* p, const char* key);  /* NULL if absent */
RF_PACKAGE_API RF_Status  rf_pack_add(RF_Pack* p, const char* name, const void* data, size_t size, int compress);
RF_PACKAGE_API RF_Status  rf_pack_add_file(RF_Pack* p, const char* name, const char* path, int compress);
RF_PACKAGE_API size_t     rf_pack_count(const RF_Pack* p);
RF_PACKAGE_API const char* rf_pack_name(const RF_Pack* p, size_t i);
RF_PACKAGE_API uint64_t   rf_pack_size(const RF_Pack* p, size_t i);          /* original size */
RF_PACKAGE_API RF_Status  rf_pack_extract(const RF_Pack* p, const char* name, void** data, size_t* size); /* CRC verified; rf_free */
RF_PACKAGE_API RF_Status  rf_pack_save_mem(const RF_Pack* p, void** out, size_t* size);
RF_PACKAGE_API RF_Status  rf_pack_save_file(const RF_Pack* p, const char* path);
RF_PACKAGE_API RF_Status  rf_pack_open_mem(const void* data, size_t size, RF_Pack** out);
RF_PACKAGE_API RF_Status  rf_pack_open_file(const char* path, RF_Pack** out);

#ifdef __cplusplus
}
#endif
#endif
