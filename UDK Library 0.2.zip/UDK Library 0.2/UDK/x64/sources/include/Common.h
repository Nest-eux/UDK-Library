/* RF UDK - Replication Framework :: shared definitions */
#ifndef RF_COMMON_H
#define RF_COMMON_H
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#if defined(_WIN32)
 #define RF_DLLEXPORT __declspec(dllexport)
 #define RF_DLLIMPORT __declspec(dllimport)
#else
 #define RF_DLLEXPORT __attribute__((visibility("default")))
 #define RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif

#define RF_UDK_VERSION_MAJOR 0
#define RF_UDK_VERSION_MINOR 1
#define RF_UDK_VERSION_PATCH 0

typedef enum RF_Status {
    RF_OK = 0, RF_ERR_GENERIC = -1, RF_ERR_ARG = -2, RF_ERR_NOMEM = -3,
    RF_ERR_IO = -4, RF_ERR_NOTFOUND = -5, RF_ERR_WINAPI = -6, RF_ERR_UNSUPPORTED = -7
} RF_Status;

/* Every RF library (.dll / .rflib) exports RF_GetModuleInfo */
typedef struct RF_ModuleInfo {
    char     name[64];      /* e.g. "RF.Core.C" */
    char     language[8];   /* "C", "CPP", "CS", "FS" */
    uint32_t major, minor, patch;
} RF_ModuleInfo;

typedef int (*RF_GetModuleInfoFn)(RF_ModuleInfo* out);

/* Put once in every library: RF_DEFINE_MODULE(RF_X_API, "RF.X.C", "C") */
#define RF_DEFINE_MODULE(api, nm, lang) \
    api int RF_GetModuleInfo(RF_ModuleInfo* o) { \
        if (!o) return RF_ERR_ARG; memset(o, 0, sizeof *o); \
        strncpy(o->name, nm, sizeof o->name - 1); strncpy(o->language, lang, sizeof o->language - 1); \
        o->major = RF_UDK_VERSION_MAJOR; o->minor = RF_UDK_VERSION_MINOR; o->patch = RF_UDK_VERSION_PATCH; \
        return RF_OK; }

#ifdef __cplusplus
}
#endif
#endif
