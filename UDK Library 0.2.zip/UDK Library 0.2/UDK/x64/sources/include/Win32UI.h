#ifndef RF_WIN32UI_H
#define RF_WIN32UI_H
#include "Common.h"
#ifdef RF_WIN32UI_BUILDING
 #define RF_WIN32UI_API RF_DLLEXPORT
#else
 #define RF_WIN32UI_API RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif
/* RF.Win32UI.C - native Win32 windows and controls without any framework */
typedef struct RF_Window RF_Window;
/* code: 0 = clicked/changed, 1 = window closing (control_id = 0) */
typedef void (*RF_UIEvent)(int control_id, int code, void* user);
RF_WIN32UI_API RF_Window* rf_ui_window_create(const char* title, int w, int h, RF_UIEvent cb, void* user);
RF_WIN32UI_API RF_Status  rf_ui_add_button(RF_Window* w, int id, const char* text, int x, int y, int cw, int ch);
RF_WIN32UI_API RF_Status  rf_ui_add_label(RF_Window* w, int id, const char* text, int x, int y, int cw, int ch);
RF_WIN32UI_API RF_Status  rf_ui_add_edit(RF_Window* w, int id, const char* text, int x, int y, int cw, int ch, int multiline);
RF_WIN32UI_API RF_Status  rf_ui_add_checkbox(RF_Window* w, int id, const char* text, int x, int y, int cw, int ch);
RF_WIN32UI_API RF_Status  rf_ui_add_listbox(RF_Window* w, int id, int x, int y, int cw, int ch);
RF_WIN32UI_API RF_Status  rf_ui_add_progress(RF_Window* w, int id, int x, int y, int cw, int ch);
RF_WIN32UI_API RF_Status  rf_ui_set_text(RF_Window* w, int id, const char* text);
RF_WIN32UI_API char*      rf_ui_get_text(RF_Window* w, int id);                 /* rf_free */
RF_WIN32UI_API int        rf_ui_get_checked(RF_Window* w, int id);
RF_WIN32UI_API RF_Status  rf_ui_listbox_add(RF_Window* w, int id, const char* text);
RF_WIN32UI_API RF_Status  rf_ui_progress_set(RF_Window* w, int id, int percent);
RF_WIN32UI_API void       rf_ui_show(RF_Window* w);
RF_WIN32UI_API int        rf_ui_run(void);                                      /* message loop until quit */
RF_WIN32UI_API void       rf_ui_quit(void);
RF_WIN32UI_API void       rf_ui_window_close(RF_Window* w);
RF_WIN32UI_API int        rf_ui_message_box(const char* title, const char* text, uint32_t flags); /* MB_* flags */
/* filter: "Text files|*.txt|All files|*.*" */
RF_WIN32UI_API RF_Status  rf_ui_open_file_dialog(const char* filter, char** out);
RF_WIN32UI_API RF_Status  rf_ui_save_file_dialog(const char* filter, char** out);

#ifdef __cplusplus
}
#endif
#endif
