#ifndef RF_THREADING_H
#define RF_THREADING_H
#include "Common.h"
#ifdef RF_THREADING_BUILDING
 #define RF_THREADING_API RF_DLLEXPORT
#else
 #define RF_THREADING_API RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif
/* RF.Threading.C - threads, mutex, events, semaphores, timers, high-resolution clock */
typedef struct RF_Thread RF_Thread; typedef struct RF_Mutex RF_Mutex; typedef struct RF_Event RF_Event;
typedef struct RF_Sem RF_Sem; typedef struct RF_Timer RF_Timer;
typedef void (*RF_ThreadFn)(void* arg);
RF_THREADING_API RF_Thread* rf_thread_start(RF_ThreadFn fn, void* arg);
RF_THREADING_API void       rf_thread_join(RF_Thread* t);           /* waits and frees */
RF_THREADING_API uint32_t   rf_thread_current_id(void);
RF_THREADING_API RF_Mutex*  rf_mutex_new(void);
RF_THREADING_API void       rf_mutex_lock(RF_Mutex* m);
RF_THREADING_API int        rf_mutex_try_lock(RF_Mutex* m);
RF_THREADING_API void       rf_mutex_unlock(RF_Mutex* m);
RF_THREADING_API void       rf_mutex_free(RF_Mutex* m);
RF_THREADING_API RF_Event*  rf_event_new(int manual_reset, int initial);
RF_THREADING_API void       rf_event_set(RF_Event* e);
RF_THREADING_API void       rf_event_reset(RF_Event* e);
RF_THREADING_API int        rf_event_wait(RF_Event* e, uint32_t timeout_ms);  /* 1 = signaled, 0 = timeout; 0xFFFFFFFF = infinite */
RF_THREADING_API void       rf_event_free(RF_Event* e);
RF_THREADING_API RF_Sem*    rf_sem_new(int initial, int max);
RF_THREADING_API int        rf_sem_acquire(RF_Sem* s, uint32_t timeout_ms);
RF_THREADING_API void       rf_sem_release(RF_Sem* s);
RF_THREADING_API void       rf_sem_free(RF_Sem* s);
RF_THREADING_API RF_Timer*  rf_timer_start(uint32_t interval_ms, int repeat, RF_ThreadFn cb, void* arg);
RF_THREADING_API void       rf_timer_stop(RF_Timer* t);              /* waits for running callback, frees */
RF_THREADING_API void       rf_sleep_ms(uint32_t ms);
RF_THREADING_API uint64_t   rf_ticks_ms(void);
RF_THREADING_API double     rf_clock_seconds(void);                  /* high-resolution monotonic */

#ifdef __cplusplus
}
#endif
#endif
