#ifndef RF_IMAGE_HPP
#define RF_IMAGE_HPP
#include "Common.h"
#ifdef RF_IMAGE_BUILDING
 #define RF_IMAGE_API extern "C" RF_DLLEXPORT
#else
 #define RF_IMAGE_API extern "C" RF_DLLIMPORT
#endif
/* RF.Image.Cpp - RGBA images: BMP load/save, resize, crop, flip, grayscale */
typedef struct RFI_Image RFI_Image;
RF_IMAGE_API RFI_Image* rfi_create(int w, int h);                       /* transparent black */
RF_IMAGE_API void       rfi_free(RFI_Image* img);
RF_IMAGE_API int        rfi_width(const RFI_Image* img);
RF_IMAGE_API int        rfi_height(const RFI_Image* img);
RF_IMAGE_API uint8_t*   rfi_pixels(RFI_Image* img);                     /* RGBA, row-major top-down, w*h*4 bytes */
RF_IMAGE_API RFI_Image* rfi_load_bmp_mem(const void* data, size_t size); /* 24/32-bit uncompressed */
RF_IMAGE_API RF_Status  rfi_save_bmp_mem(const RFI_Image* img, void** out, size_t* size); /* rfi_free_buffer */
RF_IMAGE_API void       rfi_free_buffer(void* p);
RF_IMAGE_API RFI_Image* rfi_resize(const RFI_Image* img, int nw, int nh);   /* bilinear, new image */
RF_IMAGE_API RFI_Image* rfi_crop(const RFI_Image* img, int x, int y, int w, int h);
RF_IMAGE_API void       rfi_grayscale(RFI_Image* img);
RF_IMAGE_API void       rfi_flip(RFI_Image* img, int vertical);
#endif
