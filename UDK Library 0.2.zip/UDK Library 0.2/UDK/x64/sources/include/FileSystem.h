#ifndef RF_FILESYSTEM_H
#define RF_FILESYSTEM_H
#include "Common.h"
#ifdef RF_FILESYSTEM_BUILDING
 #define RF_FILESYSTEM_API RF_DLLEXPORT
#else
 #define RF_FILESYSTEM_API RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif
/* RF.FileSystem.C - directories, copy/move/delete, paths, known folders, change watcher (UTF-8 paths) */
typedef int (*RF_DirCb)(const char* name, int is_dir, uint64_t size, void* user); /* return 0 to stop */
RF_FILESYSTEM_API RF_Status rf_fs_list(const char* dir, RF_DirCb cb, void* user);
RF_FILESYSTEM_API RF_Status rf_fs_mkdir(const char* path);                         /* recursive */
RF_FILESYSTEM_API RF_Status rf_fs_copy(const char* src, const char* dst, int overwrite);
RF_FILESYSTEM_API RF_Status rf_fs_move(const char* src, const char* dst);
RF_FILESYSTEM_API RF_Status rf_fs_delete(const char* path);                        /* file or empty dir */
RF_FILESYSTEM_API RF_Status rf_fs_delete_tree(const char* path);
RF_FILESYSTEM_API int       rf_fs_is_dir(const char* path);
RF_FILESYSTEM_API int64_t   rf_fs_file_size(const char* path);                     /* -1 on error */
RF_FILESYSTEM_API char*     rf_path_join(const char* a, const char* b);            /* free with rf_free */
RF_FILESYSTEM_API char*     rf_path_filename(const char* p);
RF_FILESYSTEM_API char*     rf_path_dir(const char* p);
RF_FILESYSTEM_API char*     rf_path_ext(const char* p);                            /* ".txt" or "" */
/* which: "temp" "appdata" "localappdata" "documents" "desktop" "home" "exe" "cwd" */
RF_FILESYSTEM_API RF_Status rf_fs_known_folder(const char* which, char** out);

enum { RF_WATCH_ADDED = 1, RF_WATCH_REMOVED = 2, RF_WATCH_MODIFIED = 3, RF_WATCH_RENAMED_OLD = 4, RF_WATCH_RENAMED_NEW = 5 };
typedef void (*RF_WatchCb)(int action, const char* rel_path, void* user);
typedef struct RF_Watch RF_Watch;
RF_FILESYSTEM_API RF_Watch* rf_fs_watch_start(const char* dir, int recursive, RF_WatchCb cb, void* user);
RF_FILESYSTEM_API void      rf_fs_watch_stop(RF_Watch* w);

#ifdef __cplusplus
}
#endif
#endif
