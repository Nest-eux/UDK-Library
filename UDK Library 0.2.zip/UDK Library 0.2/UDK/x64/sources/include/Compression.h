#ifndef RF_COMPRESSION_H
#define RF_COMPRESSION_H
#include "Common.h"
#ifdef RF_COMPRESSION_BUILDING
 #define RF_COMPRESSION_API RF_DLLEXPORT
#else
 #define RF_COMPRESSION_API RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif
/* RF.Compression.C - fast LZ77 block compressor (RFZ1 format) */
RF_COMPRESSION_API size_t    rf_lz_bound(size_t n);
RF_COMPRESSION_API RF_Status rf_lz_compress(const void* in, size_t n, void** out, size_t* out_n);   /* free with rf_free */
RF_COMPRESSION_API RF_Status rf_lz_decompress(const void* in, size_t n, void** out, size_t* out_n); /* free with rf_free */

#ifdef __cplusplus
}
#endif
#endif
