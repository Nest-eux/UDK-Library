#ifndef RF_COLLECTIONS_H
#define RF_COLLECTIONS_H
#include "Common.h"
#ifdef RF_COLLECTIONS_BUILDING
 #define RF_COLLECTIONS_API RF_DLLEXPORT
#else
 #define RF_COLLECTIONS_API RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif
/* RF.Collections.C - dynamic array, string hash map, string builder */
typedef struct RF_Vec RF_Vec;
RF_COLLECTIONS_API RF_Vec*   rf_vec_new(size_t elem_size);
RF_COLLECTIONS_API void      rf_vec_free(RF_Vec* v);
RF_COLLECTIONS_API size_t    rf_vec_len(const RF_Vec* v);
RF_COLLECTIONS_API RF_Status rf_vec_push(RF_Vec* v, const void* elem);
RF_COLLECTIONS_API void*     rf_vec_at(RF_Vec* v, size_t i);          /* NULL if out of range */
RF_COLLECTIONS_API RF_Status rf_vec_pop(RF_Vec* v, void* out);
RF_COLLECTIONS_API RF_Status rf_vec_remove(RF_Vec* v, size_t i);
RF_COLLECTIONS_API void      rf_vec_clear(RF_Vec* v);

typedef struct RF_Map RF_Map;   /* string -> void* */
typedef int (*RF_MapIter)(const char* key, void* value, void* user); /* return 0 to stop */
RF_COLLECTIONS_API RF_Map*   rf_map_new(void);
RF_COLLECTIONS_API void      rf_map_free(RF_Map* m);
RF_COLLECTIONS_API RF_Status rf_map_set(RF_Map* m, const char* key, void* value);
RF_COLLECTIONS_API void*     rf_map_get(const RF_Map* m, const char* key);
RF_COLLECTIONS_API int       rf_map_has(const RF_Map* m, const char* key);
RF_COLLECTIONS_API RF_Status rf_map_remove(RF_Map* m, const char* key);
RF_COLLECTIONS_API size_t    rf_map_count(const RF_Map* m);
RF_COLLECTIONS_API void      rf_map_foreach(const RF_Map* m, RF_MapIter cb, void* user);

typedef struct RF_StrBuf RF_StrBuf;
RF_COLLECTIONS_API RF_StrBuf* rf_sb_new(void);
RF_COLLECTIONS_API void       rf_sb_free(RF_StrBuf* sb);
RF_COLLECTIONS_API RF_Status  rf_sb_append(RF_StrBuf* sb, const char* s);
RF_COLLECTIONS_API RF_Status  rf_sb_appendf(RF_StrBuf* sb, const char* fmt, ...);
RF_COLLECTIONS_API const char* rf_sb_cstr(const RF_StrBuf* sb);
RF_COLLECTIONS_API size_t     rf_sb_len(const RF_StrBuf* sb);
RF_COLLECTIONS_API char*      rf_sb_detach(RF_StrBuf* sb);  /* caller frees with rf_free; sb is freed */

#ifdef __cplusplus
}
#endif
#endif
