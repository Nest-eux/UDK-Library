#ifndef RF_JSON_H
#define RF_JSON_H
#include "Common.h"
#ifdef RF_JSON_BUILDING
 #define RF_JSON_API RF_DLLEXPORT
#else
 #define RF_JSON_API RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif
/* RF.Json.C - JSON parser / builder / serializer */
typedef enum { RF_JSON_NULL, RF_JSON_BOOL, RF_JSON_NUMBER, RF_JSON_STRING, RF_JSON_ARRAY, RF_JSON_OBJECT } RF_JsonType;
typedef struct RF_Json RF_Json;

RF_JSON_API RF_Json*     rf_json_parse(const char* text);       /* NULL on error, see rf_last_error() */
RF_JSON_API void         rf_json_free(RF_Json* j);
RF_JSON_API RF_JsonType  rf_json_type(const RF_Json* j);
RF_JSON_API double       rf_json_number(const RF_Json* j);
RF_JSON_API int          rf_json_bool(const RF_Json* j);
RF_JSON_API const char*  rf_json_string(const RF_Json* j);
RF_JSON_API size_t       rf_json_count(const RF_Json* j);        /* array / object length */
RF_JSON_API RF_Json*     rf_json_at(const RF_Json* j, size_t i);
RF_JSON_API RF_Json*     rf_json_get(const RF_Json* j, const char* key);
RF_JSON_API const char*  rf_json_key_at(const RF_Json* j, size_t i);

RF_JSON_API RF_Json*     rf_json_new_null(void);
RF_JSON_API RF_Json*     rf_json_new_bool(int b);
RF_JSON_API RF_Json*     rf_json_new_number(double d);
RF_JSON_API RF_Json*     rf_json_new_string(const char* s);
RF_JSON_API RF_Json*     rf_json_new_array(void);
RF_JSON_API RF_Json*     rf_json_new_object(void);
RF_JSON_API RF_Status    rf_json_array_push(RF_Json* arr, RF_Json* item);                  /* takes ownership */
RF_JSON_API RF_Status    rf_json_object_set(RF_Json* obj, const char* key, RF_Json* item); /* takes ownership */
RF_JSON_API char*        rf_json_stringify(const RF_Json* j, int pretty);                   /* free with rf_free */

#ifdef __cplusplus
}
#endif
#endif
