/* RF.System.C - WinAPI wrappers: files, processes, registry, windows, clipboard, sysinfo */
#ifndef RF_SYSTEM_H
#define RF_SYSTEM_H
#include "Common.h"
#ifdef RF_SYSTEM_BUILDING
 #define RF_SYSTEM_API RF_DLLEXPORT
#else
 #define RF_SYSTEM_API RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif


RF_SYSTEM_API int       rf_file_exists(const char* path);
RF_SYSTEM_API RF_Status rf_file_read_all(const char* path, void** data, size_t* size); /* free with rf_free */
RF_SYSTEM_API RF_Status rf_file_write_all(const char* path, const void* data, size_t size);

RF_SYSTEM_API RF_Status rf_process_run(const char* cmdline, int wait, uint32_t* exit_code);
typedef int (*RF_ProcessCb)(uint32_t pid, const char* exe_name, void* user); /* return 0 to stop */
RF_SYSTEM_API RF_Status rf_process_enum(RF_ProcessCb cb, void* user);
RF_SYSTEM_API RF_Status rf_process_kill(uint32_t pid);

/* registry: root = "HKCU" | "HKLM" */
RF_SYSTEM_API RF_Status rf_reg_read_string(const char* root, const char* key, const char* name, char* buf, size_t buf_size);
RF_SYSTEM_API RF_Status rf_reg_write_string(const char* root, const char* key, const char* name, const char* value);
RF_SYSTEM_API RF_Status rf_reg_delete_value(const char* root, const char* key, const char* name);

typedef int (*RF_WindowCb)(uintptr_t hwnd, const char* title, void* user); /* return 0 to stop */
RF_SYSTEM_API RF_Status rf_window_enum(RF_WindowCb cb, void* user);
RF_SYSTEM_API RF_Status rf_clipboard_get_text(char** out);   /* free with rf_free */
RF_SYSTEM_API RF_Status rf_clipboard_set_text(const char* text);

typedef struct RF_SysInfo {
    uint32_t cpu_count; uint64_t ram_total, ram_free; uint32_t os_major, os_minor, os_build;
    char computer_name[64];
} RF_SysInfo;
RF_SYSTEM_API RF_Status rf_sysinfo(RF_SysInfo* out);

#ifdef __cplusplus
}
#endif
#endif
