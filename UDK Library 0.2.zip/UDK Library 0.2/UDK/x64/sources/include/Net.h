#ifndef RF_NET_H
#define RF_NET_H
#include "Common.h"
#ifdef RF_NET_BUILDING
 #define RF_NET_API RF_DLLEXPORT
#else
 #define RF_NET_API RF_DLLIMPORT
#endif
#ifdef __cplusplus
extern "C" {
#endif
/* RF.Net.C - TCP / UDP sockets and HTTP(S) client (WinHTTP) */
typedef struct RF_Socket RF_Socket;
RF_NET_API RF_Status rf_tcp_connect(const char* host, uint16_t port, RF_Socket** out);
RF_NET_API RF_Status rf_tcp_listen(uint16_t port, int backlog, RF_Socket** out);
RF_NET_API RF_Status rf_tcp_accept(RF_Socket* listener, RF_Socket** client);
RF_NET_API int       rf_sock_send(RF_Socket* s, const void* data, size_t n);   /* bytes sent or -1 */
RF_NET_API int       rf_sock_recv(RF_Socket* s, void* buf, size_t n);          /* bytes, 0 = closed, -1 = error */
RF_NET_API RF_Status rf_sock_set_timeout(RF_Socket* s, uint32_t ms);
RF_NET_API void      rf_sock_close(RF_Socket* s);
RF_NET_API RF_Status rf_udp_open(uint16_t bind_port, RF_Socket** out);          /* 0 = ephemeral */
RF_NET_API int       rf_udp_sendto(RF_Socket* s, const char* host, uint16_t port, const void* data, size_t n);
RF_NET_API int       rf_udp_recvfrom(RF_Socket* s, void* buf, size_t n, char* from_host, size_t host_size, uint16_t* from_port);
/* headers: "Name: value\r\nName2: value2" or NULL. *resp freed with rf_free (NUL-terminated for convenience) */
RF_NET_API RF_Status rf_http_request(const char* method, const char* url, const char* headers,
                                     const void* body, size_t body_len, int* status, void** resp, size_t* resp_len);

#ifdef __cplusplus
}
#endif
#endif
