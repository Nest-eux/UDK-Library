#ifndef RF_REGEX_HPP
#define RF_REGEX_HPP
#include "Common.h"
#ifdef RF_REGEX_BUILDING
 #define RF_REGEX_API extern "C" RF_DLLEXPORT
#else
 #define RF_REGEX_API extern "C" RF_DLLIMPORT
#endif
/* RF.Regex.Cpp - std::regex (ECMAScript) behind a flat C ABI */
typedef struct RFX_Regex RFX_Regex;
typedef struct RFX_Match { int count; int pos[10]; int len[10]; } RFX_Match;  /* group 0 = whole match; -1 pos = unmatched */
RF_REGEX_API RFX_Regex* rfx_compile(const char* pattern, int ignore_case);   /* NULL on bad pattern */
RF_REGEX_API void       rfx_free(RFX_Regex* re);
RF_REGEX_API int        rfx_match_full(const RFX_Regex* re, const char* text);
RF_REGEX_API int        rfx_find(const RFX_Regex* re, const char* text, size_t start, RFX_Match* m);  /* 1 = found */
RF_REGEX_API char*      rfx_replace(const RFX_Regex* re, const char* text, const char* repl);          /* $1 style; rfx_free_string */
RF_REGEX_API void       rfx_free_string(char* s);
#endif
