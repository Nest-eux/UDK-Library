/* udkpack - create / inspect / extract .udklib packages
   udkpack create out.udklib [-m key=value]... [--store] [alias=]file...
   udkpack list <pkg> | info <pkg> | extract <pkg> <outdir> */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <shellapi.h>
#include "RF/Core.h"
#include "RF/Package.h"
#include "RF/FileSystem.h"

static char* to8(const wchar_t* w) { char* c = NULL; rf_utf16_to_utf8(w, &c); return c; }
static int usage(void) { puts("udkpack create <out.udklib> [-m key=value]... [--store] [alias=]file...\nudkpack list|info <pkg>\nudkpack extract <pkg> <outdir>"); return 2; }

int main(void) {
    int argc; wchar_t** wv = CommandLineToArgvW(GetCommandLineW(), &argc); char** v = rf_alloc(sizeof(char*) * (size_t)(argc + 1));
    for (int i = 0; i < argc; i++) v[i] = to8(wv[i]);
    if (argc < 3) return usage();
    if (!strcmp(v[1], "create")) {
        RF_Pack* p = rf_pack_new(); int compress = 1, added = 0;
        for (int i = 3; i < argc; i++) {
            if (!strcmp(v[i], "-m") && i + 1 < argc) { char* eq = strchr(v[++i], '='); if (!eq) return usage(); *eq = 0; rf_pack_set_meta(p, v[i], eq + 1); continue; }
            if (!strcmp(v[i], "--store")) { compress = 0; continue; }
            char* eq = strchr(v[i], '='); const char* path = eq ? eq + 1 : v[i]; char* name = eq ? (*eq = 0, v[i]) : rf_path_filename(v[i]);
            if (rf_pack_add_file(p, name, path, compress)) { fprintf(stderr, "error adding %s: %s\n", path, rf_last_error()); return 1; } added++;
        }
        if (rf_pack_save_file(p, v[2])) { fprintf(stderr, "cannot write %s\n", v[2]); return 1; }
        printf("%s: %d file(s)\n", v[2], added); return 0;
    }
    RF_Pack* p; if (rf_pack_open_file(v[2], &p)) { fprintf(stderr, "%s\n", rf_last_error()); return 1; }
    if (!strcmp(v[1], "list") || !strcmp(v[1], "info")) {
        if (!strcmp(v[1], "info")) { const char* k[] = { "name", "version", "author", "description", "entry" }; for (int i = 0; i < 5; i++) if (rf_pack_meta(p, k[i])) printf("%s: %s\n", k[i], rf_pack_meta(p, k[i])); }
        for (size_t i = 0; i < rf_pack_count(p); i++) printf("%10llu  %s\n", (unsigned long long)rf_pack_size(p, i), rf_pack_name(p, i)); return 0;
    }
    if (!strcmp(v[1], "extract") && argc >= 4) {
        for (size_t i = 0; i < rf_pack_count(p); i++) {
            const char* n = rf_pack_name(p, i); void* d; size_t sz; if (rf_pack_extract(p, n, &d, &sz)) { fprintf(stderr, "%s: %s\n", n, rf_last_error()); return 1; }
            char* full = rf_path_join(v[3], n); char* dir = rf_path_dir(full); if (*dir) rf_fs_mkdir(dir);
            if (rf_fs_mkdir(v[3])) {} FILE* f = NULL; wchar_t* w; if (!rf_utf8_to_utf16(full, &w)) { f = _wfopen(w, L"wb"); rf_free(w); }
            if (!f || fwrite(d, 1, sz, f) != sz) { fprintf(stderr, "cannot write %s\n", full); return 1; } fclose(f); printf("extracted %s\n", full);
        }
        return 0;
    }
    return usage();
}
