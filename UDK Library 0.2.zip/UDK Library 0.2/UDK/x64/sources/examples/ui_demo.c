/* Pure-C native window demo: hash text with RF.Crypto, show it with RF.Text */
#include <stdio.h>
#include <windows.h>
#include "RF/Core.h"
#include "RF/Win32UI.h"
#include "RF/Crypto.h"
#include "RF/Text.h"
enum { ID_IN = 1, ID_BTN, ID_OUT, ID_LIST };
static RF_Window* win;
static void on_event(int id, int code, void* user) {
    (void)user;
    if (code == 1) { rf_ui_quit(); return; }
    if (id == ID_BTN) {
        char* t = rf_ui_get_text(win, ID_IN); uint8_t h[32]; rf_sha256(t, strlen(t), h);
        char* hx = rf_hex_encode(h, 32); rf_ui_set_text(win, ID_OUT, hx); rf_ui_listbox_add(win, ID_LIST, hx); rf_free(hx); rf_free(t);
    }
}
int WINAPI WinMain(HINSTANCE a, HINSTANCE b, LPSTR c, int d) {
    (void)a; (void)b; (void)c; (void)d;
    win = rf_ui_window_create("RF UDK demo", 560, 300, on_event, NULL);
    rf_ui_add_label(win, 0, "Text:", 10, 12, 50, 20); rf_ui_add_edit(win, ID_IN, "hello", 60, 10, 380, 24, 0);
    rf_ui_add_button(win, ID_BTN, "SHA-256", 450, 10, 90, 26); rf_ui_add_edit(win, ID_OUT, "", 10, 44, 530, 24, 0);
    rf_ui_add_listbox(win, ID_LIST, 10, 78, 530, 170); rf_ui_show(win); return rf_ui_run();
}
