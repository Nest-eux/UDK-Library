#include <stdio.h>
#include "RF/Core.h"
#include "RF/System.h"
int main(void) {
    printf("%s\n", rf_version());
    RF_SysInfo s; rf_sysinfo(&s);
    printf("PC=%s CPU=%u RAM=%llu MB Win %u.%u.%u\n", s.computer_name, s.cpu_count,
           (unsigned long long)(s.ram_total >> 20), s.os_major, s.os_minor, s.os_build);
    printf("crc32(\"RF\")=%08x\n", rf_crc32("RF", 2));
    return 0;
}
