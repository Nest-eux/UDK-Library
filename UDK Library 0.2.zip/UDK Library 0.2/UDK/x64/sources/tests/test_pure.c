#include <stdio.h>
#include <stdlib.h>
#include "RF/Core.h"
#include "RF/Collections.h"
#include "RF/Text.h"
#include "RF/Json.h"
#include "RF/Crypto.h"
#include "RF/Compression.h"
#include "RF/Package.h"
static int fails;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main(void) {
    /* collections */
    RF_Vec* v = rf_vec_new(sizeof(int)); for (int i = 0; i < 1000; i++) rf_vec_push(v, &i);
    CHECK(rf_vec_len(v) == 1000 && *(int*)rf_vec_at(v, 777) == 777); rf_vec_remove(v, 0); CHECK(*(int*)rf_vec_at(v, 0) == 1); rf_vec_free(v);
    RF_Map* m = rf_map_new(); char k[16]; for (int i = 0; i < 500; i++) { snprintf(k, 16, "k%d", i); rf_map_set(m, k, (void*)(intptr_t)(i + 1)); }
    CHECK(rf_map_count(m) == 500 && rf_map_get(m, "k123") == (void*)(intptr_t)124); rf_map_remove(m, "k123"); CHECK(!rf_map_has(m, "k123")); rf_map_free(m);
    RF_StrBuf* sb = rf_sb_new(); rf_sb_append(sb, "a"); rf_sb_appendf(sb, "%d-%s", 42, "z"); CHECK(!strcmp(rf_sb_cstr(sb), "a42-z")); rf_sb_free(sb);
    /* text */
    char* b = rf_base64_encode("Man", 3); CHECK(!strcmp(b, "TWFu")); rf_free(b);
    b = rf_base64_encode("Ma", 2); CHECK(!strcmp(b, "TWE=")); rf_free(b);
    void* d; size_t n; CHECK(rf_base64_decode("TWFuTWE=", &d, &n) == RF_OK && n == 5 && !memcmp(d, "ManMa", 5)); rf_free(d);
    b = rf_str_replace("a-b-c", "-", "+++"); CHECK(!strcmp(b, "a+++b+++c")); rf_free(b);
    size_t cnt; char** parts = rf_str_split("x,,y", ',', &cnt); CHECK(cnt == 3 && !strcmp(parts[2], "y")); rf_str_split_free(parts, cnt);
    CHECK(rf_utf8_valid("п\xD1\x80ивет") && !rf_utf8_valid("\xC0\x80") && rf_utf8_length("привет") == 6);
    /* json */
    RF_Json* j = rf_json_parse("{\"a\":[1,2.5,true,null],\"s\":\"h\\u00e9\\n\",\"o\":{\"x\":-3e2}}");
    CHECK(j && rf_json_count(rf_json_get(j, "a")) == 4 && rf_json_number(rf_json_get(rf_json_get(j, "o"), "x")) == -300);
    char* t = rf_json_stringify(j, 0); RF_Json* j2 = rf_json_parse(t); char* t2 = rf_json_stringify(j2, 1); CHECK(j2 && strstr(t2, "\"x\": -300")); rf_free(t); rf_free(t2); rf_json_free(j); rf_json_free(j2);
    CHECK(!rf_json_parse("{\"a\":}") && !rf_json_parse("[1,2"));
    /* crypto */
    uint8_t h[32]; rf_sha256("abc", 3, h); char* hx = rf_hex_encode(h, 32); CHECK(!strcmp(hx, "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")); rf_free(hx);
    rf_hmac_sha256("Jefe", 4, "what do ya want for nothing?", 28, h); hx = rf_hex_encode(h, 32); CHECK(!strcmp(hx, "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843")); rf_free(hx);
    uint8_t dk[32]; rf_pbkdf2_sha256("password", 8, "salt", 4, 1, dk, 32); hx = rf_hex_encode(dk, 32); CHECK(!strcmp(hx, "120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b")); rf_free(hx);
    uint8_t key[32], nonce[12] = {0,0,0,0,0,0,0,0x4a,0,0,0,0}; for (int i = 0; i < 32; i++) key[i] = (uint8_t)i;
    const char* pt = "Ladies and Gentlemen of the class of '99: If I could offer you only one tip for the future, sunscreen would be it."; uint8_t ct[200];
    rf_chacha20_xor(key, nonce, 1, pt, ct, strlen(pt)); hx = rf_hex_encode(ct, 16); CHECK(!strcmp(hx, "6e2e359a2568f98041ba0728dd0d6981")); rf_free(hx);
    char back[200]; rf_chacha20_xor(key, nonce, 1, ct, back, strlen(pt)); CHECK(!memcmp(back, pt, strlen(pt)));
    uint8_t r1[16], r2[16]; rf_random_bytes(r1, 16); rf_random_bytes(r2, 16); CHECK(memcmp(r1, r2, 16) != 0);
    /* compression */
    size_t N = 200000; uint8_t* src = malloc(N); for (size_t i = 0; i < N; i++) src[i] = (uint8_t)((i * i / 7) % 13 + (i % 1000 < 500 ? 0 : i % 5));
    void* c; size_t cn; CHECK(rf_lz_compress(src, N, &c, &cn) == RF_OK); printf("lz: %zu -> %zu\n", N, cn);
    void* u; size_t un; CHECK(rf_lz_decompress(c, cn, &u, &un) == RF_OK && un == N && !memcmp(u, src, N)); rf_free(c); rf_free(u);
    uint8_t* rnd = malloc(5000); rf_random_bytes(rnd, 5000); rf_lz_compress(rnd, 5000, &c, &cn); CHECK(rf_lz_decompress(c, cn, &u, &un) == RF_OK && !memcmp(u, rnd, 5000)); rf_free(c); rf_free(u);
    rf_lz_compress("", 0, &c, &cn); CHECK(rf_lz_decompress(c, cn, &u, &un) == RF_OK && un == 0); rf_free(c); rf_free(u);
    /* package */
    RF_Pack* p = rf_pack_new(); rf_pack_set_meta(p, "name", "Demo"); rf_pack_set_meta(p, "version", "1.2.3");
    rf_pack_add(p, "big.bin", src, N, 1); rf_pack_add(p, "rnd.bin", rnd, 5000, 1); rf_pack_add(p, "dir/hello.txt", "hello", 5, 0);
    CHECK(rf_pack_add(p, "dir/hello.txt", "x", 1, 0) != RF_OK);
    void* pm; size_t ps; CHECK(rf_pack_save_mem(p, &pm, &ps) == RF_OK); printf("udklib: %zu bytes\n", ps); rf_pack_free(p);
    RF_Pack* q; CHECK(rf_pack_open_mem(pm, ps, &q) == RF_OK && rf_pack_count(q) == 3 && !strcmp(rf_pack_meta(q, "version"), "1.2.3"));
    void* x; size_t xn; CHECK(rf_pack_extract(q, "big.bin", &x, &xn) == RF_OK && xn == N && !memcmp(x, src, N)); rf_free(x);
    CHECK(rf_pack_extract(q, "dir/hello.txt", &x, &xn) == RF_OK && xn == 5 && !memcmp(x, "hello", 5)); rf_free(x);
    CHECK(rf_pack_extract(q, "nope", &x, &xn) == RF_ERR_NOTFOUND); rf_pack_free(q);
    ((uint8_t*)pm)[ps / 2] ^= 0xFF; /* corrupt middle -> must be detected */
    rf_pack_open_mem(pm, ps, &q); int bad = 0; for (size_t i = 0; q && i < rf_pack_count(q); i++) { if (rf_pack_extract(q, rf_pack_name(q, i), &x, &xn) != RF_OK) bad = 1; else rf_free(x); } CHECK(bad); rf_pack_free(q);
    free(src); free(rnd); rf_free(pm);
    printf(fails ? "\n%d FAILED\n" : "\nALL PURE TESTS PASSED\n", fails); return fails != 0;
}
