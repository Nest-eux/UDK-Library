/* Linux-only shim so the pure libs can be unit-tested without Windows */
#include "RF/Core.h"
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <stdio.h>
static char err[256];
void* rf_alloc(size_t n) { return calloc(1, n ? n : 1); }
void* rf_realloc(void* p, size_t n) { return realloc(p, n); }
void rf_free(void* p) { free(p); }
char* rf_strdup(const char* s) { if (!s) return NULL; size_t n = strlen(s) + 1; char* d = malloc(n); if (d) memcpy(d, s, n); return d; }
const char* rf_last_error(void) { return err; }
void rf_set_error(const char* f, ...) { va_list a; va_start(a, f); vsnprintf(err, sizeof err, f, a); va_end(a); }
uint32_t rf_crc32(const void* d, size_t n) { const uint8_t* p = d; uint32_t c = 0xFFFFFFFFu; for (size_t i = 0; i < n; i++) { c ^= p[i]; for (int k = 0; k < 8; k++) c = (c >> 1) ^ (0xEDB88320u & (uint32_t)-(int32_t)(c & 1)); } return ~c; }
uint64_t rf_fnv1a64(const void* d, size_t n) { const uint8_t* p = d; uint64_t h = 1469598103934665603ULL; for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 1099511628211ULL; } return h; }
