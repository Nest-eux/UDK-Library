#include <cstdio>
#include <cstdlib>
#include <cmath>
#include "RF/Regex.hpp"
#include "RF/Image.hpp"
#include "RF/Math.hpp"
static int fails;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main() {
    RFX_Regex* re = rfx_compile("(\\w+)@(\\w+)\\.com", 0); RFX_Match m;
    CHECK(re && rfx_find(re, "mail bob@site.com now", 0, &m) && m.count == 3 && m.pos[1] == 5 && m.len[1] == 3 && m.pos[2] == 9);
    CHECK(rfx_match_full(re, "a@b.com") && !rfx_match_full(re, "a@b.org")); char* r = rfx_replace(re, "bob@site.com", "$2:$1"); CHECK(r && !std::strcmp(r, "site:bob")); rfx_free_string(r); rfx_free(re);
    CHECK(!rfx_compile("(unclosed", 0));
    RFI_Image* im = rfi_create(4, 2); uint8_t* p = rfi_pixels(im); for (int i = 0; i < 8; i++) { p[i*4] = (uint8_t)(i * 30); p[i*4+1] = 100; p[i*4+2] = 200; p[i*4+3] = 255; }
    void* bmp; size_t bn; CHECK(rfi_save_bmp_mem(im, &bmp, &bn) == RF_OK); RFI_Image* im2 = rfi_load_bmp_mem(bmp, bn);
    CHECK(im2 && rfi_width(im2) == 4 && rfi_height(im2) == 2 && !std::memcmp(rfi_pixels(im2), p, 32)); rfi_free_buffer(bmp);
    RFI_Image* big = rfi_resize(im, 40, 20); CHECK(big && rfi_width(big) == 40 && rfi_pixels(big)[0] == 0 && rfi_pixels(big)[(39) * 4] == 90);
    RFI_Image* cr = rfi_crop(im, 1, 0, 2, 2); CHECK(cr && rfi_pixels(cr)[0] == 30); rfi_flip(im, 0); CHECK(rfi_pixels(im)[0] == 90); rfi_grayscale(im); CHECK(rfi_pixels(im)[1] == rfi_pixels(im)[2]);
    CHECK(!rfi_crop(im, 3, 0, 5, 1)); rfi_free(im); rfi_free(im2); rfi_free(big); rfi_free(cr);
    float t[16], s[16], o[16], inv[16], id[16]; rfm_mat4_translate(t, 1, 2, 3); rfm_mat4_scale(s, 2, 2, 2); rfm_mat4_mul(t, s, o); CHECK(o[12] == 1 && o[0] == 2);
    float R[16]; rfm_mat4_rotate(R, 0.7f, 1, 2, 3); rfm_mat4_mul(o, R, o); CHECK(rfm_mat4_invert(o, inv)); rfm_mat4_mul(o, inv, id); for (int i = 0; i < 16; i++) CHECK(std::fabs(id[i] - (i % 5 == 0)) < 1e-4);
    double A[4] = { 2, 1, 1, 3 }, b[2] = { 3, 5 }, x[2]; CHECK(rfm_solve(A, 2, b, x) && std::fabs(x[0] - 0.8) < 1e-9 && std::fabs(x[1] - 1.4) < 1e-9);
    double sing[4] = { 1, 2, 2, 4 }; CHECK(!rfm_solve(sing, 2, b, x));
    double a2[6] = { 1, 2, 3, 4, 5, 6 }, b2[6] = { 7, 8, 9, 10, 11, 12 }, c2[4]; CHECK(rfm_mat_mul(a2, 2, 3, b2, 2, c2) && c2[0] == 58 && c2[3] == 154);
    double d[5] = { 4, 1, 3, 2, 10 }; RFM_Stats st; CHECK(rfm_stats(d, 5, &st) && st.mean == 4 && st.median == 3 && st.min == 1 && st.max == 10);
    float a3[3] = { 1, 0, 0 }, b3[3] = { 0, 1, 0 }, c3[3]; rfm_vec3_cross(a3, b3, c3); CHECK(c3[2] == 1);
    std::printf(fails ? "\n%d FAILED\n" : "ALL C++ TESTS PASSED\n", fails); return fails != 0;
}
